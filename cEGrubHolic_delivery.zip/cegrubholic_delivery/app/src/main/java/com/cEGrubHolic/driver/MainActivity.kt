package com.cEGrubHolic.driver

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.core.view.GravityCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.adapter.MenuAdapter
import com.cEGrubHolic.driver.fragment.*
import com.cEGrubHolic.driver.models.MenuModel
import com.cEGrubHolic.driver.models.OrderBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.AlertDialogUtil
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_DATA_BUNDLE
import com.cEGrubHolic.driver.utils.FragmentUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_main_toolbar.*
import kotlinx.android.synthetic.main.dialog_confirmation.view.*
import kotlinx.android.synthetic.main.fragment_setting_home.*
import org.json.JSONObject

class MainActivity : BaseActivity() {

    var doubleBackToExitPressedOnce: Boolean = false
    private var receiver: BroadcastReceiver? = null

    val userAuthVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    val listOfDataSideNav = arrayListOf(
        MenuModel( R.string.home),
        MenuModel( R.string.my_profile),
        MenuModel(R.string.earnings),
        MenuModel(R.string.order_history),
        MenuModel(R.string.ratings),
        MenuModel( R.string.change_password),
        MenuModel(R.string.support),
        MenuModel( R.string.terms_and_conditions),
        MenuModel( R.string.privacy_policy),
        MenuModel(R.string.logout)
    )
    var sideNavAdepter: MenuAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        removeFullScreen()
        backStackManager(0)
        setLightStatusBarWhite()

        setViewResponseModel()

        FragmentUtils.replaceMenuFragment(
            this@MainActivity,
            HomeFragment(), R.id.fragment_container
        )
        if (intent != null && intent.hasExtra(KEY_NOTIFICATION_DATA_BUNDLE)) {
            //redirect to notification related screen
            handleNotification(intent)
        }
        //throw NullPointerException("test crash")


        btnLaft.setOnClickListener {
            toggleDrawerMenu()
        }

        sideNavAdepter =
            MenuAdapter(listOfDataSideNav, object : MenuAdapter.OnMenuClickListener {

                override fun onMenuClicked(sideMenuModel: MenuModel) {
                    if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.closeDrawer(GravityCompat.START, true)
                    }

                    for (item in listOfDataSideNav) {
                        item.isSelected = sideMenuModel.menuName == item.menuName
                    }

                    sideNavAdepter?.notifyDataSetChanged()

                    when (sideMenuModel.menuName) {
                        R.string.home -> {

                            tvTitle.text = getString(R.string.home)

                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                HomeFragment(),
                                R.id.fragment_container
                            )


                        }
                        R.string.my_profile -> {
                            tvTitle.text = getString(R.string.my_profile)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                MyProfileFragment(),
                                R.id.fragment_container
                            )

                        }
                        R.string.earnings -> {
                            tvTitle.text = getString(R.string.earnings)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                EarningsFragment(),
                                R.id.fragment_container
                            )

                        }
                        R.string.order_history -> {
                            tvTitle.text= getString(R.string.order_history)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                OrderHistoryFragment(),
                                R.id.fragment_container
                            )

                        }
                        R.string.ratings -> {
                            tvTitle.text= getString(R.string.ratings)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                RatingsFragment(),
                                R.id.fragment_container
                            )

                        }
                        R.string.change_password -> {
                            tvTitle.text = getString(R.string.change_password)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ChangePasswordFragment(),
                                R.id.fragment_container
                            )

                        }
                        R.string.support -> {
                            tvTitle.text = getString(R.string.support)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                SupportFragment(),
                                R.id.fragment_container
                            )
                        }
                        R.string.terms_and_conditions -> {
                            tvTitle.text = getString(R.string.terms_and_conditions)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                TermsAndConditionFragment(),
                                R.id.fragment_container
                            )
                            /*val intent = Intent(this@MainActivity,TermsCondtionDriverActivity::class.java)
                            startActivity(intent)*/

                        }
                        R.string.privacy_policy -> {
                            tvTitle.text = getString(R.string.privacy_policy)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                               PrivacyPolicyFragment(),
                                R.id.fragment_container
                            )
                           /* val intent = Intent(this@MainActivity,PrivacyPolicyDriverActivity::class.java)
                            startActivity(intent)*/

                        }
                        R.string.logout -> {
                            val logoutView = LayoutInflater.from(this@MainActivity)
                                .inflate(R.layout.dialog_confirmation, null)

                            val logoutAlert =
                                AlertDialogUtil.createCustomAlertDialog(
                                    this@MainActivity,
                                    logoutView
                                )

                            logoutView.txtDialogTitle.text = getString(R.string.logout)
                            logoutView.txtDialogMessage.text = getString(R.string.messegeLogout)
                            logoutView.btnPositive.text = getString(R.string.ok)
                            DrawableCompat.setTint(
                                logoutView.btnPositive.background,
                                ContextCompat.getColor(this@MainActivity, R.color.icon_tint)
                            )
                            logoutAlert.show()
                            logoutAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

                            logoutView.btnNegative.setOnClickListener {
                                logoutAlert.dismiss()
                            }

                            logoutView.btnPositive.setOnClickListener {
                                logoutAlert.dismiss()
                                userAuthVM.logout()
                            }

                        }
                    }
                }

            })
        recyacalersideNavegetionView.adapter = sideNavAdepter
        sideNavAdepter?.onMenuClickListener?.onMenuClicked(listOfDataSideNav[0])

    }
    @SuppressLint("WrongConstant")
    fun toggleDrawerMenu() {

        if (drawerLayout.isDrawerOpen(Gravity.START)) {
            drawerLayout.closeDrawer(Gravity.START, true)
        } else {
            drawerLayout.openDrawer(Gravity.START, true)
            navigetionViewMain.bringToFront()
            drawerLayout.requestLayout()
        }


    }
    private fun setViewResponseModel() {
        if (!userAuthVM.logoutApiObservable.hasActiveObservers()) {
            userAuthVM.logoutApiObservable.observe(this) {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                navigetionViewMain,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                navigetionViewMain,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            }
        }
    }

    private fun registerReceiver() {
        try {
            val filter = IntentFilter(Constants.INTENT_ACTION_NOTIFICATION)
            receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    handleNotification(intent)
                }
            }
            registerReceiver(receiver, filter)
        } catch (e: Exception) {
            Log.e("MenuCoachingFragment", "onActivityCreated : ${e.printStackTrace()} ")
        }
    }

    fun unregisterReceiver() {
        try {
            if (receiver != null)
                unregisterReceiver(receiver)
        } catch (e: Exception) {
            Log.e("MenuCoachingFragment", "onDestroy : ${e.printStackTrace()} ")
        }
    }


    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        if (intent != null && intent.hasExtra(KEY_NOTIFICATION_DATA_BUNDLE)) {
            //redirect to notification related screen
            handleNotification(intent)
        }
    }

    private fun handleNotification(intent: Intent) {

        val notificationDataBundle = intent.getBundleExtra(KEY_NOTIFICATION_DATA_BUNDLE)!!
        val nId = if (notificationDataBundle.containsKey(Constants.KEY_NOTIFICATION_nId)) {
            notificationDataBundle.getString(Constants.KEY_NOTIFICATION_nId, "")!!
        } else {
            null
        }
        val vOtherJson =
            if (notificationDataBundle.containsKey(Constants.KEY_NOTIFICATION_vOther)) {
                JSONObject(
                    notificationDataBundle.getString(
                        Constants.KEY_NOTIFICATION_vOther,
                        ""
                    )!!
                )
            } else {
                null
            }


        when (notificationDataBundle.getString(Constants.KEY_NOTIFICATION_nPushType, "")!!) {
            Constants.nPushType_rideRequest -> {
                val currentFragment =
                    supportFragmentManager.findFragmentById(R.id.fragment_container)

                if (currentFragment != null && currentFragment is HomeFragment) {
                    currentFragment.refreshApi()
                } else {
                    FragmentUtils.replaceMenuFragment(
                        this@MainActivity,
                        HomeFragment(), R.id.fragment_container
                    )
                }
            }

            Constants.nPushType_cancel_oder -> {
                if (nId != null) {
                    var orderBean = OrderBean(id = nId)
                    startActivity(
                        Intent(this, OrderDetailActivity::class.java).putExtra(
                            Constants.ORDERMODEL,
                            orderBean
                        )
                            .putExtra(Constants.IS_FROM_NOTIFICATION, true)
                    )
                }

            }

        }
    }

    private fun switchSelectedMenu(menuName: Int) {
        for (item in listOfDataSideNav) {
            item.isSelected = (menuName == item.menuName)
        }
        when (menuName) {
            R.string.home -> {
                tvTitle.text = getString(R.string.home)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.home
                }
            }

            R.string.my_profile -> {
                tvTitle.text  = getString(R.string.my_profile)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.my_profile
                }
            }
            R.string.earnings -> {
                tvTitle.text = getString(R.string.earnings)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.earnings
                }
            }
            R.string.order_history -> {
                tvTitle.text  = getString(R.string.order_history)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.order_history
                }
            }
            R.string.ratings -> {
                tvTitle.text  = getString(R.string.ratings)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.ratings
                }
            }
            R.string.change_password -> {
                tvTitle.text = getString(R.string.change_password)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.change_password
                }
            }
            R.string.support -> {
                tvTitle.text  = getString(R.string.support)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.support
                }
            }
            R.string.terms_and_conditions -> {
                tvTitle.text  = getString(R.string.terms_and_conditions)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.terms_and_conditions
                }
            }
            R.string.privacy_policy -> {
                tvTitle.text = getString(R.string.privacy_policy)
                for (item in listOfDataSideNav) {
                    item.isSelected = item.menuName == R.string.privacy_policy
                }
            }

        }
        sideNavAdepter?.notifyDataSetChanged()

    }

    private fun backStackManager(menuName: Int) {
        for (item in listOfDataSideNav) {
            item.isSelected = (menuName == item.menuName)
        }

        supportFragmentManager.addOnBackStackChangedListener {
            when (supportFragmentManager.findFragmentById(R.id.fragment_container)) {

                is HomeFragment -> {
                    switchSelectedMenu(R.string.home)
                }
                is MyProfileFragment -> {
                    switchSelectedMenu(R.string.my_profile)
                }
                is EarningsFragment -> {
                    switchSelectedMenu(R.string.earnings)
                }
                is OrderHistoryFragment ->{
                    switchSelectedMenu(R.string.order_history)
                }
                is RatingsFragment -> {
                    switchSelectedMenu(R.string.ratings)
                }
                is ChangePasswordFragment -> {
                    switchSelectedMenu(R.string.change_password)
                }
                is SupportFragment -> {
                    switchSelectedMenu(R.string.support)
                }
                is TermsAndConditionFragment -> {
                    switchSelectedMenu(R.string.terms_and_condition)
                }
                is PrivacyPolicyFragment -> {
                    switchSelectedMenu(R.string.privacy_policy)
                }



            }
            sideNavAdepter?.notifyDataSetChanged()
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //Log.d("request Code", "requestCode $requestCode resultCode $resultCode data $data")
        if (data != null) {
            super.onActivityResult(requestCode, resultCode, data)

            val currentFragment =
                supportFragmentManager.findFragmentById(R.id.fragment_container)
            currentFragment!!.onActivityResult(requestCode, resultCode, intent)

        } else {
            super.onActivityResult(requestCode, resultCode, null)
            val currentFragment =
                supportFragmentManager.findFragmentById(R.id.fragment_container)
            currentFragment?.onActivityResult(requestCode, resultCode, intent)
        }


    }

    override fun onBackPressed() {

        Log.e(
            "MainActivity",
            "replaceMenuFragment onBackPressed: \n count : " + supportFragmentManager.backStackEntryCount +
                    "  & frgmnt : " + supportFragmentManager.findFragmentById(R.id.fragment_container)
        )
        if (supportFragmentManager.findFragmentById(R.id.fragment_container) != null
            && (supportFragmentManager.findFragmentById(R.id.fragment_container) is HomeFragment)
        ) {
            if (doubleBackToExitPressedOnce) {
                finish()
                super.onBackPressed()
                return
            }
            this.doubleBackToExitPressedOnce = true
            Toast.makeText(this, getString(R.string.msg_back_press), Toast.LENGTH_SHORT).show()
            Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
        } else if (supportFragmentManager.findFragmentById(R.id.fragment_container) != null
            && supportFragmentManager.findFragmentById(R.id.fragment_container) !is HomeFragment
        ) {
            supportFragmentManager.popBackStack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        isGPSenabled(Constants.RC_ENABLE_GPS)
        registerReceiver()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver()
    }
}