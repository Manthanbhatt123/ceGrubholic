package com.cEGrubHolic.driver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.FoodDataBean
import kotlinx.android.synthetic.main.raw_food_order_item.view.*
import java.util.*


class OrderFoodItemAdapter(
    private val listOfItem: ArrayList<FoodDataBean>
) : RecyclerView.Adapter<OrderFoodItemAdapter.MenuViewHolder>() {

    private var context: Context? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MenuViewHolder {
        context = viewGroup.context
        return MenuViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.raw_food_order_item, null
            )
        )
    }

    override fun onBindViewHolder(menuViewHolder: MenuViewHolder, position: Int) {

        val orderBean = listOfItem[position]
        var itemView = menuViewHolder.itemView
        var size = listOfItem.size

        itemView.tvFoodName.text = orderBean.vProductName
       /* try {
            itemView.tvFoodPrice.text = FormValidationUtils.getValueWithCurrencySymbolCode(
                orderBean.dProductPrice.toDouble() * orderBean.nQty.toDouble(), context!!.getString(
                    R.string.defult_currency
                ), context!!.getString(R.string.defult_conversion_rate)
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
*/
        itemView.tvFoodCount.text = String.format(
            context!!.getString(R.string.placeholder_qty), orderBean.nQty
        )

        if (position == size - 1) {
            menuViewHolder.itemView.divider.visibility = View.GONE
        } else {
            menuViewHolder.itemView.divider.visibility = View.VISIBLE
        }

    }


    override fun getItemCount(): Int {
        return listOfItem.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                //onOrderClickListener.onOrderClicked()
            }
        }
    }

    fun updateItemList(updatedOrderList: ArrayList<FoodDataBean>) {
        listOfItem.clear()
        listOfItem.addAll(updatedOrderList)
        notifyDataSetChanged()
    }

    interface OnOrderClickListener {
        fun onOrderClicked()

    }
}
