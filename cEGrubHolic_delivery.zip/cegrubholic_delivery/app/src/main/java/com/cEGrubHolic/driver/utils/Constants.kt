package com.cEGrubHolic.driver.utils

import com.cEGrubHolic.driver.models.AppLanguageModel
import com.cEGrubHolic.driver.models.Country


object Constants {

    const val ACTIVE_STATUS="ACTIVE_STATUS"

    const val NLOGINDEVICE_TYPE_ANDROID = "1"

    var SUPPORT_CONTECT_NO = ""
    var isAccountApproved = ""

    const val MOBILE_VERIFIED_NO="0"
    const val MOBILE_VERIFIED_YES="1"

    const val IS_LOCATION_SERVICE_RUNNING = "IS_LOCATION_SERVICE_RUNNING"
    var currentLanguage = "en"

    var GOOGLEAPIKEY=""
    var vCurrentCurrencySymbol = ""
    var vSymbol = ""
    const val APK_LANGUAGE_CODE = "APK_LANGUAGE_CODE"
    const val CURRNCY_SYMBOL = "CURRNCY_SYMBOL"
    const val CURRNCY_NAME = "CURRNCY_NAME"
    const val CURRNCY_CONVERSUION_RATE = "CURRNCY_CONVERSUION_RATE"

    const val LATITUDE = "LATITUDE"
    const val LONGITUDE = "LONGITUDE"

    const val KEY_NOTIFICATION_TITLE = "KEY_NOTIFICATION_TITLE"
    const val KEY_NOTIFICATION_MESSAGE = "KEY_NOTIFICATION_MESSAGE"

    const val USERMODEL = "USERMODEL"
    const val ORDERMODEL = "ORDERMODEL"
    const val IS_FROM_NOTIFICATION="IS_FROM_NOTIFICATION"


    const val server_dateformat = "yyyy-MM-dd HH:mm:ss"
    const val display_dateformat = "dd MMM, yyyy hh:mm a"
    const val DATE_FORMAT_ONLY_TIME = "hh:mm aa"
    const val DATE_FORMAT_ONLY_DATE = "dd MMMM yyyy"
    const val NO_INTERNET = "No internet connection"


    const val AUTH_TOKEN = "AUTH_TOKEN"
    const val PUSH_TOKEN = "PUSH_TOKEN"
    const val IS_LOGGED_IN = "IS_LOGGED_IN"
    const val USER_SESSION: String = "USER_SESSION"
    const val APK_VERSION_CODE = "APK_VERSION_CODE"

    const val NSTATUS_ACCEPT = "1"
    const val NSTATUS_REJECT = "2"
    const val NSTATUS_DELIVERED = "3"


    const val KEY_NOTIFICATION_DATA_BUNDLE: String = "notificationDataBundle"
    const val KEY_NOTIFICATION_nPushType = "nPushType"
    const val KEY_NOTIFICATION_nId = "nId"
    const val KEY_NOTIFICATION_vOther = "vOther"
    const val KEY_NOTIFICATION_vOther_isSlientRequired = "isSlientRequired"
    const val INTENT_ACTION_NOTIFICATION = "INTENT_ACTION_NOTIFICATION3"
    const val ACTION_RESTART_SERVICE="ACTION_RESTART_SERVICE"
    const val NOTIFICATION_CHANNEL_ID="Location Service"

    const val nPushType_rideRequest = "5"
    const val nPushType_cancel_oder="11"


    const val KEY_TITLE = "title"
    const val KEY_CATEGORY_ID = "categoryId"

    const val UPDATE_DRIVER_LOCATION = 10000L


    const val KEY_USER_MODEL: String = "KEY_USER_MODEL"

    const val RC_ENABLE_GPS = 1234

    const val RC_ORDER_DETAIL = 501
    const val REGISTRATION_IMAGE_REQ_CODE= 502


    /*fun getOrderStatusByStatusCode(context: Context, orderStatus: String): String {
        return when (orderStatus) {
            TRIPSTATUS_PENDING -> { // Received/pending
                context.getString(R.string.status_pending)
            }

            TRIPSTATUS_ONGOING -> { //confirmed
                context.getString(R.string.status_ongoiong)
            }
            TRIPSTATUS_COMPLETED -> {
                context.getString(R.string.completed)
            }
            TRIPSTATUS_CANCELED -> { //rejected cancelled
                context.getString(R.string.status_rejected)
            }
            else -> { //other
                ""
            }
        }
    }

    fun getOrderStatusTxtColorByStatusCode(context: Context, orderStatus: String): Int {
        return when (orderStatus) {
            TRIPSTATUS_PENDING -> { // Received/pending
                ContextCompat.getColor(context, R.color.yellow)
            }
            TRIPSTATUS_ONGOING -> { //confirmed
                ContextCompat.getColor(context, R.color.Blue)
            }
            TRIPSTATUS_COMPLETED -> {
                ContextCompat.getColor(context, R.color.yellow)
            }
            TRIPSTATUS_CANCELED -> { //rejected cancelled
                (ContextCompat.getColor(context, R.color.red))
            }
            else -> { //other
                (ContextCompat.getColor(context, R.color.status_pending_yellow_text))
            }
        }
    }*/

    val AppLanguages_ENGLISH =
        arrayListOf(AppLanguageModel("Spanish", "es"), AppLanguageModel("English", "en"))

    val AppLanguages_SPANISH =
        arrayListOf(AppLanguageModel("Español", "es"), AppLanguageModel("Ingles", "en"))

    val AppLanguages =
        arrayListOf(
            AppLanguageModel("Español", "es"),
            AppLanguageModel("English", "en")
        )

    val COUNTRIES = arrayOf(
        Country("AD", "Andorra", "+376"),
        Country("AE", "United Arab Emirates", "+971"),
        Country("AF", "Afghanistan", "+93"),
        Country("AG", "Antigua and Barbuda", "+1"),
        Country("AI", "Anguilla", "+1"),
        Country("AL", "Albania", "+355"),
        Country("AM", "Armenia", "+374"),
        Country("AO", "Angola", "+244"),
        Country("AQ", "Antarctica", "+672"),
        Country("AR", "Argentina", "+54"),
        Country("AS", "AmericanSamoa", "+1"),
        Country("AT", "Austria", "+43"),
        Country("AU", "Australia", "+61"),
        Country("AW", "Aruba", "+297"),
        Country("AX", "Åland Islands", "+358"),
        Country("AZ", "Azerbaijan", "+994"),
        Country("BA", "Bosnia and Herzegovina", "+387"),
        Country("BB", "Barbados", "+1"),
        Country("BD", "Bangladesh", "+880"),
        Country("BE", "Belgium", "+32"),
        Country("BF", "Burkina Faso", "+226"),
        Country("BG", "Bulgaria", "+359"),
        Country("BH", "Bahrain", "+973"),
        Country("BI", "Burundi", "+257"),
        Country("BJ", "Benin", "+229"),
        Country("BL", "Saint Barthélemy", "+590"),
        Country("BM", "Bermuda", "+1"),
        Country("BN", "Brunei Darussalam", "+673"),
        Country("BO", "Bolivia, Plurinational State of", "+591"),
        Country("BQ", "Bonaire", "+599"),
        Country("BR", "Brazil", "+55"),
        Country("BS", "Bahamas", "+1"),
        Country("BT", "Bhutan", "+975"),
        Country("BV", "Bouvet Island", "+47"),
        Country("BW", "Botswana", "+267"),
        Country("BY", "Belarus", "+375"),
        Country("BZ", "Belize", "+501"),
        Country("CA", "Canada", "+1"),
        Country("CC", "Cocos (Keeling) Islands", "+61"),
        Country("CD", "Congo, The Democratic Republic of the", "+243"),
        Country("CF", "Central African Republic", "+236"),
        Country("CG", "Congo", "+242"),
        Country("CH", "Switzerland", "+41"),
        Country("CI", "Ivory Coast", "+225"),
        Country("CK", "Cook Islands", "+682"),
        Country("CL", "Chile", "+56"),
        Country("CM", "Cameroon", "+237"),
        Country("CN", "China", "+86"),
        Country("CO", "Colombia", "+57"),
        Country("CR", "Costa Rica", "+506"),
        Country("CU", "Cuba", "+53"),
        Country("CV", "Cape Verde", "+238"),
        Country("CW", "Curacao", "+599"),
        Country("CX", "Christmas Island", "+61"),
        Country("CY", "Cyprus", "+357"),
        Country("CZ", "Czech Republic", "+420"),
        Country("DE", "Germany", "+49"),
        Country("DJ", "Djibouti", "+253"),
        Country("DK", "Denmark", "+45"),
        Country("DM", "Dominica", "+1"),
        Country("DO", "Dominican Republic", "+1"),
        Country("DZ", "Algeria", "+213"),
        Country("EC", "Ecuador", "+593"),
        Country("EE", "Estonia", "+372"),
        Country("EG", "Egypt", "+20"),
        Country("EH", "Western Sahara", "+212"),
        Country("ER", "Eritrea", "+291"),
        Country("ES", "Spain", "+34"),
        Country("ET", "Ethiopia", "+251"),
        Country("FI", "Finland", "+358"),
        Country("FJ", "Fiji", "+679"),
        Country("FK", "Falkland Islands (Malvinas)", "+500"),
        Country("FM", "Micronesia, Federated States of", "+691"),
        Country("FO", "Faroe Islands", "+298"),
        Country("FR", "France", "+33"),
        Country("GA", "Gabon", "+241"),
        Country("GB", "United Kingdom", "+44"),
        Country("GD", "Grenada", "+1"),
        Country("GE", "Georgia", "+995"),
        Country("GF", "French Guiana", "+594"),
        Country("GG", "Guernsey", "+44"),
        Country("GH", "Ghana", "+233"),
        Country("GI", "Gibraltar", "+350"),
        Country("GL", "Greenland", "+299"),
        Country("GM", "Gambia", "+220"),
        Country("GN", "Guinea", "+224"),
        Country("GP", "Guadeloupe", "+590"),
        Country("GQ", "Equatorial Guinea", "+240"),
        Country("GR", "Greece", "+30"),
        Country("GS", "South Georgia and the South Sandwich Islands", "+500"),
        Country("GT", "Guatemala", "+502"),
        Country("GU", "Guam", "+1"),
        Country("GW", "Guinea-Bissau", "+245"),
        Country("GY", "Guyana", "+595"),
        Country("HK", "Hong Kong", "+852"),
        Country("HM", "Heard Island and McDonald Islands", ""),
        Country("HN", "Honduras", "+504"),
        Country("HR", "Croatia", "+385"),
        Country("HT", "Haiti", "+509"),
        Country("HU", "Hungary", "+36"),
        Country("ID", "Indonesia", "+62"),
        Country("IE", "Ireland", "+353"),
        Country("IL", "Israel", "+972"),
        Country("IM", "Isle of Man", "+44"),
        Country("IN", "India", "+91"),
        Country("IO", "British Indian Ocean Territory", "+246"),
        Country("IQ", "Iraq", "+964"),
        Country("IR", "Iran, Islamic Republic of", "+98"),
        Country("IS", "Iceland", "+354"),
        Country("IT", "Italy", "+39"),
        Country("JE", "Jersey", "+44"),
        Country("JM", "Jamaica", "+1"),
        Country("JO", "Jordan", "+962"),
        Country("JP", "Japan", "+81"),
        Country("KE", "Kenya", "+254"),
        Country("KG", "Kyrgyzstan", "+996"),
        Country("KH", "Cambodia", "+855"),
        Country("KI", "Kiribati", "+686"),
        Country("KM", "Comoros", "+269"),
        Country("KN", "Saint Kitts and Nevis", "+1"),
        Country("KP", "North Korea", "+850"),
        Country("KR", "South Korea", "+82"),
        Country("KW", "Kuwait", "+965"),
        Country("KY", "Cayman Islands", "+345"),
        Country("KZ", "Kazakhstan", "+7"),
        Country("LA", "Lao People's Democratic Republic", "+856"),
        Country("LB", "Lebanon", "+961"),
        Country("LC", "Saint Lucia", "+1"),
        Country("LI", "Liechtenstein", "+423"),
        Country("LK", "Sri Lanka", "+94"),
        Country("LR", "Liberia", "+231"),
        Country("LS", "Lesotho", "+266"),
        Country("LT", "Lithuania", "+370"),
        Country("LU", "Luxembourg", "+352"),
        Country("LV", "Latvia", "+371"),
        Country("LY", "Libyan Arab Jamahiriya", "+218"),
        Country("MA", "Morocco", "+212"),
        Country("MC", "Monaco", "+377"),
        Country("MD", "Moldova, Republic of", "+373"),
        Country("ME", "Montenegro", "+382"),
        Country("MF", "Saint Martin", "+590"),
        Country("MG", "Madagascar", "+261"),
        Country("MH", "Marshall Islands", "+692"),
        Country("MK", "Macedonia, The Former Yugoslav Republic of", "+389"),
        Country("ML", "Mali", "+223"),
        Country("MM", "Myanmar", "+95"),
        Country("MN", "Mongolia", "+976"),
        Country("MO", "Macao", "+853"),
        Country("MP", "Northern Mariana Islands", "+1"),
        Country("MQ", "Martinique", "+596"),
        Country("MR", "Mauritania", "+222"),
        Country("MS", "Montserrat", "+1"),
        Country("MT", "Malta", "+356"),
        Country("MU", "Mauritius", "+230"),
        Country("MV", "Maldives", "+960"),
        Country("MW", "Malawi", "+265"),
        Country("MX", "Mexico", "+52"),
        Country("MY", "Malaysia", "+60"),
        Country("MZ", "Mozambique", "+258"),
        Country("NA", "Namibia", "+264"),
        Country("NC", "New Caledonia", "+687"),
        Country("NE", "Niger", "+227"),
        Country("NF", "Norfolk Island", "+672"),
        Country("NG", "Nigeria", "+234"),
        Country("NI", "Nicaragua", "+505"),
        Country("NL", "Netherlands", "+31"),
        Country("NO", "Norway", "+47"),
        Country("NP", "Nepal", "+977"),
        Country("NR", "Nauru", "+674"),
        Country("NU", "Niue", "+683"),
        Country("NZ", "New Zealand", "+64"),
        Country("OM", "Oman", "+968"),
        Country("PA", "Panama", "+507"),
        Country("PE", "Peru", "+51"),
        Country("PF", "French Polynesia", "+689"),
        Country("PG", "Papua New Guinea", "+675"),
        Country("PH", "Philippines", "+63"),
        Country("PK", "Pakistan", "+92"),
        Country("PL", "Poland", "+48"),
        Country("PM", "Saint Pierre and Miquelon", "+508"),
        Country("PN", "Pitcairn", "+872"),
        Country("PR", "Puerto Rico", "+1"),
        Country("PS", "Palestinian Territory, Occupied", "+970"),
        Country("PT", "Portugal", "+351"),
        Country("PW", "Palau", "+680"),
        Country("PY", "Paraguay", "+595"),
        Country("QA", "Qatar", "+974"),
        Country("RE", "Réunion", "+262"),
        Country("RO", "Romania", "+40"),
        Country("RS", "Serbia", "+381"),
        Country("RU", "Russia", "+7"),
        Country("RW", "Rwanda", "+250"),
        Country("SA", "Saudi Arabia", "+966"),
        Country("SB", "Solomon Islands", "+677"),
        Country("SC", "Seychelles", "+248"),
        Country("SD", "Sudan", "+249"),
        Country("SE", "Sweden", "+46"),
        Country("SG", "Singapore", "+65"),
        Country("SH", "Saint Helena, Ascension and Tristan Da Cunha", "+290"),
        Country("SI", "Slovenia", "+386"),
        Country("SJ", "Svalbard and Jan Mayen", "+47"),
        Country("SK", "Slovakia", "+421"),
        Country("SL", "Sierra Leone", "+232"),
        Country("SM", "San Marino", "+378"),
        Country("SN", "Senegal", "+221"),
        Country("SO", "Somalia", "+252"),
        Country("SR", "Suriname", "+597"),
        Country("SS", "South Sudan", "+211"),
        Country("ST", "Sao Tome and Principe", "+239"),
        Country("SV", "El Salvador", "+503"),
        Country("SX", "  Sint Maarten", "+1"),
        Country("SY", "Syrian Arab Republic", "+963"),
        Country("SZ", "Swaziland", "+268"),
        Country("TC", "Turks and Caicos Islands", "+1"),
        Country("TD", "Chad", "+235"),
        Country("TF", "French Southern Territories", "+262"),
        Country("TG", "Togo", "+228"),
        Country("TH", "Thailand", "+66"),
        Country("TJ", "Tajikistan", "+992"),
        Country("TK", "Tokelau", "+690"),
        Country("TL", "East Timor", "+670"),
        Country("TM", "Turkmenistan", "+993"),
        Country("TN", "Tunisia", "+216"),
        Country("TO", "Tonga", "+676"),
        Country("TR", "Turkey", "+90"),
        Country("TT", "Trinidad and Tobago", "+1"),
        Country("TV", "Tuvalu", "+688"),
        Country("TW", "Taiwan", "+886"),
        Country("TZ", "Tanzania, United Republic of", "+255"),
        Country("UA", "Ukraine", "+380"),
        Country("UG", "Uganda", "+256"),
        Country("UM", "U.S. Minor Outlying Islands", ""),
        Country("US", "United States", "+1"),
        Country("UY", "Uruguay", "+598"),
        Country("UZ", "Uzbekistan", "+998"),
        Country("VA", "Holy See (Vatican City State)", "+379"),
        Country("VC", "Saint Vincent and the Grenadines", "+1"),
        Country("VE", "Venezuela, Bolivarian Republic of", "+58"),
        Country("VG", "Virgin Islands, British", "+1"),
        Country("VI", "Virgin Islands, U.S.", "+1"),
        Country("VN", "Viet Nam", "+84"),
        Country("VU", "Vanuatu", "+678"),
        Country("WF", "Wallis and Futuna", "+681"),
        Country("WS", "Samoa", "+685"),
        Country("XK", "Kosovo", "+383"),
        Country("YE", "Yemen", "+967"),
        Country("YT", "Mayotte", "+262"),
        Country("ZA", "South Africa", "+27"),
        Country("ZM", "Zambia", "+260"),
        Country("ZW", "Zimbabwe", "+263")
    )


}