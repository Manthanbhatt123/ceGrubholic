package com.cEGrubHolic.driver


import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.appcompat.app.AlertDialog
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.AlertDialogUtil
import com.cEGrubHolic.driver.utils.ConnectionUtil
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_DATA_BUNDLE
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_nPushType
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils


class SplashActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("SplashActivity", "onCreate (line 21): ")
        //showShortToast("EGo  Delivery Driver app")
        //FirebaseApp.initializeApp(this)

        //val crashlytics = FirebaseCrashlytics.getInstance()
        //crashlytics.log("my message")
        Log.d("SplashActivity", "onCreate (line 27): ")
        if (intent != null && intent.extras != null) {
            if (intent.extras!!.containsKey(KEY_NOTIFICATION_nPushType)) {
                Log.d("SplashActivity", "onCreate (line 30): "+intent.extras!!)
                if (MyAppPreferenceUtils.isLoggedIn(this)) {
                    if (ConnectionUtil.isDataConnectionAvailable(this@SplashActivity)) {
                        finish()
                        val mainActivityIntent = Intent(this, MainActivity::class.java)
                        mainActivityIntent.putExtra(KEY_NOTIFICATION_DATA_BUNDLE, intent.extras)
                        startActivity(mainActivityIntent)
                    } else {
                        shownoInternetDialog()
                    }
                } else {
                    startActivity(Intent(this@SplashActivity, LoginActivity::class.java))
                    finish()
                }
            } else {
                transferToMain()
            }
        } else{
            transferToMain()
        }
    }

    private  fun transferToMain(){
        if (!isTaskRoot) {
            finish()
            return
        } else {
            setContentView(R.layout.activity_splash_acativity)

            if (WebServiceRetrofitUtil.webService == null) {
                WebServiceRetrofitUtil.init(this)
            }
            Log.d("SplashActivity", "onCreate (line 85): ")

            Handler().postDelayed({

                if (MyAppPreferenceUtils.isLoggedIn(this)) {

                    val mainActivityIntent = Intent(this, MainActivity::class.java)
                    if (intent != null && intent.extras != null) {
                        Log.d("SplashActivity", "onCreate (line 93): " + intent.extras)
                        mainActivityIntent.putExtra(KEY_NOTIFICATION_DATA_BUNDLE, intent.extras)
                    }
                    startActivity(mainActivityIntent)
                    animateEnterTransition()
                    finish()
                } else {
                    startActivity(Intent(this, LoginActivity::class.java))
                    animateEnterTransition()
                    finish()
                }

            }, 3000)
        }
    }


    fun shownoInternetDialog() {
        val cancelRideDialog = AlertDialogUtil.showOneButtonAlertDialog(
            this,
            getString(R.string.no_internet),
            getString(R.string.no_internet_connection),
            getString(R.string.ok),
            object : AlertDialogUtil.OnOneButtonAlertDialogClickListener {
                override fun onPositiveButtonClicked(alertDialog: AlertDialog) {
                    if (ConnectionUtil.isDataConnectionAvailable(this@SplashActivity)) {
                        val mainActivityIntent =
                            Intent(this@SplashActivity, MainActivity::class.java)
                        mainActivityIntent.putExtra(KEY_NOTIFICATION_DATA_BUNDLE, intent.extras)
                        startActivity(mainActivityIntent)
                    } else {
                        alertDialog.dismiss()
                        shownoInternetDialog()
                    }
                }
            })
        cancelRideDialog.setCancelable(false)
        cancelRideDialog.show()
    }
}
