package com.cEGrubHolic.driver.models



import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class EarningsModel(
    @SerializedName("weeklyEarning")
    val earnings: ArrayList<EarningsItemModel> = arrayListOf(),
    @SerializedName("totalEarning")
    val totalEarning: String = "",
    @SerializedName("totalOrder")
    val totalOrder: String = "",
    @SerializedName("registrationDate")
    val registrationData: String = "",
    @SerializedName("startdate")
    val startdate: String = "",
    @SerializedName("enddate")
    val enddate: String = ""
):Serializable


