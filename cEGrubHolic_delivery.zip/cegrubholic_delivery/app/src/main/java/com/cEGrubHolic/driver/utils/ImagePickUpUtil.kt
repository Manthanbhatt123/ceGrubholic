package  com.cEGrubHolic.driver.utils

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.text.TextUtils
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.*
import java.util.regex.Pattern

/**
 * Created by Ashish on 7/12/18.
 */
object ImagePickUpUtil {

    fun getRealPathFromURI(context: Context, uri: Uri): String? {
        var filePath: String? = ""

        var isImageFromGoogleDrive: Boolean? = false

        if (DocumentsContract.isDocumentUri(context, uri)) {
            if ("com.android.externalstorage.documents" == uri.authority) {
                val docId = DocumentsContract.getDocumentId(uri)
                val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                val type = split[0]

                if ("primary".equals(type, ignoreCase = true)) {
                    filePath = Environment.getExternalStorageDirectory().toString() + "/" + split[1]
                } else {
                    val DIR_SEPORATOR = Pattern.compile("/")
                    val rv = HashSet<String>()
                    val rawExternalStorage = System.getenv("EXTERNAL_STORAGE")
                    val rawSecondaryStoragesStr = System.getenv("SECONDARY_STORAGE")
                    val rawEmulatedStorageTarget = System.getenv("EMULATED_STORAGE_TARGET")
                    if (TextUtils.isEmpty(rawEmulatedStorageTarget)) {
                        if (TextUtils.isEmpty(rawExternalStorage)) {
                            rv.add("/storage/sdcard0")
                        } else {
                            rv.add(rawExternalStorage!!)
                        }
                    } else {
                        val rawUserId: String

                        val path = Environment.getExternalStorageDirectory().absolutePath
                        val folders = DIR_SEPORATOR.split(path)
                        val lastFolder = folders[folders.size - 1]
                        var isDigit = false
                        try {
                            Integer.valueOf(lastFolder)
                            isDigit = true
                        } catch (ignored: NumberFormatException) {
                        }

                        rawUserId = if (isDigit) lastFolder else ""

                        if (TextUtils.isEmpty(rawUserId)) {
                            rv.add(rawEmulatedStorageTarget!!)
                        } else {
                            rv.add(rawEmulatedStorageTarget + File.separator + rawUserId)
                        }
                    }
                    if (!TextUtils.isEmpty(rawSecondaryStoragesStr)) {
                        val rawSecondaryStorages =
                            rawSecondaryStoragesStr!!.split(File.pathSeparator.toRegex()).dropLastWhile { it.isEmpty() }
                                .toTypedArray()
                        Collections.addAll(rv, *rawSecondaryStorages)
                    }
                    val temp = rv.toTypedArray()
                    for (i in temp.indices) {
                        val tempf = File(temp[i] + "/" + split[1])
                        if (tempf.exists()) {
                            filePath = temp[i] + "/" + split[1]
                        }
                    }
                }
            } else if ("com.android.providers.downloads.documents" == uri.authority) {
                val id = DocumentsContract.getDocumentId(uri)
                val contentUri = ContentUris.withAppendedId(
                    Uri.parse("content://downloads/public_downloads"),
                    java.lang.Long.valueOf(id)
                )

                var cursor: Cursor? = null
                val column = "_data"
                val projection = arrayOf(column)
                try {
                    cursor = context.contentResolver.query(contentUri, projection, null, null, null)
                    if (cursor != null && cursor.moveToFirst()) {
                        val column_index = cursor.getColumnIndexOrThrow(column)
                        filePath = cursor.getString(column_index)
                    }
                } finally {
                    cursor?.close()
                }
            } else if ("com.android.providers.media.documents" == uri.authority) {
                val docId = DocumentsContract.getDocumentId(uri)
                val split = docId.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                val type = split[0]

                var contentUri: Uri? = null
                if ("image" == type) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                } else if ("video" == type) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else if ("audio" == type) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                }

                val selection = "_id=?"
                val selectionArgs = arrayOf(split[1])

                var cursor: Cursor? = null
                val column = "_data"
                val projection = arrayOf(column)

                try {
                    cursor = context.contentResolver.query(contentUri!!, projection, selection, selectionArgs, null)
                    if (cursor != null && cursor.moveToFirst()) {
                        val column_index = cursor.getColumnIndexOrThrow(column)
                        filePath = cursor.getString(column_index)
                    }
                } finally {
                    cursor?.close()
                }
            } else if ("com.google.android.apps.docs.storage" == uri.authority) {
                isImageFromGoogleDrive = true
            }
        } else if ("content".equals(uri.scheme!!, ignoreCase = true)) {
            var cursor: Cursor? = null
            val column = "_data"
            val projection = arrayOf(column)

            try {
                cursor = context.contentResolver.query(uri, projection, null, null, null)
                if (cursor != null && cursor.moveToFirst()) {
                    val column_index = cursor.getColumnIndexOrThrow(column)
                    filePath = cursor.getString(column_index)
                }
            } finally {
                cursor?.close()
            }
        } else if ("file".equals(uri.scheme!!, ignoreCase = true)) {
            filePath = uri.path
        }

        if (isImageFromGoogleDrive!!) {
            try {
                val bitmap = BitmapFactory.decodeStream(context.contentResolver.openInputStream(uri))

                val file = File(context.cacheDir.toString() + File.separator + System.currentTimeMillis() + ".png")

                val stream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.WEBP, 100, stream)
                try {
                    if (!file.exists()) {
                        file.createNewFile()
                    } else {
                        file.delete()
                        file.createNewFile()
                    }
                    val fo = FileOutputStream(file)
                    val imageData = stream.toByteArray()


                    fo.write(imageData)
                    fo.flush()
                    fo.close()


                    filePath = file.path
                } catch (e: IOException) {
                    e.printStackTrace()
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }

        }/* else {
            File f = new File(filePath);
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath(), bmOptions);

        }*/

        return filePath
    }
}
