package com.cEGrubHolic.driver.models

import java.io.Serializable

data class AppLanguageModel(val language: String = "", val languageCode: String = ""):
    Serializable {
    override fun toString(): String {
        return language
    }
}