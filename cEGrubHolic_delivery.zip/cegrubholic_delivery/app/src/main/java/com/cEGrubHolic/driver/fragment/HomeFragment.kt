package com.cEGrubHolic.driver.fragment

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.*
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.cEGrubHolic.driver.MainActivity
import com.cEGrubHolic.driver.OrderDetailActivity
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.SettingActivity
import com.cEGrubHolic.driver.adapter.OrderActiveAdapter
import com.cEGrubHolic.driver.models.InitialDataBean
import com.cEGrubHolic.driver.models.OrderBean
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.Constants.GOOGLEAPIKEY
import com.cEGrubHolic.driver.utils.Constants.RC_ORDER_DETAIL
import com.cEGrubHolic.driver.utils.Constants.SUPPORT_CONTECT_NO
import com.cEGrubHolic.driver.utils.Constants.isAccountApproved
import com.cEGrubHolic.driver.utils.Constants.vCurrentCurrencySymbol
import com.cEGrubHolic.driver.utils.Constants.vSymbol
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_home.*
import java.util.*


class HomeFragment : BaseFragment(), View.OnClickListener {

    val userAuthVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }

    var listOfOrder = arrayListOf<OrderBean>()
    var userData = UserSessionBean()
    var initialDataBean: InitialDataBean? = null
    var activeStatus = ""
    var getUserImage = ""
    var getUserName = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    private val orderActiveAdapter by lazy {
        OrderActiveAdapter(
            arrayListOf(),
            object : OrderActiveAdapter.OnOrderClickListener {
                override fun onOrderClicked(orderBean: OrderBean) {
                    startActivityForResult(
                        Intent(requireContext(), OrderDetailActivity::class.java).putExtra(
                            Constants.ORDERMODEL,
                            orderBean
                        )
                            .putExtra(Constants.IS_FROM_NOTIFICATION, false), RC_ORDER_DETAIL
                    )
                }

            })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setViewResponseModel()
        myOrderVM.getInitialData()
        tvlblActiveOrder.visibility = View.GONE
        tvSwitchActive.setOnClickListener(this)
        rvActiveOrder.adapter = orderActiveAdapter





        swipeRefreshHome.setOnRefreshListener {
            myOrderVM.getInitialData()
        }
        userData = MyAppPreferenceUtils.getUserSession(requireContext())
        activeStatus = MyAppPreferenceUtils.getActiveStatus(requireContext())



    }

    private fun callLocationUpdteapi(latitude: Double, longitude: Double) {

        if (userData.dLat == latitude.toString() && userData.dLng == longitude.toString()) {
            Log.d("HomeFragment", "callLocationUpdteapi (line 138): Same Location")
            hideProgress()
        //    myOrderVM.getInitialData()
        } else {
            Log.d("HomeFragment", "callLocationUpdteapi (line 138): Different  Location")
            val apiCall =
                WebServiceRetrofitUtil.webService!!.updateLatLng(latitude, longitude)

            WebServiceResponseHandler.handleApiResponse(
                apiCall,
                object : WebServiceResponseHandler.DataHandler {
                    override fun onSuccess(data: JsonElement, message: String) {
                        Log.w("LocationUpdateService", "updateLatLngToServer : $message")
                        (activity as MainActivity).stopInAppLocationUpdates()
                        hideProgress()
               //         myOrderVM.getInitialData()
                    }

                    override fun onFailure(message: String) {
                        Log.e("LocationUpdateService", "updateLatLngToServer : $message")
                        hideProgress()
                        showSnackbar(
                            imgProfileHome,
                            message,
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                    override fun noInternetConnection() {
                        hideProgress()
                        showSnackbar(
                            imgProfileHome,
                            getString(R.string.no_internet_connection),
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                    override fun sessionExpired() {
                        Log.e("LocationUpdateService", "sessionExpired: stopping service")
                        hideProgress()
                        destroyLoginSession(false)
                    }

                })
        }

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_setting, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle item selection
        when (item.itemId) {

            R.id.menu_setting -> {
                //showShortToast("Setting")
                startActivity(Intent(requireContext()!!, SettingActivity::class.java))
            }
        }
        return true
    }

    override fun onClick(view: View?) {
        when (view) {
            tvSwitchActive -> {
                if (isAccountApproved == "0") {
                    showSnackbar(
                        imgProfileHome,
                        getString(R.string.your_account),
                        SnackbarUtils.SnackbarType.ERROR
                    )
                    tvSwitchActive.isChecked = false
                }else{
                    var isActive = ""
                    if (activeStatus == "1") {
                        isActive = "0"
                    } else {
                        isActive = "1"
                    }

                    userAuthVM.updateProfile(isActive = isActive)
                }

            }
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.updateProfileObserver.hasActiveObservers()) {
            userAuthVM.updateProfileObserver.observe(viewLifecycleOwner) {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            if (requireContext() != null) {
                                MyAppPreferenceUtils.saveUserSession(
                                    requireContext()!!, Gson().fromJson(
                                        it.data,
                                        object : TypeToken<UserSessionBean>() {}.type
                                    )
                                )

                                userData = MyAppPreferenceUtils.getUserSession(requireContext()!!)





                                if (userData.isOnline == "1") {
                                    Log.d("HomeFragment", "setViewResponseModel (line 249): ")
                                    MyAppPreferenceUtils.setActiveStatus(requireContext()!!, "1")
                                    (activity as MainActivity).startInAppLocationUpdates(
                                        isInAppUpdateRequired_ = false,
                                        enableLocationService_ = true
                                    ) {}
                                    myOrderVM.getInitialData()
                                    tvSwitchActive.isChecked = true
                                } else {
                                    Log.d("HomeFragment", "setViewResponseModel (line 258): ")
                                    MyAppPreferenceUtils.setActiveStatus(requireContext()!!, "0")
                                    (activity as MainActivity).stopLocationUpdateService()
                                    showDetailView(false, "", true)
                                    tvSwitchActive.isChecked = false
                                }
                            }
                            activeStatus = MyAppPreferenceUtils.getActiveStatus(requireContext()!!)
                            showSnackbar(
                                imgProfileHome,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                imgProfileHome,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                imgProfileHome,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            }
        }

        if (!myOrderVM.getInitialDataObservable.hasActiveObservers()) {
            myOrderVM.getInitialDataObservable.observe(viewLifecycleOwner) {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swipeRefreshHome.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            swipeRefreshHome.isRefreshing = false
                            initialDataBean = Gson().fromJson(
                                it.data,
                                object : TypeToken<InitialDataBean>() {}.type
                            )
                            vCurrentCurrencySymbol = it.data!!.asJsonObject["vSymbol"].asString
                            vSymbol = it.data!!.asJsonObject["vSymbol"].asString

                            GOOGLEAPIKEY = initialDataBean!!.googlePlaceApiKey
                            SUPPORT_CONTECT_NO =
                                it.data!!.asJsonObject["setting"].asJsonObject["vSupportNo"].asString
                            isAccountApproved = it.data!!.asJsonObject["isApproved"].asString

                            userData = MyAppPreferenceUtils.getUserSession(requireContext())

                            tvDeliveryBoyName.text = userData.vName

                            Glide.with(requireContext())
                                .load(userData.vImagePath)
                                .placeholder(R.drawable.ic_profile_placeholder)
                                .into(imgProfileHome)

                            if (isAccountApproved == "0") {
                                showSnackbar(
                                    imgProfileHome,
                                    getString(R.string.your_account),
                                    SnackbarUtils.SnackbarType.ERROR
                                )
                            }

                            if (isAccountApproved == "1") {
                                if (activeStatus == "3") {
                                    Log.d("HomeFragment", "Status Other")
                                    (activity as MainActivity).startInAppLocationUpdates(
                                        isInAppUpdateRequired_ = true,
                                        enableLocationService_ = false
                                    ) {
                                        //   showProgress(getString(R.string.progress_please_wait), false)
                                        callLocationUpdteapi(it.latitude, it.longitude)
                                    }

                                } else {
                                    if (activeStatus == "1") {
                                        Log.d("HomeFragment", "Sttus Active")
                                        tvSwitchActive.isChecked = true
                                        (activity as MainActivity).startInAppLocationUpdates(
                                            isInAppUpdateRequired_ = false,
                                            enableLocationService_ = true
                                        ) {}
                                        //     myOrderVM.getInitialData()
                                    } else {
                                        Log.d("HomeFragment", "Status inActive")
                                        tvSwitchActive.isChecked = false
                                        showDetailView(false, "", true)
                                    }

                                }

                            }


                            if (activeStatus == "3") {
                                if (initialDataBean!!.isActive == "1") {
                                    Log.d("HomeFragment", "setViewResponseModel (line 315): ")
                                    (activity as MainActivity).startInAppLocationUpdates(
                                        isInAppUpdateRequired_ = false,
                                        enableLocationService_ = true
                                    ) {}
                                    MyAppPreferenceUtils.setActiveStatus(requireContext()!!, "1")
                                    tvSwitchActive.isChecked = true
                                    listOfOrder.clear()
                                    if (initialDataBean!!.orderlist.isNotEmpty()) {
                                        listOfOrder.addAll(initialDataBean!!.orderlist)
                                        orderActiveAdapter.updateOrderList(listOfOrder)
                                        orderActiveAdapter.updateDate(Date())
                                        showDetailView(true, "", false)
                                    } else {
                                        showDetailView(false, it.message, false)
                                    }
                                } else {
                                    Log.d("HomeFragment", "setViewResponseModel (line 328): ")
                                    MyAppPreferenceUtils.setActiveStatus(requireContext()!!, "0")
                                    showDetailView(false, "", true)
                                    tvSwitchActive.isChecked = false
                                }
                            } else {
                                if (initialDataBean!!.isActive == "1") {
                                    Log.d("HomeFragment", "setViewResponseModel (line 335): ")
                                    MyAppPreferenceUtils.setActiveStatus(requireContext(), "1")
                                    listOfOrder.clear()
                                    if (initialDataBean!!.orderlist.isNotEmpty()) {
                                        listOfOrder.addAll(initialDataBean!!.orderlist)
                                        orderActiveAdapter.updateOrderList(listOfOrder)
                                        orderActiveAdapter.updateDate(Date())
                                        showDetailView(true, "", false)
                                    } else {
                                        showDetailView(false, it.message, false)
                                    }
                                } else {
                                    Log.d("HomeFragment", "setViewResponseModel (line 343): ")
                                    MyAppPreferenceUtils.setActiveStatus(requireContext(), "0")
                                    showDetailView(false, "", true)
                                }
                            }
                            activeStatus = MyAppPreferenceUtils.getActiveStatus(requireContext())
                        }
                        ApiResponseStatus.ERROR -> {
                            swipeRefreshHome.isRefreshing = false
                            showDetailView(false, it.message, false)
                            /*showSnackbar(
                                imgProfileHome,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )*/
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            swipeRefreshHome.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swipeRefreshHome.isRefreshing = false
                            showSnackbar(
                                imgProfileHome,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            }
        }


    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String, isHideAll: Boolean) {

        if (isHideAll) {
            tvlblActiveOrder.visibility = View.GONE
            viewDivider.visibility = View.GONE
            rvActiveOrder.visibility = View.GONE
            imgNoDataFoundOrderList.visibility = View.GONE
        } else {

            txtErrorOrderList.text = errorMsg

            if (isDataAvailable) {
                imgNoDataFoundOrderList.visibility = View.GONE
                tvlblActiveOrder.visibility = View.VISIBLE
                viewDivider.visibility = View.VISIBLE
                rvActiveOrder.visibility = View.VISIBLE
            } else {
                tvlblActiveOrder.visibility = View.GONE
                viewDivider.visibility = View.GONE
                rvActiveOrder.visibility = View.GONE
                imgNoDataFoundOrderList.visibility = View.VISIBLE


            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        //super.onActivityResult(requestCode, resultCode, data)
        //if (resultCode == Activity.RESULT_OK) {
        when (requestCode) {

            Constants.RC_ORDER_DETAIL -> {
                //selectedTabId = ORDER_TYPE_PENDING
                myOrderVM.getInitialData()
            }
        }
        //}
    }

    fun refreshApi() {
        myOrderVM.getInitialData()
    }


}