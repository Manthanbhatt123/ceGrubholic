package com.cEGrubHolic.driver.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ReviwesModel(
    @SerializedName("id")
    val userid:String = "",
    @SerializedName("vName")
    val vFullName:String= "",
    @SerializedName("vImagePath")
    val vImagePath:String= "",
    @SerializedName("nDeliveryBoyRate")
    val nRating : String = "",
    @SerializedName("dCreatedDate")
    val dCreatedDate:String = "",
    @SerializedName("vOrderId")
    val vOrderId:String = ""
):Serializable