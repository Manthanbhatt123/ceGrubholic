package com.cEGrubHolic.driver

import android.annotation.TargetApi
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.locationService.LocationUpdateService
import com.cEGrubHolic.driver.models.CheckVersionBean
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.AlertDialogUtil.showOneButtonAlertDialog
import com.cEGrubHolic.driver.utils.AlertDialogUtil.showTwoButtonAlertDialog
import com.cEGrubHolic.driver.utils.ConnectionUtil.startNetworkConnectionChecking
import com.cEGrubHolic.driver.utils.ConnectionUtil.stopNetworkConnectionChecking
import com.cEGrubHolic.driver.utils.Constants.RC_ENABLE_GPS
import com.cEGrubHolic.driver.utils.PackageInfoUtil.getAppVersionName
import com.cEGrubHolic.driver.utils.PackageInfoUtil.isAppLatest
import com.cEGrubHolic.driver.utils.ProgressDialogWithCustomLoader.dismissProgressDialog
import com.cEGrubHolic.driver.utils.ProgressDialogWithCustomLoader.showProgressDialog
import com.cEGrubHolic.driver.viewModelProviders.VersionVM
import com.google.android.gms.location.*
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.dialog_confirmation_without_title.view.*


open class BaseActivity : PermissionActivity() {

    private val UPDATE_INTERVAL_IN_MILLISECONDS: Long = 5000
    private val FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2

    private var mLocationRequest: LocationRequest? = null
    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLocationCallback: LocationCallback? = null

    private var mLocationServiceIntent: Intent? = null
    private var mLocationUpdateService: LocationUpdateService? = null

    var isCheckVersion: Boolean = false

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleManager.setLocale(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        FirebaseApp.initializeApp(this)
        window.apply {
            clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            statusBarColor = Color.TRANSPARENT
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            setLightStatusBarWhite()
        }

        if (WebServiceRetrofitUtil.webService == null) {
            WebServiceRetrofitUtil.init(this)
        }

        //MyAppPreferenceUtils.savePushToken(this, "123")

        FirebaseApp.initializeApp(this)
        /*FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("Error", "pushToken getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                task.result?.token?.let {

                    if (it == MyAppPreferenceUtils.getPushToken(this@BaseActivity)) {
                        return@OnCompleteListener
                    } else {
                        MyAppPreferenceUtils.savePushToken(this, it)
                        WebServiceRetrofitUtil.init(this)
                    }
                }
            })*/

        FirebaseMessaging.getInstance().token.addOnCompleteListener {
            if (it.isComplete) {
                try {
                    val token = it.result
                    Log.d("FCM PushToken: ", token)
                    if (token != MyAppPreferenceUtils.getPushToken(this@BaseActivity)) {
                        Log.d("abc", "onNewToken-BaseActivity: " + token)
                        MyAppPreferenceUtils.savePushToken(this, token)
                        WebServiceRetrofitUtil.init(this)
                    } else {
                        Log.w("Error", "pushToken getInstanceId failed", it.exception)
                        Log.d("BaseActivity_", "not save Token")
                    }
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
                }

            }
        }


        Log.e("BaseActivity", "onCreate: ")
        disableAutoFill()

        if (!appVersionVm.versionApiResponseObservable.hasActiveObservers()) {
            appVersionVm.versionApiResponseObservable.observe(this, {
                it.getContentIfNotHandled()?.let {
                    when (it?.status) {
                        ApiResponseStatus.SUCCESS -> {

                            val appVersionModel: CheckVersionBean = Gson().fromJson(
                                it.data,
                                object : TypeToken<CheckVersionBean>() {}.type
                            )

                            if (appVersionModel.isMaintenanceMode == "1") {
                                showMaintenanceModeAlertDialog()
                            } else {

                                if ((maintenanceAlertDialog != null
                                            && maintenanceAlertDialog!!.isShowing)
                                ) {
                                    maintenanceAlertDialog?.dismiss()
                                }

                                showAppUpdateAlert_IfRequired(appVersionModel)
                            }
                        }
                    }
                }
            })
        }


    }

    override fun onResume() {
        super.onResume()

    }
    /*override fun setContentView(view: Int) {

        val screenRootView = LinearLayout(this)
        screenRootView.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        );
        screenRootView.orientation = LinearLayout.VERTICAL;
        screenRootView.addView(
            LayoutInflater.from(this@BaseActivity).inflate(
                R.layout.frame_debug,
                null
            )
        );

        val screenView = LayoutInflater.from(this@BaseActivity).inflate(view, null)
        screenRootView.addView(screenView)

        super.setContentView(screenRootView)
    }*/

    private var maintenanceAlertDialog: AlertDialog? = null

    private fun showMaintenanceModeAlertDialog() {

        if ((maintenanceAlertDialog != null && maintenanceAlertDialog!!.isShowing)) {
            return
        }

        val alertView = LayoutInflater.from(this@BaseActivity)
            .inflate(R.layout.dialog_confirmation_without_title, null)

        maintenanceAlertDialog =
            AlertDialogUtil.createCustomAlertDialog(
                this@BaseActivity,
                alertView
            )

        alertView.txtDialogMessage.text = getString(R.string.maintenenceModeMessage)

        maintenanceAlertDialog?.setCancelable(false)
        maintenanceAlertDialog?.show()
        maintenanceAlertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))


        alertView.btnNegative.visibility = View.GONE
        alertView.btnPositive.visibility = View.GONE

        maintenanceAlertDialog?.show()
    }

    private var appUpdateAlertDialog: AlertDialog? = null

    private fun showAppUpdateAlert_IfRequired(appVersionModel: CheckVersionBean) {

        if ((appUpdateAlertDialog != null && appUpdateAlertDialog!!.isShowing)) {
            return
        }

        try {
            if (!isAppLatest(getAppVersionName(this), appVersionModel.dVersionName)
                && ((application as BaseApplication).latestVersionOfApp == "0.0" ||
                        (application as BaseApplication).latestVersionOfApp != appVersionModel.dVersionName)
                || ((application as BaseApplication).latestVersionOfApp == appVersionModel.dVersionName &&
                        appVersionModel.isForceUpdate == "1")
            ) {


                if (appVersionModel.isForceUpdate == "1") {
                    appUpdateAlertDialog =
                        showOneButtonAlertDialog(this@BaseActivity,
                            getString(R.string.updateRequired),
                            resources.getString(R.string.app_update_msg),
                            getString(R.string.goToPlayStore),
                            object : AlertDialogUtil.OnOneButtonAlertDialogClickListener {
                                override fun onPositiveButtonClicked(alertDialog: AlertDialog) {

                                    IntentUtils.browserIntentVersioControl(
                                        this@BaseActivity,
                                        appVersionModel.vStoreURL
                                    )
                                }
                            })
                    appUpdateAlertDialog!!.setCancelable(false)
                    appUpdateAlertDialog!!.show()

                    /*appUpdateAlertDialog!!.setOnShowListener {
                        val b = appUpdateAlertDialog!!.getButton(AlertDialog.BUTTON_POSITIVE)
                        b.setOnClickListener {
                            //                            PackageInfoUtil.openGooglePlay(this@BaseActivity)
                            IntentUtils.browserIntent(
                                this@BaseActivity,
                                appVersionModel.vStoreURL
                            )
                        }
                    }*/

                } else {
                    if (!isCheckVersion) {
                        appUpdateAlertDialog = showTwoButtonAlertDialog(this@BaseActivity,
                            getString(R.string.updateRequired),
                            resources.getString(R.string.app_update_msg),
                            getString(R.string.goToPlayStore),
                            getString(R.string.cancel),
                            object : AlertDialogUtil.OnTwoButtonAlertDialogClickListener {
                                override fun onPositiveButtonClicked(alertDialog: AlertDialog) {

                                    IntentUtils.browserIntentVersioControl(
                                        this@BaseActivity,
                                        appVersionModel.vStoreURL
                                    )
                                    isCheckVersion = true
                                }

                                override fun onNegativeButtonClicked(alertDialog: AlertDialog) {

                                    (application as BaseApplication).latestVersionOfApp =
                                        appVersionModel.dVersionName

                                    alertDialog.dismiss()
                                    isCheckVersion = true
                                }
                            })
                        appUpdateAlertDialog!!.setCancelable(true)
                        appUpdateAlertDialog!!.show()
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("BaseActivity", "showAppUpdateAlert_IfRequired : ${e.printStackTrace()} ")
        }
    }


    /*  fun removeLocationUpdate() {
          if (mFusedLocationClient != null && mLocationCallback != null)
              mFusedLocationClient!!.removeLocationUpdates(mLocationCallback)
      }*/

    val appVersionVm by lazy {
        ViewModelProvider(this).get(VersionVM::class.java)
    }

    fun checkAppVersion() {
        appVersionVm.getLatestAppVersion("1", "2")
    }

    fun setFullScreen() {
        // requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

    }

    fun removeFullScreen() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    override fun onDestroy() {
        super.onDestroy()
        KeyboardUtils.hideKeyboard(this, window.decorView)
        if (!MyAppPreferenceUtils.isLoggedIn(this)) {
            stopLocationUpdateService()
        }
        stopNetworkConnectionChecking()
        dismissProgressDialog()
        // stopLocationUpdates()
    }


    fun showShortToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    fun showLongToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    fun destroyLoginSession(isMessageRequired: Boolean) {
        hideProgress()

        if (isMessageRequired)
            showShortToast(getString(R.string.msg_session_expire))

        stopInAppLocationUpdates()
        stopLocationUpdateService()

        MyAppPreferenceUtils.clearLoginSession(this)
        finish()
        val intent = Intent(this, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)

    }



    fun destroyLoginSessionOnSucess(activity: Activity) {
        hideProgress()
        //showShortToast(Constants.SESSION_EXPIRED)
        MyAppPreferenceUtils.clearLoginSession(activity)
        activity.finish()
        val intent = Intent(activity, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)

    }


    fun showSnackbar(view: View, msg: String, type: SnackbarUtils.SnackbarType) {
        when (type) {

            SnackbarUtils.SnackbarType.SUCCESS -> {
                SnackbarUtils.success(this@BaseActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.WARNING -> {
                SnackbarUtils.warning(this@BaseActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.ERROR -> {
                SnackbarUtils.error(this@BaseActivity, view, msg)
            }
        }
    }


    fun showProgress(msg: String, cancelable: Boolean) {
        showProgressDialog(this, "", msg, cancelable)
    }

    fun hideProgress() {
        dismissProgressDialog()
    }

    fun startNetworkConnectionChecker() {
        startNetworkConnectionChecking(this, object : ConnectionUtil.MyListener {
            override fun onConnected(subtypeName: String) {
                showSnackbar(
                    window.decorView, "onConnected with $subtypeName",
                    SnackbarUtils.SnackbarType.SUCCESS
                )
            }

            override fun onDisconnected() {
                showSnackbar(window.decorView, "onDisconnected", SnackbarUtils.SnackbarType.ERROR)

            }
        })
    }


    fun animateEnterTransition() {
        overridePendingTransition(R.anim.enter, R.anim.exit)
    }

    fun animateExitTransition() {
        overridePendingTransition(
            R.anim.enter_return,
            R.anim.exit_return
        )
    }

    val userSession: UserSessionBean
        get() {
            return MyAppPreferenceUtils.getUserSession(this)
        }


    @TargetApi(Build.VERSION_CODES.O)
    private fun disableAutoFill() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            window.decorView.importantForAutofill =
                View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS
    }


    fun isGPSenabled(RC_ENABLE_GPS: Int): Boolean {

        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)
            && !manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        ) {
            showLocationGPSEnableSettingDialog(this, RC_ENABLE_GPS)
            false
        } else {
            true
        }
    }

    private var gpsSettingDialog: AlertDialog? = null

    private fun showLocationGPSEnableSettingDialog(
        activity: Activity,
        rcEnableGps: Int
    ) {

        if (gpsSettingDialog != null && gpsSettingDialog!!.isShowing) return

        gpsSettingDialog =
            AlertDialog.Builder(activity, R.style.DialogTheme)
                .setTitle(getString(R.string.gps_disable))
                .setMessage(getString(R.string.gps_required))
                .setPositiveButton(getString(R.string.enable_gps)) { dialogInterface, i ->
                    // Call your Alert message
                    dialogInterface.dismiss()
                    activity.startActivityForResult(
                        Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS),
                        rcEnableGps
                    )
                }
                .setCancelable(false)
                .create()

        gpsSettingDialog!!.show()
    }


    private var isFunctionAlreadyRunning = false
    private var isInAppUpdateRequired = false
    private var enableLocationService = false
    private var locationCallbackFunction: ((Location) -> Unit)? = null

    fun startInAppLocationUpdates(
        isInAppUpdateRequired_: Boolean = true,  // for app
        enableLocationService_: Boolean = false, // for background
        onLocationChanged: (Location) -> Unit,
    ) {
        this.locationCallbackFunction = onLocationChanged
        this.isInAppUpdateRequired = isInAppUpdateRequired_
        this.enableLocationService = enableLocationService_

        if (isFunctionAlreadyRunning) {
            return
        } else {
            isFunctionAlreadyRunning = true;
        }

        checkAndAskLocationPermissionNew {
            isFunctionAlreadyRunning = false
            if (it) {
                if (isGPSenabled(RC_ENABLE_GPS)) {

                    if (isInAppUpdateRequired) {
                        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

                        mLocationCallback = object : LocationCallback() {
                            override fun onLocationResult(locationResult: LocationResult?) {
                                super.onLocationResult(locationResult)

                                if (locationResult != null) {

                                    try {
                                        if (locationCallbackFunction != null) {
                                            locationCallbackFunction?.invoke(locationResult.lastLocation)
                                        } else {
                                            onLocationChanged(locationResult.lastLocation)
                                        }
                                    } catch (e: java.lang.Exception) {
                                        e.printStackTrace()
                                    }
                                    Log.d(
                                        "BaseActivity",
                                        "onLocationResult : $locationResult.lastLocation    accuracy: ${locationResult.lastLocation!!.accuracy}"
                                    )
                                }
                            }
                        }

                        mLocationRequest = LocationRequest()
                        mLocationRequest!!.interval = UPDATE_INTERVAL_IN_MILLISECONDS
                        mLocationRequest!!.fastestInterval = FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS
                        mLocationRequest!!.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
                        //  mLocationRequest!!.smallestDisplacement = 10f

                        try {
                            mFusedLocationClient?.requestLocationUpdates(
                                mLocationRequest,
                                mLocationCallback!!, Looper.myLooper()
                            )

                            mFusedLocationClient!!.lastLocation
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful && task.result != null) {
                                        try {
                                            if (locationCallbackFunction != null) {
                                                locationCallbackFunction?.invoke(task.result as Location)
                                            } else {
                                                onLocationChanged(task.result as Location)
                                            }
                                        } catch (e: java.lang.Exception) {
                                            e.printStackTrace()
                                        }

                                    } else {
                                        Log.w(
                                            "BaseActivity",
                                            "getLastLocation : Failed to get location."
                                        )
                                    }
                                }

                        } catch (e: SecurityException) {
                            Log.e("BaseActivity", "startLocationUpdates : ${e.printStackTrace()} ")
                        }

                    }

                    if (enableLocationService) {
                        if (mLocationUpdateService != null && isMyServiceRunning(
                                mLocationUpdateService!!.javaClass
                            )
                        ) {
                            return@checkAndAskLocationPermissionNew
                        }

                        mLocationUpdateService = LocationUpdateService()
                        mLocationServiceIntent = Intent(this, mLocationUpdateService!!.javaClass)
                        checkAndAskLocationPermissionNew { isGranted ->
                            if (isGranted) {
                                if (isGPSenabled(RC_ENABLE_GPS)) {
                                    startService(mLocationServiceIntent)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    fun stopInAppLocationUpdates() {

        if (mFusedLocationClient != null && mLocationCallback != null) {
            mFusedLocationClient?.removeLocationUpdates(mLocationCallback)
        }
    }

//    private var bgLocationPermissionAlertDialog: AlertDialog? = null

    private fun startLocationUpdateService() {

        if (mLocationUpdateService != null && isMyServiceRunning(mLocationUpdateService!!.javaClass)) {
            return
        }

        mLocationUpdateService = LocationUpdateService()
        mLocationServiceIntent = Intent(this, mLocationUpdateService!!.javaClass)

        checkAndAskLocationPermissionNew {
            if (it) {
                if (isGPSenabled(RC_ENABLE_GPS)) {
                    startService(mLocationServiceIntent)
                }
            }
        }

        /* if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
             if (ContextCompat.checkSelfPermission(
                     this,
                     Manifest.permission.ACCESS_BACKGROUND_LOCATION
                 ) != PackageManager.PERMISSION_GRANTED
             ) {

                 if (bgLocationPermissionAlertDialog != null && bgLocationPermissionAlertDialog!!.isShowing) {
                     bgLocationPermissionAlertDialog?.dismiss()
                 }

                 //show dialog

                 val backgroundLocationPermissionDialogView = LayoutInflater.from(this@BaseActivity)
                     .inflate(R.layout.dialog_confirmation, null)

                 bgLocationPermissionAlertDialog =
                     AlertDialogUtil.createCustomAlertDialog(
                         this@BaseActivity,
                         backgroundLocationPermissionDialogView
                     )

                 backgroundLocationPermissionDialogView.txtDialogTitle.visibility = View.GONE
                 backgroundLocationPermissionDialogView.viewSeparator.visibility = View.GONE

                 backgroundLocationPermissionDialogView.txtDialogTitle.text =
                     getString(R.string.app_display_name)
                 backgroundLocationPermissionDialogView.txtDialogMessage.text =
                     getString(R.string.backgroundPermissionMessage)
                 backgroundLocationPermissionDialogView.btnPositive.text =
                     getString(R.string.continueToPermission)

                 bgLocationPermissionAlertDialog?.setCancelable(false)
                 bgLocationPermissionAlertDialog?.show()
                 bgLocationPermissionAlertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

                 backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

                 backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                     bgLocationPermissionAlertDialog?.dismiss()
                     checkAndAskBackgroundLocationPermission {
                         if (it) {
                             if (isGPSenabled(RC_ENABLE_GPS)) {
                                 startService(mLocationServiceIntent)
                             }
                         }
                     }

                 }

             } else {
                 checkAndAskBackgroundLocationPermission {
                     if (it) {
                         if (isGPSenabled(RC_ENABLE_GPS)) {
                             startService(mLocationServiceIntent)
                         }
                     }
                 }
             }


         } else {
             checkAndAskLocationPermission {
                 if (it) {
                     if (isGPSenabled(RC_ENABLE_GPS)) {
                         startService(mLocationServiceIntent)
                     }
                 }
             }
         }*/

    }

    fun stopLocationUpdateService() {
        (MyAppPreferenceUtils.setServiceRunningStatus(this, false))
        if (mLocationServiceIntent != null)
            stopService(mLocationServiceIntent!!)
    }

    /*fun updateLatLngToServer(location: Location) {
        //call update lat lng api

        if (WebServiceRetrofitUtil.webService == null) {
            WebServiceRetrofitUtil.init(this)
        }

        try {

            *//* val symbols = DecimalFormatSymbols(Locale.ENGLISH)

             val decimalFormat = DecimalFormat("#.#######", symbols)
             decimalFormat.roundingMode = RoundingMode.HALF_UP

             val latitude = decimalFormat.format(location.latitude).toDouble()
             val longitude = decimalFormat.format(location.longitude).toDouble()*//*

            val latitude = location.latitude
            val longitude = location.longitude

            *//*if (MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).latitude == latitude
                && MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).longitude == longitude
            ) {
                return
            }*//*

            MyAppPreferenceUtils.setUserCurrentLocation(
                applicationContext, latitude, longitude
            )

            val apiCall =
                WebServiceRetrofitUtil.webService!!.updateLocation(latitude, longitude)

            Log.e("BaseActivity", "updateLatLngToServer : $@@@@@@@@ ")

            WebServiceResponseHandler.handleApiResponse(
                apiCall,
                object : WebServiceResponseHandler.DataHandler {
                    override fun onSuccess(data: JsonElement, message: String) {
                        Log.e("BaseActivity", "updateLatLngToServer : $$$$$$$$ $message")
                    }

                    override fun onFailure(message: String) {
                        Log.e("BaseActivity", "updateLatLngToServer : $$$$$$$$ $message")
                    }

                    override fun noInternetConnection() {

                    }

                    override fun sessionExpired() {
                        stopLocationUpdateService()
                        stopInAppLocationUpdates()
                        destroyLoginSession(true)
                    }

                })

        } catch (e: java.lang.NumberFormatException) {
            //catch block added because getting error

            *//*
             * Fatal Exception: java.lang.NumberFormatException: For input string: "-21,528766"
             * crash reported in Huawai Mate9 & Y7 device
             *//*


            Log.e("LocationUpdateService", "updateLatLngToServer : ${e.printStackTrace()} ")
        }
    }*/


    fun isMyServiceRunning(serviceClass: Class<*>): Boolean {

        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                Log.i("isMyServiceRunning?", true.toString() + "")
                return true
            }
        }
        Log.i("isMyServiceRunning?", false.toString() + "")

        return false
    }


    fun setLightStatusBarWhite() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            var flags = window.decorView.systemUiVisibility
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            //flags = flags or 0
            window.decorView.systemUiVisibility = flags
            window.statusBarColor = getColor(R.color.transparent)
        }
    }

    fun clearLightStatusBar() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.statusBarColor = ContextCompat.getColor(this, R.color.colorPrimaryDark)
        }
    }

    /*@RequiresApi(Build.VERSION_CODES.Q)*/
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constants.RC_ENABLE_GPS) {
            Log.d("LocationABCD", "onActivityResult: ")
            startLocationUpdateService()
        }


    }
}