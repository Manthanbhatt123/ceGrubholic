package com.cEGrubHolic.driver.viewModelProviders

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.driver.network.ApiResponse
import com.cEGrubHolic.driver.network.Event
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.google.gson.JsonElement



class VersionVM : ViewModel() {

    val versionApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getLatestAppVersion(nAppType:String,nRecordFor:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.checkAppVersion(nAppType,nRecordFor)

        versionApiResponseObservable.postValue(
            Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    versionApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    versionApiResponseObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    versionApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    versionApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }
}