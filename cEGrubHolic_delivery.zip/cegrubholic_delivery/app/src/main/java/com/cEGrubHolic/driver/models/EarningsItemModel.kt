package com.cEGrubHolic.driver.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class EarningsItemModel(
    @SerializedName("dailytotal")
    val dailytotal: String = "",
    @SerializedName("Date")
    val Date: String = ""
): Serializable