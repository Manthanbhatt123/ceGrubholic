package com.cEGrubHolic.driver.utils

import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Ashish on 24/7/19.
 */
class StringDateComparator : Comparator<String> {
    var dateFormat = SimpleDateFormat(/*"MM/dd/yyyy",*/"yyyy-MM-dd", Locale.ENGLISH)
    override fun compare(lhs: String, rhs: String): Int {
        return dateFormat.parse(lhs).compareTo(dateFormat.parse(rhs))
    }
}