package  com.cEGrubHolic.driver.utils

import android.content.Context
import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.utils.Constants.currentLanguage
import com.cEGrubHolic.driver.utils.PreferenceUtils.sharedPreferences
import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


/**
 * Created by codexalters on 12/3/18.
 */
object MyAppPreferenceUtils {

    fun getToken(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.AUTH_TOKEN,
            ""
        )
    }

    fun saveToken(context: Context, token: String) {
        PreferenceUtils.setString(
            context,
            Constants.AUTH_TOKEN,
            "Bearer $token"
        )
    }


    fun getPushToken(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.PUSH_TOKEN,
            ""
        )
    }

    fun savePushToken(context: Context, pushToken: String) {
        PreferenceUtils.setString(
            context,
            Constants.PUSH_TOKEN,
            pushToken
        )
    }

    fun isLoggedIn(context: Context): Boolean {
        return PreferenceUtils.getBoolean(
            context,
            Constants.IS_LOGGED_IN,
            false
        )
    }

    fun getServiceRunningStatus(context: Context): Boolean {
        return PreferenceUtils.getBoolean(context, Constants.IS_LOCATION_SERVICE_RUNNING, false)
    }

    fun setServiceRunningStatus(context: Context, b: Boolean) {
        PreferenceUtils.setBoolean(context, Constants.IS_LOCATION_SERVICE_RUNNING, b)
    }

    fun setLoggedIn(context: Context, isLoggedIn: Boolean) {
        PreferenceUtils.setBoolean(
            context,
            Constants.IS_LOGGED_IN,
            isLoggedIn
        )
    }

    fun saveUserSession(context: Context, userModel: UserSessionBean) {
        PreferenceUtils.setString(
            context,
            Constants.USER_SESSION,
            Gson().toJson(userModel)
        )
    }

    fun getUserSession(context: Context): UserSessionBean {

        if (PreferenceUtils.getString(
                context,
                Constants.USER_SESSION,
                ""
            ).isNotEmpty()
        ) {
            return Gson().fromJson(
                PreferenceUtils.getString(
                    context,
                    Constants.USER_SESSION,
                    ""
                ),
                object : TypeToken<UserSessionBean>() {}.type
            )
        } else {
            return UserSessionBean()
        }

    }


    /*fun saveInitData(context: Context, initDataBean: InitDataBean) {
        PreferenceUtils.setString(
            context,
            Constants.USER_INIT_DATA,
            Gson().toJson(initDataBean)
        )

        setConversionRate(context, initDataBean.OtherDetails.dConversionRate)
        setCurrencyName(context, initDataBean.OtherDetails.currencyName)
        setCurrencySysmbol(context, initDataBean.OtherDetails.vSymbol)
    }

    fun getInitData(context: Context): InitDataBean {

        if (PreferenceUtils.getString(
                context,
                Constants.USER_INIT_DATA,
                ""
            ).length > 0
        ) {
            return Gson().fromJson(
                PreferenceUtils.getString(
                    context,
                    Constants.USER_INIT_DATA,
                    ""
                ),
                object : TypeToken<InitDataBean>() {}.type
            )
        } else {
            return InitDataBean()
        }

    }*/


    fun setCurrencySysmbol(context: Context, currencySysmbol: String) {
        PreferenceUtils.setString(
            context,
            Constants.CURRNCY_SYMBOL,
            currencySysmbol
        )
    }

    fun getCurrencySysmbol(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.CURRNCY_SYMBOL,
            ""
        )
    }

    fun setCurrencyName(context: Context, currencyRate: String) {
        PreferenceUtils.setString(
            context,
            Constants.CURRNCY_NAME,
            currencyRate
        )
    }

    fun getCurrencyName(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.CURRNCY_NAME,
            ""
        )
    }

    fun setConversionRate(context: Context, conversionRate: String) {
        PreferenceUtils.setString(
            context,
            Constants.CURRNCY_CONVERSUION_RATE,
            conversionRate
        )
    }

    fun getConversionRate(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.CURRNCY_CONVERSUION_RATE,
            ""
        )
    }

    fun getUserCurrentLocation(context: Context): LatLng {

        return LatLng(
            PreferenceUtils.getString(context, Constants.LATITUDE, "0.0").toDouble(),
            PreferenceUtils.getString(context, Constants.LONGITUDE, "0.0").toDouble()
        )
    }

    fun setUserCurrentLocation(requireContext: Context, latitude: Double, longitude: Double) {
        PreferenceUtils.setString(
            requireContext,
            Constants.LATITUDE,
            latitude.toString()
        )
        PreferenceUtils.setString(
            requireContext,
            Constants.LONGITUDE,
            longitude.toString()
        )
    }

    fun setActiveStatus(context: Context, status: String) {
        PreferenceUtils.setString(
            context,
            Constants.ACTIVE_STATUS,
            status
        )
    }

    fun getActiveStatus(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.ACTIVE_STATUS,
            "3"
        )
    }


    fun clearLoginSession(context: Context) {
        val pushToken = getPushToken(context)
        PreferenceUtils.setClear(context)
        savePushToken(context, pushToken)
    }


    fun setLatestAppVersion(context: Context, versionCode: String) {
        PreferenceUtils.setString(
            context,
            Constants.APK_VERSION_CODE,
            versionCode
        )

    }

    fun isAppUpdateRequire(context: Context): Boolean {

        val latestVersionCode =
            sharedPreferences!!.getString(
                Constants.APK_VERSION_CODE,
                PackageInfoUtil.getAppVersionName(context)
            )
        return !PackageInfoUtil.getAppVersionName(context).equals(latestVersionCode)

    }


    fun printHashKey(pContext: Context) {
        try {
            val info = pContext.getPackageManager().getPackageInfo(
                pContext.packageName,
                PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.i(
                    "MyAppPreferenceUtils",
                    "printHashKey : ${Base64.encodeToString(md.digest(), Base64.DEFAULT)}"
                )
            }
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    fun setAppLanguage(context: Context, languageCode: String) {
        PreferenceUtils.setString(context, Constants.APK_LANGUAGE_CODE, languageCode)
        currentLanguage = languageCode
    }

    fun getAppLanguage(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.APK_LANGUAGE_CODE,
            Constants.AppLanguages_SPANISH[1].languageCode
        )
    }


}