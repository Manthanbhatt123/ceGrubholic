package com.cEGrubHolic.driver.fragment

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.SettingActivity
import com.cEGrubHolic.driver.adapter.MenuAdapter
import com.cEGrubHolic.driver.models.MenuModel
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.AlertDialogUtil
import com.cEGrubHolic.driver.utils.FragmentUtils
import com.cEGrubHolic.driver.utils.PackageInfoUtil
import com.cEGrubHolic.driver.utils.SnackbarUtils
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.dialog_confirmation.view.*
import kotlinx.android.synthetic.main.fragment_setting_home.*


class SettingHomeFragment : BaseFragment() {

    val listOfMenus = arrayListOf<MenuModel>()
    var menuAdapter: MenuAdapter? = null

    val userAuthVM by lazy {
        ViewModelProvider(this).get(com.cEGrubHolic.driver.viewModelProviders.UserAuthVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_setting_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setViewResponseModel()
  //      setSideMenu(context!!)
        rvMenu.adapter = menuAdapter

      /*  txtAppVersion.text=String.format(
            getString(R.string.placeholder_version),
            PackageInfoUtil.getAppVersionName(context!!)
        )*/
    }

    private fun setSideMenu(context: Context) {


        listOfMenus.add(
            MenuModel(
                R.string.order_history
            )
        )


        listOfMenus.add(
            MenuModel(
                R.string.my_profile
            )
        )

        listOfMenus.add(
            MenuModel(
                R.string.change_password
            )
        )

        listOfMenus.add(
            MenuModel(
                R.string.logout
            )
        )

/*        menuAdapter =
            MenuAdapter(
                listOfMenus,
                object : MenuAdapter.OnMenuClickListener {

                    override fun onMenuClicked(
                        menuPos: Int,
                        sideMenuModel: MenuModel,
                        sideMenuAdapter: MenuAdapter
                    ) {

                        switchSelectedMenu(sideMenuModel.menuName)

                        when (sideMenuModel.menuName) {

                            R.string.order_history -> {
                                switchSelectedMenu(R.string.order_history)
                                FragmentUtils.addFragment(
                                    activity as SettingActivity,
                                    OrderHistoryFragment(),
                                    R.id.fragment_setting_container
                                )
                            }

                            R.string.my_profile -> {
                                switchSelectedMenu(R.string.my_profile)
                                FragmentUtils.addFragment(
                                    activity as SettingActivity,
                                    MyProfileFragment(),
                                    R.id.fragment_setting_container
                                )
                            }

                            R.string.change_password -> {
                                switchSelectedMenu(R.string.change_password)
                                FragmentUtils.addFragment(
                                    activity as SettingActivity,
                                    ChangePasswordFragment(),
                                    R.id.fragment_setting_container
                                )
                            }

                            R.string.logout -> {
                                val logoutView = LayoutInflater.from(context)
                                    .inflate(R.layout.dialog_confirmation, null)

                                val logoutAlert =
                                    AlertDialogUtil.createCustomAlertDialog(
                                        context!!,
                                        logoutView
                                    )

                                logoutView.txtDialogTitle.text = getString(R.string.logout)
                                logoutView.txtDialogMessage.text = getString(R.string.messegeLogout)
                                logoutView.btnPositive.text = getString(R.string.ok)
                                DrawableCompat.setTint(
                                    logoutView.btnPositive.background,
                                    ContextCompat.getColor(context, R.color.icon_tint)
                                )
                                logoutAlert.show()
                                logoutAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

                                logoutView.btnNegative.setOnClickListener {
                                    logoutAlert.dismiss()
                                }

                                logoutView.btnPositive.setOnClickListener {
                                    logoutAlert.dismiss()
                                    userAuthVM.logout()
                                }
                            }


                        }
                    }
                })*/
    }

    fun switchSelectedMenu(menuName: Int) {

        for ((itemIndex, sideMenuBean) in listOfMenus.withIndex()) {
            listOfMenus[itemIndex].isSelected = menuName == sideMenuBean.menuName
        }
        menuAdapter?.notifyDataSetChanged()

        when (menuName) {

            R.string.order_history -> {
                (activity as SettingActivity).setting_toolbar_title.text =
                    getString(R.string.order_history)
            }

            R.string.my_profile -> {
                (activity as SettingActivity).setting_toolbar_title.text =
                    getString(R.string.my_profile)
            }

            R.string.change_password -> {
                (activity as SettingActivity).setting_toolbar_title.text =
                    getString(R.string.change_password)
            }
        }

        (activity as SettingActivity).toolbarSetting.setNavigationIcon(R.drawable.ic_back_test)
        (activity as SettingActivity).toolbarSetting.setNavigationOnClickListener {
            (activity as SettingActivity).onBackPressed()
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.logoutApiObservable.hasActiveObservers()) {
            userAuthVM.logoutApiObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                rvMenu,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                rvMenu,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }
}

