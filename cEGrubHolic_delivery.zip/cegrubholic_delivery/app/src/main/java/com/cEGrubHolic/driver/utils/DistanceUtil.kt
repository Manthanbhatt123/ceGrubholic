package com.cEGrubHolic.driver.utils

import android.location.Location

object DistanceUtil {
    fun distance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
       /* val theta = lon1 - lon2
        var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))* Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta))
        dist = Math.acos(dist)
        dist = rad2deg(dist)
        //distance in km
        dist = dist * 60.0 * 1.1515
        return dist*/

        val startPoint = Location("locationA")
        startPoint.setLatitude(lat1)
        startPoint.setLongitude(lon1)

        val endPoint = Location("locationA")
        endPoint.setLatitude(lat2)
        endPoint.setLongitude(lon2)

        var dist = startPoint.distanceTo(endPoint)

        dist=dist/1000

        //distance in miles
        //var miles = dist / 1.6
        //return miles
        return dist.toDouble()



       /* val earthRadius = 6371000.0 //meters
        val dLat = Math.toRadians(lat2 - lat1)
        val dLng = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1)) * Math.cos(
            Math.toRadians(lat2)
        ) *
                Math.sin(dLng / 2) * Math.sin(dLng / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

        return (earthRadius * c)*/


    }

    fun distanceinMeter(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        /* val theta = lon1 - lon2
         var dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1))* Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta))
         dist = Math.acos(dist)
         dist = rad2deg(dist)
         //distance in km
         dist = dist * 60.0 * 1.1515
         return dist*/

        val startPoint = Location("locationA")
        startPoint.setLatitude(lat1)
        startPoint.setLongitude(lon1)

        val endPoint = Location("locationA")
        endPoint.setLatitude(lat2)
        endPoint.setLongitude(lon2)

        val dist = startPoint.distanceTo(endPoint)

        //distance in miles
        //var miles = dist / 1.6
        //return miles
        return dist.toDouble()



        /* val earthRadius = 6371000.0 //meters
         val dLat = Math.toRadians(lat2 - lat1)
         val dLng = Math.toRadians(lon2 - lon1)
         val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1)) * Math.cos(
             Math.toRadians(lat2)
         ) *
                 Math.sin(dLng / 2) * Math.sin(dLng / 2)
         val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

         return (earthRadius * c)*/


    }



    fun deg2rad(deg: Double): Double {
        return deg * Math.PI / 180.0
    }

    fun rad2deg(rad: Double): Double {
        return rad * 180.0 / Math.PI
    }
}