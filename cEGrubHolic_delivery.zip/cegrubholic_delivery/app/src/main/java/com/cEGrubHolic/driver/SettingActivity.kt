package com.cEGrubHolic.driver

import android.os.Bundle
import android.util.Log
import com.cEGrubHolic.driver.fragment.ChangePasswordFragment
import com.cEGrubHolic.driver.fragment.MyProfileFragment
import com.cEGrubHolic.driver.fragment.OrderHistoryFragment
import com.cEGrubHolic.driver.fragment.SettingHomeFragment
import com.cEGrubHolic.driver.utils.FragmentUtils
import kotlinx.android.synthetic.main.activity_setting.*


class SettingActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        setSupportActionBar(toolbarSetting)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        removeFullScreen()
        backStackManager()
        setLightStatusBarWhite()

        FragmentUtils.replaceMenuFragment(
            this@SettingActivity,
            SettingHomeFragment(), R.id.fragment_setting_container
        )
    }


    private fun backStackManager() {

        supportFragmentManager.addOnBackStackChangedListener {

            /*  toolbarFoodModule.setNavigationOnClickListener {
              toggleDrawerMenu()
          }
          toolbarFoodModule.setNavigationIcon(R.drawable.ic_menu)*/
            val currentFragment =
                supportFragmentManager.findFragmentById(R.id.fragment_setting_container)

            when (currentFragment) {

                is SettingHomeFragment -> {
                    toolbarSetting.setNavigationIcon(R.drawable.ic_back_test)
                    setting_toolbar_title.text = getString(R.string.settings)
                    toolbarSetting.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }

                is OrderHistoryFragment -> {
                    toolbarSetting.setNavigationIcon(R.drawable.ic_back_test)
                    setting_toolbar_title.text = getString(R.string.order_history)
                    toolbarSetting.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }

                is MyProfileFragment -> {
                    toolbarSetting.setNavigationIcon(R.drawable.ic_back_test)
                    setting_toolbar_title.text = getString(R.string.my_profile)
                    toolbarSetting.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }

                is ChangePasswordFragment -> {
                    toolbarSetting.setNavigationIcon(R.drawable.ic_back_test)
                    setting_toolbar_title.text = getString(R.string.change_password)
                    toolbarSetting.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }


            }
        }

    }

    override fun onBackPressed() {

        Log.e(
            "MainActivity",
            "replaceMenuFragment onBackPressed: \n count : " + supportFragmentManager.backStackEntryCount +
                    "  & frgmnt : " + supportFragmentManager.findFragmentById(R.id.fragment_setting_container)
        )

        if (supportFragmentManager.findFragmentById(R.id.fragment_setting_container) != null
            && (supportFragmentManager.findFragmentById(R.id.fragment_setting_container) is SettingHomeFragment)
        ) {
            finish()
        } else if (supportFragmentManager.findFragmentById(R.id.fragment_setting_container) != null
            && supportFragmentManager.findFragmentById(R.id.fragment_setting_container) !is SettingHomeFragment
        ) {
            supportFragmentManager.popBackStack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}