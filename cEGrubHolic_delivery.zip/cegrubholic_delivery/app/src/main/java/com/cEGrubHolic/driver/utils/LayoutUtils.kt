package  com.cEGrubHolic.driver.utils


import android.app.Activity
import android.content.Context
import android.view.View
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.util.DisplayMetrics



/**
 * Created by codexalters on 10/3/18.
 */
object LayoutUtils {

    fun disableUI(activity: Activity) {
        disableViewGroup(activity.window.decorView as ViewGroup)
    }

    fun disableUI(fragment: Fragment) {
        disableViewGroup(fragment.view as ViewGroup)
    }

    fun enableUI(activity: Activity) {
        enableViewGroup(activity.window.decorView as ViewGroup)
    }

    fun enableUI(fragment: Fragment) {
        enableViewGroup(fragment.view as ViewGroup)
    }

    fun disableViewGroup(layout: ViewGroup) {
        layout.isEnabled = false
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                disableViewGroup(child)
            } else {
                child.isEnabled = false
            }
        }
    }

    fun enableViewGroup(layout: ViewGroup) {
        layout.isEnabled = true
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                enableViewGroup(child)
            } else {
                child.isEnabled = true
            }
        }
    }

    fun unSelectViewGroup(layout: ViewGroup) {
        layout.isSelected=false
        //layout.imgCarSelection.alpha = 0.6f
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                unSelectViewGroup(child)
            } else {
                child.isSelected = false
                //child.imgCarSelection.alpha = 0.6f
            }
        }
    }



    fun disableView(layout: View) {
        layout.isEnabled = false
    }

    fun enableView(layout: View) {
        layout.isEnabled = true
    }

    fun hideViewGroup(layout: ViewGroup) {
        layout.visibility = GONE
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                hideViewGroup(child)
            } else {
                child.visibility = GONE
            }
        }
    }

    fun showViewGroup(layout: ViewGroup) {
        layout.visibility = VISIBLE
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                hideViewGroup(child)
            } else {
                child.visibility = VISIBLE
            }
        }
    }


    fun changeViewSelectionFromViewGroup(layout: ViewGroup, childViewToBeSelected: View) {
        for (i in 0 until layout.childCount) {
            val child = layout.getChildAt(i)
            if (child is ViewGroup) {
                changeViewSelectionFromViewGroup(
                    child,
                    childViewToBeSelected
                )
            } else {
                child.isSelected = child.id == childViewToBeSelected.id
            }
        }
    }

    fun dpToPx(dp: Int,context:Context): Int {
        val displayMetrics = context.resources.getDisplayMetrics()
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT))
    }

    fun pxToDp(px: Int,context:Context): Int {
        val displayMetrics = context.getResources().getDisplayMetrics()
        return Math.round(px / (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT))
    }

}