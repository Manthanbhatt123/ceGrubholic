package com.cEGrubHolic.driver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.OrderBean
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.DateTimeUtils
import com.cEGrubHolic.driver.utils.FormValidationUtils
import kotlinx.android.synthetic.main.raw_active_order.view.*
import java.util.*


class OrderActiveAdapter(
    private val listOfOrder: ArrayList<OrderBean>,
    private val onOrderClickListener: OnOrderClickListener
) : RecyclerView.Adapter<OrderActiveAdapter.MenuViewHolder>() {

    private var context: Context? = null
    private var crtDate=Date()


    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MenuViewHolder {
        context = viewGroup.context
        return MenuViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.raw_active_order, null
            )
        )
    }

    override fun onBindViewHolder(menuViewHolder: MenuViewHolder, position: Int) {

        val orderBean = listOfOrder[position]
        var itemView = menuViewHolder.itemView

        itemView.tvorderId.text = String.format(
            context!!.getString(R.string.placeholder_order_no), orderBean.vOrderId
        )
        if (orderBean.nStatus == "0"){
            itemView.tvOrderViewStatus.text = itemView.context.getString(R.string.order_received)
        }else   if (orderBean.nStatus == "1"){
            itemView.tvOrderViewStatus.text = itemView.context.getString(R.string.orderaccepted)
        }else   if (orderBean.nStatus == "2"){
            itemView.tvOrderViewStatus.text = itemView.context.getString(R.string.orderdispatched)
        }else   if (orderBean.nStatus == "3"){
            itemView.tvOrderViewStatus.text = itemView.context.getString(R.string.order_delivered)
        }else   if (orderBean.nStatus == "4"){
            itemView.tvOrderViewStatus.text = itemView.context.getString(R.string.order_cencel)
        }

        itemView.txtPripretionTime.text = orderBean.nPreparationTime+itemView.context.getString(R.string.min)

        itemView.tvOrderStatus.text = String.format(
            context!!.getString(R.string.placeholder_order_assigned),
            DateTimeUtils.getDateDifferenceMin(
                DateTimeUtils.utcToLocalDateNew(orderBean.dOrderAssignDate,Constants.server_dateformat),
                crtDate
            )
        )
        itemView.tvtotalItem.text = String.format(
            context!!.getString(R.string.placeholder_items), orderBean.nTotalItems
        )
        itemView.tvAmount.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            orderBean.dGrandTotal, Constants.vCurrentCurrencySymbol, context!!.getString(R.string.defult_conversion_rate)
        )
    }


    override fun getItemCount(): Int {
        return listOfOrder.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                onOrderClickListener.onOrderClicked(listOfOrder[layoutPosition])
            }
        }
    }

    fun updateOrderList(updatedOrderList: ArrayList<OrderBean>) {
        listOfOrder.clear()
        listOfOrder.addAll(updatedOrderList)
        notifyDataSetChanged()
    }

    fun updateDate(updatedCrtDate: Date){
        crtDate=updatedCrtDate
    }

    interface OnOrderClickListener {
        fun onOrderClicked(orderBean: OrderBean)

    }
}
