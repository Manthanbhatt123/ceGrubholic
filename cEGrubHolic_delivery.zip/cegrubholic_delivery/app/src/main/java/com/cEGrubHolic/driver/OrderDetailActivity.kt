package com.cEGrubHolic.driver

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.cEGrubHolic.driver.fragment.OrderDeliveredSuccessFragment
import com.cEGrubHolic.driver.fragment.OrderDetailFragment
import com.cEGrubHolic.driver.models.OrderBean
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.FragmentUtils
import kotlinx.android.synthetic.main.activity_order_detail.*


class OrderDetailActivity : BaseActivity() {

    var orderBean: OrderBean? = null
    var isFromNotification = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_detail)
        setSupportActionBar(toolbarOrderDetail)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        removeFullScreen()
        backStackManager()
        setLightStatusBarWhite()

        if (intent != null && intent.hasExtra(Constants.ORDERMODEL) && intent.hasExtra(Constants.IS_FROM_NOTIFICATION)) {
            orderBean = intent.getSerializableExtra(Constants.ORDERMODEL) as OrderBean
            isFromNotification = intent.getBooleanExtra(Constants.IS_FROM_NOTIFICATION, false)
            val orderDetailFragment = OrderDetailFragment()
            val bundle = Bundle()
            bundle.putSerializable(Constants.ORDERMODEL, orderBean)
            orderDetailFragment.arguments = bundle
            //orderDetailFragment.setTargetFragment(this@OrderFragment, RC_ORDER_DETAIL)
            FragmentUtils.addFragment(
                this@OrderDetailActivity,
                orderDetailFragment,
                R.id.fragment_order_details_container
            )
        }
    }

    private fun backStackManager() {

        supportFragmentManager.addOnBackStackChangedListener {
            val currentFragment =
                supportFragmentManager.findFragmentById(R.id.fragment_order_details_container)

            when (currentFragment) {

                is OrderDetailFragment -> {
                    toolbarOrderDetail.setNavigationIcon(R.drawable.ic_back_test)
                    order_details_toolbar.text = getString(R.string.orderdetail)
                    toolbarOrderDetail.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }

                is OrderDeliveredSuccessFragment -> {
                    toolbarOrderDetail.navigationIcon = null
                    order_details_toolbar.text = getString(R.string.orderdetail)
                    toolbarOrderDetail.setNavigationOnClickListener {
                        onBackPressed()
                    }
                }

            }
        }

    }

    override fun onBackPressed() {

        Log.e(
            "MainActivity",
            "replaceMenuFragment onBackPressed: \n count : " + supportFragmentManager.backStackEntryCount +
                    "  & frgmnt : " + supportFragmentManager.findFragmentById(R.id.fragment_order_details_container)
        )

        if (supportFragmentManager.findFragmentById(R.id.fragment_order_details_container) != null
        /*&& (supportFragmentManager.findFragmentById(R.id.fragment_order_details_container) is OrderDetailFragment)*/
        ) {
            if (isFromNotification) {
                val i = Intent(this, MainActivity::class.java)
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                finish()
                startActivity(i)
            } else {
                finish()
            }
        } /*else if (supportFragmentManager.findFragmentById(R.id.fragment_order_details_container) != null
            && supportFragmentManager.findFragmentById(R.id.fragment_order_details_container) !is OrderDetailFragment
        ) {
            supportFragmentManager.popBackStack()
        } */ /*else {
            super.onBackPressed()
        }*/
    }

    override fun onDestroy() {
        super.onDestroy()
    }
}