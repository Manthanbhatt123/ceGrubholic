package com.cEGrubHolic.driver.network


enum class ApiResponseStatus {
    LOADING,
    SUCCESS,
    ERROR,
    SESSION_EXPIRED,
    NO_INTERNET
}