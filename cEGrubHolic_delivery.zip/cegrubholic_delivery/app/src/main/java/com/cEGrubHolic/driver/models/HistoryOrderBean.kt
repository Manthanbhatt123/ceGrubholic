package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class HistoryOrderBean(
    @SerializedName("dCreatedDate")
    val dCreatedDate: String = "",
    @SerializedName("dGrandTotal")
    val dGrandTotal: String = "",
    @SerializedName("dLat")
    val dLat: String = "",
    @SerializedName("dLng")
    val dLng: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nStatus")
    val nStatus: String = "",
    @SerializedName("TotalItems")
    val totalItems: Int = 0,
    @SerializedName("vAddress")
    val vAddress: String = "",
    @SerializedName("vCustomerName")
    val vCustomerName: String = "",
    @SerializedName("vOrderId")
    val vOrderId: String = ""
) : Serializable