package com.cEGrubHolic.driver.network

import android.content.Context
import com.cEGrubHolic.driver.BuildConfig
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.utils.ConnectionUtil
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils.getAppLanguage
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils.getToken
import com.google.gson.GsonBuilder
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.util.concurrent.TimeUnit


object WebServiceRetrofitUtil {

    var webService: WebServices? = null

    const val HEADER_vAuthToken = "vAuthToken"
    const val HEADER_languageCode = "Ln"
    const val HEADER_vPushToken = "vPushToken"
    const val HEADER_vDeviceFingerPrint = "vDeviceFingerPrint"

    fun init(context: Context) {
        val gson = GsonBuilder()
            .setLenient()
            .disableHtmlEscaping()
            .create()

        val vAuthToken = getToken(context)
        val languageCode = getAppLanguage(context)

        val httpLoggingInterceptor = HttpLoggingInterceptor()
        httpLoggingInterceptor.level = HttpLoggingInterceptor.Level.BODY

        val internetAccessInterceptor = Interceptor { chain ->
            //this will check internet connection availability every time request made by user
            if (ConnectionUtil.isDataConnectionAvailable(context)) {
                return@Interceptor chain.proceed(chain.request())
            } else {
                throw IOException(context.getString(R.string.no_internet_connection))
            }
        }

        val headerInterceptor = Interceptor { chain ->
            //this will add required headers to APIs
            return@Interceptor chain.proceed(
                chain.request().newBuilder()
                    .addHeader(HEADER_vAuthToken, vAuthToken)
                    .addHeader(HEADER_languageCode, languageCode)
                    .addHeader(HEADER_vPushToken, MyAppPreferenceUtils.getPushToken(context))
                    .build()
            )
        }

        val okHttpClient =
            OkHttpClient.Builder()
                .addInterceptor(headerInterceptor)
                .addInterceptor(internetAccessInterceptor)
                .addInterceptor(httpLoggingInterceptor)
                .connectTimeout(5, TimeUnit.MINUTES)
                .readTimeout(5, TimeUnit.MINUTES)
                .build()

        val retrofit = Retrofit.Builder()
            .baseUrl(BuildConfig.BaseURL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        webService = retrofit.create(WebServices::class.java)
    }


    fun destroyInstance() {
        if (webService != null)
            webService = null
    }


}