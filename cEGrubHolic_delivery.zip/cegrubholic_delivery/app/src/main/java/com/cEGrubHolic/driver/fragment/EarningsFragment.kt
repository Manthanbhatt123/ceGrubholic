package com.cEGrubHolic.driver.fragment

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.EarningsItemModel
import com.cEGrubHolic.driver.models.EarningsModel
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IAxisValueFormatter
import com.github.mikephil.charting.formatter.IValueFormatter
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.utils.ViewPortHandler
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_earnings.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import java.text.SimpleDateFormat
import java.util.*


class EarningsFragment : BaseFragment() {
    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }
    private val driverEarningList = arrayListOf<EarningsModel>()
    private var vSymbol: String = "Bs."
    private var dConversionRate: String = ""
    private var startDate = Date()
    private var endDate = Date()
    private var eRblance = 0.0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_earnings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        vSymbol = Constants.vCurrentCurrencySymbol


        val todayDate = Calendar.getInstance()
        todayDate.add(Calendar.DAY_OF_WEEK, -6)
        startDate = todayDate.time
        /*  todayDate.add(Calendar.DAY_OF_WEEK, 6)
          endDate = todayDate.time*/

        btnPreviousWeek.setOnClickListener {
            val currentDate = Calendar.getInstance()
            currentDate.time = startDate
            currentDate.add(Calendar.DAY_OF_YEAR, -6)
            startDate = currentDate.time
            myOrderVM.drivrEarning(startDate)
        }

        btnNextWeek.setOnClickListener {
            val currentDate = Calendar.getInstance()
            currentDate.time = startDate
            currentDate.add(Calendar.DAY_OF_YEAR, 6)
            startDate = currentDate.time
            myOrderVM.drivrEarning(startDate)
        }

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        if (!myOrderVM.earningObservable.hasActiveObservers()) {
            myOrderVM.earningObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            //      swipeRefreshHistory.isRefreshing = true
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            var getItemCount = 0.0

                            val todayDates = Calendar.getInstance()
                            todayDates.add(Calendar.DAY_OF_WEEK, 0)

                            val getEarningData: EarningsModel = Gson().fromJson(
                                it.data,
                                object : TypeToken<EarningsModel>() {}.type
                            )
                            initLineChart(mWeightChart, getEarningData.earnings)

                            for (item in getEarningData.earnings){
                                getItemCount  += item.dailytotal.toDouble()
                            }
                            txtTotalWeeklyEarning.text = FormValidationUtils.getValueWithCurrencySymbolCode(
                                getItemCount.toString(),vSymbol, getString(R.string.defult_conversion_rate)
                            )


                            //     swipeRefreshHistory.isRefreshing = false
                            tvTotalEarning.text =   FormValidationUtils.getValueWithCurrencySymbolCode(
                                getEarningData.totalEarning,vSymbol, getString(R.string.defult_conversion_rate)
                            )
                            tvTotalOrder.text = getEarningData.totalOrder
                            txtWeek.text = DateTimeUtils.convertDateFormat(
                                getEarningData.startdate,
                                "yyyy-MM-dd",
                                "dd/MM/yyyy"
                            ) + " - " + DateTimeUtils.convertDateFormat(
                                getEarningData.enddate,
                                "yyyy-MM-dd",
                                "dd/MM/yyyy"
                            )
                            txtWeek2.text = DateTimeUtils.convertDateFormat(
                                getEarningData.registrationData,
                                "yyyy-MM-dd HH:mm:ss",
                                "dd/MM/yyyy"
                            ) + " - " + DateTimeUtils.convertDateFormat(
                                sdf.format(todayDates.time) ,
                                "yyyy-MM-dd",
                                "dd/MM/yyyy"
                            )

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            //      swipeRefreshHistory.isRefreshing = false

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            //       swipeRefreshHistory.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            //   swipeRefreshHistory.isRefreshing = false
                            showSnackbar(
                                mWeightChart,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }

        myOrderVM.drivrEarning(startDate)

    }
    private fun initLineChart(mChart: LineChart, data: ArrayList<EarningsItemModel>?) {
        mChart.clear()

        mChart.description.isEnabled = false
        mChart.setTouchEnabled(true)
        mChart.dragDecelerationFrictionCoef = 0.9f
        mChart.isDragEnabled = true
        mChart.setScaleEnabled(true)
        mChart.setDrawGridBackground(false)
        mChart.isHighlightPerDragEnabled = false
        mChart.isScaleYEnabled = false
        mChart.setBackgroundColor(Color.WHITE)
        mChart.setViewPortOffsets(90f, 25f, 50f, 50f)
        mChart.setDrawMarkers(false)
        mChart.isHighlightPerTapEnabled = true


        val leftAxis = mChart.axisLeft
        leftAxis.textColor = Color.BLACK
        leftAxis.setDrawGridLines(false)
        leftAxis.isGranularityEnabled = false
        leftAxis.yOffset = 0f
        leftAxis.xOffset = 0f
        leftAxis.granularity = 1f
        leftAxis.setPosition(YAxis.YAxisLabelPosition.OUTSIDE_CHART)
        leftAxis.setDrawZeroLine(true)
        leftAxis.isEnabled = true
        leftAxis.textSize = 12f

        mChart.axisRight.isEnabled = false

        val xAxis = mChart.xAxis
        xAxis.position = XAxis.XAxisPosition.BOTTOM_INSIDE
        xAxis.textSize = 10f
        xAxis.textColor = Color.BLACK
        xAxis.setDrawAxisLine(true)
        xAxis.setDrawGridLines(false)
        xAxis.xOffset = 0f
        xAxis.yOffset = -14f
        xAxis.granularity = 1f
        xAxis.textSize = 12f



        var arralstofString = arrayListOf<String>()

        for ( item in data!!){
            arralstofString.add(  DateTimeUtils.convertDateFormat(
                item.Date,
               "yyyy-MM-dd",
                "dd/MM"
            ))
        }

                xAxis.valueFormatter  = IndexAxisValueFormatter(arralstofString)

                        /*object : ValueFormatter() {

            override fun getFormattedValue(value: Float, axis: AxisBase): String {
                if (value == -1f || value.toInt() == dateValues.size) {
                    return ""
                } else {
                    return DateTimeUtils.convertDateFormat(
                        dateValues[value.toInt()],
                        *//*"MM/dd/yyyy",*//* "yyyy-MM-dd",
                        "MM/dd"
                    )
                }
            }
        }*/

        if (data == null || data.isEmpty()) {
            return
        }
        setData(data)

        mWeightChart.invalidate()

        val l = mChart.legend
        l.isEnabled = true
        l.direction = Legend.LegendDirection.LEFT_TO_RIGHT
        l.form = Legend.LegendForm.CIRCLE
        l.textColor = Color.BLACK
//          l.position = Legend.LegendPosition.ABOVE_CHART_CENTER
        l.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        l.verticalAlignment = Legend.LegendVerticalAlignment.TOP
        l.setDrawInside(false)


    }
    val weightEntries = ArrayList<Entry>()
    val dateValues = ArrayList<String>()

    private fun setData(data: ArrayList<EarningsItemModel>) {

        doAsync {
            /* val tempWeightList =
                 (requireActivity().application as ProportionFit).databaseInstance!!.weightDAO().getAllWeightRecordsForGraph
             val listOfLowestWeightRecordFromDB =
                 (requireActivity().application as ProportionFit).databaseInstance!!.weightDAO()
                     .getLowestWeightRecord()*/

            val tempWeightList = data



            Log.w("UpdateWeightFragment", "setData: ${data}")
            val listOfLowestWeightRecordFromDB = data[0]


            val leftAxis = mWeightChart.axisLeft

         /*   //min weight
            if (listOfLowestWeightRecordFromDB.dWeight.toFloat() - (10) > 0) {
                leftAxis.axisMinimum = listOfLowestWeightRecordFromDB.dWeight.toFloat() - (10)
            } else {
                leftAxis.axisMinimum = listOfLowestWeightRecordFromDB.dWeight.toFloat()
            }*/


            val listOfWeightRecordFromDB = arrayListOf<EarningsItemModel>()
            for (item in tempWeightList) {
                listOfWeightRecordFromDB.add(item)
            }


//            val format = SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH)
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
            listOfWeightRecordFromDB.sortWith(Comparator { s1, s2 ->
                if (format.parse(s1.Date).after(format.parse(s2.Date))) {
                    1
                } else if (format.parse(s2.Date)
                        .after(format.parse(s1.Date))
                ) {
                    -1
                } else {
                    0
                }
            })


            dateValues.clear()
            weightEntries.clear()

            for (model in listOfWeightRecordFromDB) {
                dateValues.add(model.Date)
            }

            Collections.sort(dateValues, StringDateComparator())

            for (weightModelIndex in listOfWeightRecordFromDB) {
                for (date in dateValues) {
                    if (weightModelIndex.Date == date) {
                        weightEntries.add(
                            Entry(
                                dateValues.indexOf(date).toFloat(),
                                weightModelIndex.dailytotal.toFloat()
                            )
                        )
                    }
                }
            }


            if (dateValues.isEmpty()) {
                return@doAsync
            }
            // create a dataset and give it a type
            val set1 = LineDataSet(weightEntries, getString(R.string.weekly_earnings))
            set1.axisDependency = YAxis.AxisDependency.LEFT
            set1.color = ContextCompat.getColor(requireContext(), R.color.pink)
            set1.lineWidth = 1.5f
            set1.setDrawCircles(true)
            set1.valueTextSize = 13f
            set1.setCircleColor(set1.color)
            set1.setDrawCircleHole(true)
            set1.setDrawValues(false)
            set1.isHighlightEnabled = true
            set1.highlightLineWidth = 0f
            set1.valueTextColor = set1.color
            set1.setDrawValues(true)
            set1.highLightColor = Color.WHITE

            val data = LineData(set1)

            data.setValueFormatter(object : ValueFormatter() {
                override fun getFormattedValue(
                    value: Float,
                    entry: Entry?,
                    dataSetIndex: Int,
                    viewPortHandler: ViewPortHandler?
                ): String {
                    //   Log.i("TrackCups_n_Weight", "getFormattedValueABCd : $entry $dataSetIndex ")
                    return String.format("%.2f", value)
                }
            })

            if (mWeightChart.data != null) {
                mWeightChart.data.clearValues()
            }
            mWeightChart.data = data

            uiThread {

                mWeightChart.invalidate()
            }
        }

    }

}