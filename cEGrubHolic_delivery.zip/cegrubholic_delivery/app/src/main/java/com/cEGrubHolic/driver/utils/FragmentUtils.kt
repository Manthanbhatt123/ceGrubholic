package  com.cEGrubHolic.driver.utils

import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import com.cEGrubHolic.driver.R


/**
 * Created by codexalters on 4/12/17.
 */
object FragmentUtils {

    fun addFragment(activity: AppCompatActivity, fragment: Fragment, container: Int) {

        val currentFragment = activity.supportFragmentManager.findFragmentById(container)
        if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
            return
        val fragmentPopped = activity.supportFragmentManager.popBackStackImmediate(fragment.javaClass.simpleName, 0)

        if (!fragmentPopped) {
            val transaction = activity.supportFragmentManager.beginTransaction()
            setFragmentTransition(transaction)
            transaction.add(container, fragment, fragment.javaClass.simpleName)
            transaction.addToBackStack(fragment.javaClass.simpleName)
            transaction.commit()
        }
    }

    fun addFragmentWithCommit(activity: AppCompatActivity, fragment: Fragment, container: Int) {

        val currentFragment = activity.supportFragmentManager.findFragmentById(container)
        if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
            return
        val fragmentPopped = activity.supportFragmentManager.popBackStackImmediate(fragment.javaClass.simpleName, 0)

        if (!fragmentPopped) {
            val transaction = activity.supportFragmentManager.beginTransaction()
            setFragmentTransition(transaction)
            transaction.add(container, fragment, fragment.javaClass.simpleName)
            transaction.addToBackStack(fragment.javaClass.simpleName)
            transaction.commitAllowingStateLoss()
        }
    }

    private fun setFragmentTransition(transaction: FragmentTransaction) {
        transaction.setCustomAnimations(
            R.anim.fade_in,
            R.anim.fade_out,
            R.anim.fade_in,
            R.anim.fade_out
        )
    }

    fun replaceFragment(activity: AppCompatActivity, fragment: Fragment, container: Int) {

        val currentFragment = activity.supportFragmentManager.findFragmentById(container)
        if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
            return


        Log.w("FragmentUtils", "replaceFragment before: ${activity.supportFragmentManager.backStackEntryCount}")

        val fragmentPopped = activity.supportFragmentManager.popBackStackImmediate(fragment.javaClass.simpleName, 0)

        Log.w("FragmentUtils", "replaceFragment after: ${activity.supportFragmentManager.backStackEntryCount}")

        if (!fragmentPopped) {
            val transaction = activity.supportFragmentManager.beginTransaction()
            setFragmentTransition(transaction)
            transaction.add(container, fragment, fragment.javaClass.simpleName)
            transaction.addToBackStack(fragment.javaClass.simpleName)
            transaction.commit()
        }
    }

    fun replaceMenuFragment(activity: AppCompatActivity, fragment: Fragment, container: Int) {

        try {
            val currentFragment = activity.supportFragmentManager.findFragmentById(container)
            if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
                return

            val transaction = activity.supportFragmentManager.beginTransaction()
            setFragmentTransition(transaction)
            transaction.replace(container, fragment)
            transaction.addToBackStack(fragment.javaClass.simpleName)
            transaction.commit()
        }
        catch (e:Exception){
            e.printStackTrace()
        }
    }



    fun replaceMenuFragmentWithoutADD(activity: AppCompatActivity, fragment: Fragment, container: Int) {

        val currentFragment = activity.supportFragmentManager.findFragmentById(container)
        if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
            return

        val transaction = activity.supportFragmentManager.beginTransaction()
        setFragmentTransition(transaction)
        transaction.replace(container, fragment)
        //transaction.addToBackStack(fragment.javaClass.simpleName)
        transaction.commit()

    }


    fun addFragmentAndHideCurrent(activity: AppCompatActivity, fragment: Fragment, container: Int) {
        val currentFragment = activity.supportFragmentManager.findFragmentById(container)
        if (currentFragment != null && fragment.javaClass.simpleName == currentFragment.javaClass.simpleName)
            return

        val transaction = activity.supportFragmentManager.beginTransaction()
        if (currentFragment != null) {
            transaction.hide(currentFragment)
        }
        setFragmentTransition(transaction)
        transaction.add(container, fragment, fragment.javaClass.simpleName)
        transaction.addToBackStack(fragment.javaClass.simpleName)
        transaction.commit()

    }

    fun replaceChildFragment(parentFragment: Fragment, childFragment: Fragment, container: Int) {
        val transaction = parentFragment.childFragmentManager.beginTransaction()
        val currentFragment = parentFragment.childFragmentManager.findFragmentById(container)
        if (currentFragment != null && childFragment.javaClass.simpleName == currentFragment.javaClass.simpleName) {
            return
        } else {
            if (currentFragment != null) {
                transaction.hide(currentFragment)
            }

            if (parentFragment.childFragmentManager.findFragmentByTag(childFragment.javaClass.simpleName) != null &&
                parentFragment.childFragmentManager.findFragmentByTag(childFragment.javaClass.simpleName)!!.tag == childFragment.javaClass.simpleName
            ) {
                transaction.show(parentFragment.childFragmentManager.findFragmentByTag(childFragment.javaClass.simpleName)!!)
            } else {
                parentFragment.childFragmentManager.beginTransaction().apply {
                    add(container, childFragment, childFragment.javaClass.simpleName)
                    addToBackStack(childFragment.javaClass.simpleName)
                    commit()
                }
            }
        }


    }


}