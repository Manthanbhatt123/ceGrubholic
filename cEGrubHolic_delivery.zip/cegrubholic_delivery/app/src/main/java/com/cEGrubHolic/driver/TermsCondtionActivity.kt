package com.cEGrubHolic.driver

import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.TermsPrivacyAndAboutUsVM
import kotlinx.android.synthetic.main.activity_terms_condtion.*

class TermsCondtionActivity : BaseActivity() {

    var termstext =
        "<p><strong>OVERVIEW</strong></p> <p>This website and Mobile App (Android/iPhone) is operated by &ldquo;&rdquo;. Throughout the site and Mobile Apps, the terms &ldquo;we&rdquo;, &ldquo;us&rdquo; and &ldquo;our&rdquo; refer to.   offers this website and Mobile Apps, including all information, tools and services available from this site and Mobile Apps to you, the user, conditioned upon your acceptance of all terms, conditions, policies and notices stated here.</p> <p>By visiting our site and using/downloading our Mobile Apps, you engage in our &ldquo;Service&rdquo; and agree to be bound by the following terms and conditions (&ldquo;Terms of Service&rdquo;, &ldquo;Terms&rdquo;), including those additional terms and conditions and policies referenced herein and/or available by link. These Terms of Service apply to all users of the site and Mobile Apps offered by the Site, including without limitation users who are browsers, vendors, customers, and/ or contributors of content and services.</p> <p>Please read these Terms of Service carefully before accessing/using our website or downloading/using our Mobile Apps. By accessing/downloading or using any part of the site of Mobile Apps, you agree to be bound by these Terms of Service. If you do not agree to all the terms and conditions of this agreement, then you may not access the website/use the Mobile Apps or use any services. If these Terms of Service are considered an offer, acceptance is expressly limited to these Terms of Service.</p> <p>Any new features or tools which are added to the current website or Mobile Apps shall also be subject to this Terms of Service. You can review the most current version of the Terms of Service at any time on this page. We reserve the right to update, change or replace any part of these Terms of Service by posting updates and/or changes to our website and Mobile Apps. Please keep checking this page periodically for changes. Your continued use of or access to the website and Mobile Apps following the posting of any changes constitutes acceptance of those changes.</p> <p>&nbsp;</p> <p><strong>SECTION 1 - USE OF OUR SERVICES</strong></p> <ul> <li>By agreeing to these Terms of Service, you represent that you are at least the age of majority in your state or province of residence, or that you are the age of majority in your state or province of residence and you have given us your consent to allow any of your minor dependents to use this site.</li> <li>You may not use our Services for any illegal or unauthorized purpose nor may you, in the use of the Service, violate any laws in your jurisdiction (including but not limited to Intellectual Property laws).</li> <li>A breach or violation of any of the Terms will result in an immediate termination of your Services.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 2 - GENERAL CONDITIONS</strong></p> <ul> <li>We reserve the right to refuse service to anyone for any reason at any time.</li> <li>You understand that your content (not including credit card information), may be transferred unencrypted and involve (a) transmissions over various networks; and (b) changes to conform and adapt to technical requirements of connecting networks or devices. Credit card information is always encrypted during transfer over networks.</li> <li>You agree not to reproduce, duplicate, copy, sell, resell or exploit any portion of the Service, use of the Service, or access to the Service or any contact on the website or Mobile Apps through which the service is provided, without express written permission by us.</li> <li>The headings used in this agreement are included for convenience only and will not limit or otherwise affect these Terms.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 3 - ACCURACY, COMPLETENESS AND TIMELINESS OF INFORMATION</strong></p> <ul> <li>We are not responsible if information made available on our website and Mobile Apps is not accurate, complete or current. The material is provided for general information without any responsibility of its correctness and should not be relied upon or used as the sole basis for making decisions without consulting primary, more accurate, more complete or more timely sources of information. Any reliance on the material on our Website and Mobile Apps is at your own risk.</li> <li>Our website and Mobile Apps may contain certain historical information. Historical information, necessarily, is not current and is provided for your reference only. We reserve the right to modify the contents of our website and Mobile Apps at any time, but we have no obligation to update any information. You agree that it is your responsibility to monitor changes to our website and Mobile Apps.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 4 - MODIFICATIONS TO THE SERVICE AND PRICES</strong></p> <ul> <li>Prices for our Services are subject to change without notice.</li> <li>We reserve the right at any time to modify or discontinue the Service (or any part or content thereof) without notice at any time.</li> <li>We shall not be liable to you or to any third-party for any modification, price change, suspension or discontinuance of the Service.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 5 - SERVICES</strong></p> <ul> <li>We have made every effort to display as accurately as possible the colors and images that appear at our website and Mobile Apps. We cannot guarantee that your computer monitor&#39;s or Mobile Phone&rsquo;s display of any color will be accurate.</li> <li>We reserve the right, but are not obligated, to limit the sales of our Services to any person, geographic region or jurisdiction. We may exercise this right on a case-by-case basis. We reserve the right to limit the services that we offer. All descriptions of our Services and pricing are subject to change at anytime without notice, at the sole discretion of us.</li> <li>We do not warrant that the quality of any services, information, or other material used free or cost or purchased or obtained by you will meet your expectations, or that any errors in the Service will be corrected.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 6 - ACCURACY OF BILLING AND ACCOUNT INFORMATION</strong></p> <ul> <li>We reserve the right to refuse any order you place with us to purchase our Services. We may, in our sole discretion, limit or cancel the purchased Services.</li> <li>You agree to provide current, complete and accurate information at the time of purchase of our Services. You agree to promptly update your account and other information, including your email address and credit card numbers and expiration dates, so that we can complete your transactions and contact you as needed.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 7 - THIRD-PARTY LINKS</strong></p> <ul> <li>Certain content, products and services available via our Service may include materials and information from third-parties.</li> <li>Third-party links on our website and Mobile Apps may, sometimes, direct you to third-party sites, pages and information that are not affiliated with us. We are not responsible for examining or evaluating the content or accuracy and we do not warrant and will not have any liability or responsibility for any third-party materials or websites, or for any other materials, products, or services of third-parties.</li> <li>We are not liable for any harm or damages related to the use of goods, services, resources, content, or anything else provided by third-party. Please review carefully the third-party&#39;s policies and practices and make sure you understand them before you engage with them. Complaints, claims, concerns, or questions regarding third-party products should be directed to the third-party.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 8 - USER COMMENTS, FEEDBACK AND OTHER SUBMISSIONS</strong></p> <ul> <li>If, at our request, you send certain specific submissions (for example feedback) or without a request from us you send creative ideas, suggestions, proposals, plans, or other materials, whether online, by email, by postal mail, or otherwise (collectively, &#39;comments&#39;), you agree that we may, at any time, without restriction, edit, copy, publish, distribute, translate and otherwise use in any medium any comments that you forward to us. We are and shall be under no obligation (1) to maintain any comments in confidence; (2) to pay compensation for any comments; or (3) to respond to any comments.</li> <li>We may, but have no obligation to, monitor, edit or remove content that we determine in our sole discretion are unlawful, offensive, threatening, libelous, defamatory, pornographic, obscene or otherwise objectionable or violates any party&rsquo;s intellectual property or these Terms of Service.</li> <li>You agree that your comments will not violate any right of any third-party, including copyright, trademark, privacy, personality or other personal or proprietary right. You further agree that your comments will not contain libelous or otherwise unlawful, abusive or obscene material, or contain any computer virus or other malware that could in any way affect the operation of the Service or any related website. You may not use a false e-mail address, pretend to be someone other than yourself, or otherwise mislead us or third-parties as to the origin of any comments. You are solely responsible for any comments you make and their accuracy. We take no responsibility and assume no liability for any comments posted by you or any third-party.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 9 - PERSONAL INFORMATION</strong></p> <ul> <li>Your submission of personal information through our website and Mobile Apps is governed by our Privacy Policy.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 10 - ERRORS, INACCURACIES AND OMISSIONS</strong></p> <ul> <li>Occasionally there may be information on our website and Mobile Apps or in the Service that contains typographical errors, inaccuracies or omissions. We reserve the right to correct any errors, inaccuracies or omissions, and to change or update information if any information in the Service or on our website and Mobile Apps is inaccurate at any time without prior notice.</li> <li>We undertake no obligation to update, amend or clarify information in the Service or on our website and Mobile Apps, including without limitation, pricing information, except as required by law. No specified update or refresh date applied in the Service or on our website and Mobile Apps, should be taken to indicate that all information in the Service or on our website and Mobile Apps has been modified or updated.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 11 - PROHIBITED USES</strong></p> <ul> <li>In addition to other prohibitions as set forth in the Terms of Service, you are prohibited from using the website and Mobile Apps or their content: (a) for any unlawful purpose; (b) to solicit others to perform or participate in any unlawful acts; (c) to violate any international, federal, provincial or state regulations, rules, laws, or local ordinances; (d) to infringe upon or violate our intellectual property rights or the intellectual property rights of others; (e) to harass, abuse, insult, harm, defame, slander, disparage, intimidate, or discriminate based on gender, sexual orientation, religion, ethnicity, race, age, national origin, or disability; (f) to submit false or misleading information; (g) to upload or transmit viruses or any other type of malicious code that will or may be used in any way that will affect the functionality or operation of the Service or of any related website, other websites, or the Internet; (h) to collect or track the personal information of others; (i) to spam, phish, pharm, pretext, spider, crawl, or scrape; (j) for any obscene or immoral purpose; or (k) to interfere with or circumvent the security features of the Service or any related website, other websites, or the Internet. We reserve the right to terminate your use of the Service for violating any of the prohibited uses.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 12 - DISCLAIMER OF WARRANTIES; LIMITATION OF LIABILITY</strong></p> <ul> <li>We do not guarantee, represent or warrant that your use of our service will be uninterrupted, timely, secure or error-free.</li> <li>We do not warrant that the results or information that may be obtained from the use of the service will be accurate or reliable.</li> <li>You agree that from time to time we may remove the service for indefinite periods of time or cancel the service at any time, without notice to you.</li> <li>You expressly agree that your use of, or inability to use, the service is at your sole risk. The services delivered to you are (except as expressly stated by us) provided &#39;as is&#39; and &#39;as available&#39; for your use, without any representation, warranties or conditions of any kind, either express or implied, including all implied warranties or conditions of merchantability, merchantable quality, fitness for a particular purpose, durability, title, and non-infringement.</li> <li>In no case shall , our directors, officers, employees, affiliates, agents, contractors, interns, suppliers, service providers or licensors be liable for any injury, loss, claim, or any direct, indirect, incidental, punitive, special, or consequential damages of any kind, including, without limitation lost profits, lost revenue, lost savings, loss of data, replacement costs, or any similar damages, whether based in contract, tort (including negligence), strict liability or otherwise, arising from your use of any of the service or any products procured using the service, or for any other claim related in any way to your use of the service or any product, including, but not limited to, any errors or omissions in any content, or any loss or damage of any kind incurred as a result of the use of the service or any content (or product) posted, transmitted, or otherwise made available via the service, even if advised of their possibility. Because some states or jurisdictions do not allow the exclusion or the limitation of liability for consequential or incidental damages, in such states or jurisdictions, our liability shall be limited to the maximum extent permitted by law.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 13 - INDEMNIFICATION</strong></p> <ul> <li>You agree to indemnify, defend and hold harmless  and our parent, subsidiaries, affiliates, partners, officers, directors, agents, contractors, licensors, service providers, subcontractors, suppliers, interns and employees, harmless from any claim or demand, including reasonable attorneys&rsquo; fees, made by any third-party due to or arising out of your breach of these Terms of Service or the documents they incorporate by reference, or your violation of any law or the rights of a third-party.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 14 - SEVERABILITY</strong></p> <ul> <li>In the event that any provision of these Terms of Service is determined to be unlawful, void or unenforceable, such provision shall nonetheless be enforceable to the fullest extent permitted by applicable law, and the unenforceable portion shall be deemed to be severed from these Terms of Service, such determination shall not affect the validity and enforceability of any other remaining provisions.</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 15 - TERMINATION</strong></p> <ul> <li>The obligations and liabilities of the parties incurred prior to the termination date shall survive the termination of this agreement for all purposes.</li> <li>These Terms of Service are effective unless and until terminated by either you or us. You may terminate these Terms of Service at any time by notifying us that you no longer wish to use our Services, or when you cease using our website and Mobile Apps.</li> <li>If in our sole judgment you fail, or we suspect that you have failed, to comply with any term or provision of these Terms of Service, we also may terminate this agreement at any time without notice and you will remain liable for all amounts due up to and including the date of termination; and/or accordingly may deny you access to our Services (or any part thereof).</li> </ul> <p>&nbsp;</p> <p><strong>SECTION 16 - ENTIRE AGREEMENT</strong></p> <ul> <li>The failure of us to exercise or enforce any right or provision of these Terms of Service shall not constitute a waiver of such right or provision.</li> <li>These Terms of Service and any policies or operating rules posted by us on our website and Mobile Apps or in respect to The Service constitutes the entire agreement and understanding between you and us and govern your use of the Service, superseding any prior or contemporaneous agreements, communications and proposals, whether oral or written, between you and us (including, but not limited to, any prior versions of the Terms of Service).</li> <li>Any ambiguities in the interpretation of these Terms of Service shall not be construed against the .</li> </ul><br><br><br>"


    val termsPrivacyAndAboutUsVM by lazy {
        ViewModelProvider(this).get(TermsPrivacyAndAboutUsVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_terms_condtion)
        setSupportActionBar(toolbartc)
        removeFullScreen()
        toolbartc.setNavigationOnClickListener { onBackPressed() }

        wvTerms.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {

                if (request.url.toString().contains("http") || request.url.toString()
                        .contains("https")
                ) {
                    val intent = Intent(Intent.ACTION_VIEW, request.url)
                    view.context.startActivity(intent)
                }
                return true
            }
        }

        wvTerms.loadData(termstext, "text/html", "UTF-8")

        swipeRefreshTerms.setOnRefreshListener {
            swipeRefreshTerms.isRefreshing = false
        }

        if (!termsPrivacyAndAboutUsVM.apiTermsObservable.hasActiveObservers()) {
            termsPrivacyAndAboutUsVM.apiTermsObservable.observe(this, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swipeRefreshTerms.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            swipeRefreshTerms.isRefreshing = false
                            var termstext = (it.data!!.asJsonObject).get("vDesc").asString
                            termstext.replace("&#39;", "'")
                            wvTerms.settings.javaScriptEnabled = true
                            // show # from html string
                            wvTerms.loadDataWithBaseURL(null, termstext, "text/html", "UTF-8", null)
                        }
                        ApiResponseStatus.ERROR -> {
                            swipeRefreshTerms.isRefreshing = false
                            showSnackbar(
                                swipeRefreshTerms,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            swipeRefreshTerms.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swipeRefreshTerms.isRefreshing = false
                            showSnackbar(
                                swipeRefreshTerms,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        else -> {
                            swipeRefreshTerms.isRefreshing = false
                        }

                    }

                }
            })
        }

        //termsPrivacyAndAboutUsVM.getTermsCondition()

        /* swipeRefreshTerms.setOnRefreshListener {
             termsPrivacyAndAboutUsVM.getTermsCondition()
         }*/

    }
}