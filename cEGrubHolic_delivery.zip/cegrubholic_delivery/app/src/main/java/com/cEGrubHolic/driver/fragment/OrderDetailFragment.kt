package com.cEGrubHolic.driver.fragment

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.opengl.Visibility
import android.os.Bundle
import android.os.Handler
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.BaseActivity
import com.cEGrubHolic.driver.OrderDetailActivity
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.adapter.OrderFoodItemAdapter
import com.cEGrubHolic.driver.models.OrderBean
import com.cEGrubHolic.driver.models.OrderDetailBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.Constants.NSTATUS_ACCEPT
import com.cEGrubHolic.driver.utils.Constants.NSTATUS_DELIVERED
import com.cEGrubHolic.driver.utils.Constants.NSTATUS_REJECT
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_registration.*
import kotlinx.android.synthetic.main.dialog_confirmation_one_button.view.*
import kotlinx.android.synthetic.main.dialog_confirmation_without_title.view.*
import kotlinx.android.synthetic.main.dialog_confirmation_without_title.view.txtDialogMessage
import kotlinx.android.synthetic.main.fragment_order_detail.*
import kotlinx.android.synthetic.main.raw_active_order.view.*
import java.util.*


class OrderDetailFragment : BaseFragment(), View.OnClickListener {

    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }

    var orderBean: OrderBean? = null
    var orderDetailBean: OrderDetailBean? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_order_detail, container, false)
    }

    private val orderFoodItemAdapter by lazy {
        OrderFoodItemAdapter(arrayListOf())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        nsOrderDetail.visibility = View.GONE
        setViewResponseModel()

        tvOrderAccept.setOnClickListener(this)
        tvOrderReject.setOnClickListener(this)
        tvOrderDelivered.setOnClickListener(this)
        rlMapPickup.setOnClickListener(this)
        rlMapDelivery.setOnClickListener(this)

        rvFoodOrder.adapter = orderFoodItemAdapter

        if (arguments != null) {
            if (requireArguments().containsKey(Constants.ORDERMODEL)) {
                orderBean = requireArguments().getSerializable(Constants.ORDERMODEL) as OrderBean

                myOrderVM.getOrderDetails(orderBean!!.id)

                swipeRefreshOrderDetail.setOnRefreshListener {
                    myOrderVM.getOrderDetails(orderBean!!.id)
                }
            }
        }


    }

    private fun setViewResponseModel() {
        if (!myOrderVM.getOrderDetailsObservable.hasActiveObservers()) {
            myOrderVM.getOrderDetailsObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swipeRefreshOrderDetail.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            orderDetailBean = Gson().fromJson(
                                it.data,
                                object : TypeToken<OrderDetailBean>() {}.type
                            )
                            updateUi(orderDetailBean!!)
                        }
                        ApiResponseStatus.ERROR -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            showSnackbar(
                                swipeRefreshOrderDetail,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            showSnackbar(
                                swipeRefreshOrderDetail,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }

        if (!myOrderVM.changeOrderStatusObservable.hasActiveObservers()) {
            myOrderVM.changeOrderStatusObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swipeRefreshOrderDetail.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            activity?.setResult(Activity.RESULT_OK)


                            //check starus
                            when (it.nStatus) {

                                NSTATUS_ACCEPT -> {
                                    llAcceptReject.visibility = View.GONE
                                    tvOrderDelivered.visibility = View.GONE
                                }

                                NSTATUS_REJECT -> {
                                    activity?.finish()
                                }


                                NSTATUS_DELIVERED -> {
                                    val orderDeliveredSuccessFragment =
                                        OrderDeliveredSuccessFragment()
                                    val bundle = Bundle()
                                    bundle.putSerializable(Constants.ORDERMODEL, orderDetailBean)
                                    orderDeliveredSuccessFragment.arguments = bundle
                                    //orderDetailFragment.setTargetFragment(this@OrderFragment, RC_ORDER_DETAIL)
                                    FragmentUtils.addFragment(
                                        activity as OrderDetailActivity,
                                        orderDeliveredSuccessFragment,
                                        R.id.fragment_order_details_container
                                    )
                                }

                            }
                        }
                        ApiResponseStatus.ERROR -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            LayoutUtils.disableUI(this@OrderDetailFragment)
                            showSnackbar(
                                swipeRefreshOrderDetail,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                            Handler().postDelayed({ activity?.finish() }, 1500)


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swipeRefreshOrderDetail.isRefreshing = false
                            showSnackbar(
                                swipeRefreshOrderDetail,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }

    private fun updateUi(orderDetailBean: OrderDetailBean) {
        llAcceptReject.visibility = View.GONE
        tvOrderDelivered.visibility = View.GONE

        tvorderId.text = String.format(
           getString(R.string.placeholder_order_no), orderDetailBean.vOrderId
        )
        tvOrderAmount.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            orderDetailBean.dGrandTotal, Constants.vCurrentCurrencySymbol, getString(R.string.defult_conversion_rate)
        )
        tvtotalItem.text = String.format(
           getString(R.string.placeholder_items), orderDetailBean.foodDatumBeans.size
        )
        tvOrderStatus.text = String.format(
         getString(R.string.placeholder_order_assigned),
            DateTimeUtils.getDateDifferenceMin(
                DateTimeUtils.utcToLocalDateNew(
                    orderDetailBean.dOrderAssignDate,
                    Constants.server_dateformat
                ),
                Date()
            )
        )
        txtPripretionTimeDet.text = orderDetailBean.nPreparationTime +getString(R.string.min)

        if (orderDetailBean.nRequestStatus == "0"){
            tvOrderViewStatus.text = getString(R.string.order_received)
        }else if (orderDetailBean.nRequestStatus == "1"){
            tvOrderViewStatus.text = getString(R.string.orderaccepted)
            tvOrderDelivered.visibility = View.GONE
        }

      if(orderDetailBean.nStatus == "1"){
          tvOrderDelivered.visibility = View.GONE
      }else if(orderDetailBean.nStatus == "2"){
          tvOrderDelivered.visibility = View.VISIBLE
      }


        tvOrderPickUpRestName.text = orderDetailBean.restaurantData.vName
        tvOrderPickUpAddress.text = orderDetailBean.restaurantData.vAddress
        tvOrderPersonName.text = orderDetailBean.customerDatumBeans.vName
        tvOrderDeliveryAddress.text = orderDetailBean.customerDatumBeans.vAddress
        tvtotalItemDetail.text = String.format(
     getString(R.string.placeholder_items), orderDetailBean.foodDatumBeans.size
        )
        tvCustomerName.text = orderDetailBean.customerDatumBeans.vName
        val spannablNumber =
            SpannableString(orderDetailBean.customerDatumBeans.vMobileNo)

        spannablNumber.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                IntentUtils.callIntent(
                    activity as BaseActivity,
                    orderDetailBean.customerDatumBeans.vMobileNo
                )
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
            }
        }, 0, spannablNumber.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        tvCustomerPhoneNumber.text = spannablNumber
        tvCustomerPhoneNumber.movementMethod = LinkMovementMethod.getInstance()
        tvCustomerPhoneNumber.highlightColor = Color.TRANSPARENT

        orderFoodItemAdapter.updateItemList(orderDetailBean.foodDatumBeans)

        when (orderDetailBean.nPaymentType) {
            "1" -> {
                tvPayment.text = getString(R.string.cod)
            }
            "2"->{
                tvPayment.text = getString(R.string.online)
            }
        }

        when (orderDetailBean.nRequestStatus) {
            "0" -> {
                llAcceptReject.visibility = View.VISIBLE
                tvOrderDelivered.visibility = View.GONE
            }
            else -> {
                if (MyAppPreferenceUtils.getUserSession(requireContext()).id == orderDetailBean.nDeliveryBoyId) {
                   // tvOrderDelivered.visibility = View.VISIBLE
                } else {
                    showOrderAlredyAccepted(requireContext())
                }

            }
        }
        nsOrderDetail.visibility = View.VISIBLE



    }

    override fun onClick(view: View) {

        when (view) {
            tvOrderAccept -> {
                showOrderPopup(requireContext(), "1")
            }
            tvOrderReject -> {
                showOrderPopup(requireContext(), "2")
            }
            tvOrderDelivered -> {
                showOrderPopup(requireContext(), "3")
            }


            rlMapPickup -> {
                var driverLocation = MyAppPreferenceUtils.getUserCurrentLocation(requireContext())
                IntentUtils.mapWithDirection(
                    activity as BaseActivity,
                    driverLocation.latitude.toString(),
                    driverLocation.longitude.toString(),
                    orderDetailBean!!.restaurantData.dLat,
                    orderDetailBean!!.restaurantData.dLng
                )
            }

            rlMapDelivery -> {
                IntentUtils.mapWithDirection(
                    activity as BaseActivity,
                    orderDetailBean!!.restaurantData.dLat,
                    orderDetailBean!!.restaurantData.dLng,
                    orderDetailBean!!.customerDatumBeans.dLat,
                    orderDetailBean!!.customerDatumBeans.dLng
                )
            }


        }
    }

    private fun showOrderAlredyAccepted(context: Context) {
        val logoutView = LayoutInflater.from(context)
            .inflate(R.layout.dialog_confirmation_one_button, null)

        val logoutAlert =
            AlertDialogUtil.createCustomAlertDialog(
                context,
                logoutView
            )

        logoutView.btnOK.text=getString(R.string.ok)
        logoutView.txtDialogMessage_.text = getString(R.string.msg_order_alredy_accept)


        logoutAlert.show()
        logoutAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        logoutView.btnOK.setOnClickListener {
            logoutAlert.dismiss()
            activity?.finish()
        }
    }

    private fun showOrderPopup(context: Context, forWhat: String) {
        val logoutView = LayoutInflater.from(context)
            .inflate(R.layout.dialog_confirmation_without_title, null)

        val logoutAlert =
            AlertDialogUtil.createCustomAlertDialog(
                context,
                logoutView
            )
        when (forWhat) {
            //Accepted
            "1" -> {
                logoutView.txtDialogMessage.text = getString(R.string.msg_order_accept)
            }
            //reject
            "2" -> {
                logoutView.txtDialogMessage.text = getString(R.string.msg_reject_order)
            }
            //delivered
            "3" -> {
                logoutView.txtDialogMessage.text = getString(R.string.msg_delivered_order)
            }

        }

        logoutView.btnNegative.text = getString(R.string.no)
        logoutView.btnPositive.text = getString(R.string.yes)
        DrawableCompat.setTint(
            logoutView.btnPositive.background,
            ContextCompat.getColor(context, R.color.icon_tint)
        )
        logoutAlert.show()
        logoutAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        logoutView.btnNegative.setOnClickListener {
            logoutAlert.dismiss()
        }

        logoutView.btnPositive.setOnClickListener {
            logoutAlert.dismiss()
            when (forWhat) {
                //Accepted
                "1" -> {
                    myOrderVM.changeOrderStatus(orderBean!!.id, NSTATUS_ACCEPT)
                    tvOrderDelivered.visibility = View.GONE
                }
                //reject
                "2" -> {
                    myOrderVM.changeOrderStatus(orderBean!!.id, NSTATUS_REJECT)
                }
                //delivered
                "3" -> {
                    myOrderVM.changeOrderStatus(orderBean!!.id, NSTATUS_DELIVERED)
                }
            }
        }
    }
}


