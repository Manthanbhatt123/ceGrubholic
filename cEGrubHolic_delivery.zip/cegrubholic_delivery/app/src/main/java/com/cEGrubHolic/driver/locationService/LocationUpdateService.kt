package com.cEGrubHolic.driver.locationService

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.google.android.gms.location.*
import com.google.gson.JsonElement


class LocationUpdateService : Service() {

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private val UPDATE_INTERVAL_IN_MILLISECONDS: Long = 15000
    private val FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2

    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLocationCallback: LocationCallback? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        try {
            startLocationUpdates()
        } catch (e: Exception) {
            Log.e("LocationUpdateService", "onStartCommand : ${e.printStackTrace()} ")
        }
        return Service.START_STICKY
    }

    override fun onDestroy() {
        Log.i("EXIT", "ondestroy!")
        val broadcastIntent = Intent(this, SensorRestarterBroadcastReceiver::class.java)
        broadcastIntent.action = Constants.ACTION_RESTART_SERVICE
        sendBroadcast(broadcastIntent)
        stopLocationUpdates()
        super.onDestroy()
    }


    private fun startLocationUpdates() {

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        val mLocationRequest = LocationRequest()
        mLocationRequest.interval = UPDATE_INTERVAL_IN_MILLISECONDS
        mLocationRequest.fastestInterval = FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        // mLocationRequest!!.smallestDisplacement = 10f

        mLocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                super.onLocationResult(locationResult)

                if (locationResult != null) {
                    Log.d(
                        "LocationUpdateService",
                        "onLocationResult : ${locationResult.lastLocation} "
                    )

                    updateLatLngToServer(locationResult.lastLocation)
                }
            }
        }

        try {
            mFusedLocationClient?.requestLocationUpdates(
                mLocationRequest,
                mLocationCallback!!,
                Looper.myLooper()
            )
        } catch (e: SecurityException) {
            Log.e("LocationUpdateService", "startLocationUpdates : ${e.printStackTrace()} ")
        }


        Log.i("LocationUpdateService", "startForegroundNotification : $ ")

        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                (notificationManager.getNotificationChannel(getString(R.string.notificationChannelForegroundLocation))).id
            } else {
                // If earlier version channel ID is not used
                // https://developer.android.com/reference/android/support/v4/app/NotificationCompat.Builder.html#NotificationCompat.Builder(android.content.Context)
                ""
            }

        val notification =
            NotificationCompat.Builder(this, channelId)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.dontTurnOffGps))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true)
                .setGroup("SERVICE")
                .setColor(ContextCompat.getColor(this, R.color.icon_tint))
                .setSmallIcon(R.drawable.ic_driver_noti)
                .build()

        notification.flags = Notification.FLAG_FOREGROUND_SERVICE

        startForeground(2, notification)
    }

    private fun stopLocationUpdates() {
        mFusedLocationClient?.removeLocationUpdates(mLocationCallback!!)
        stopForeground(true)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        //Log.i("EXIT", "ondestroy!")
        Log.i("SensorService", "onTaskRemoved: ")
        super.onTaskRemoved(rootIntent)
        val broadcastIntent = Intent(this, SensorRestarterBroadcastReceiver::class.java)
        broadcastIntent.action = Constants.ACTION_RESTART_SERVICE
        sendBroadcast(broadcastIntent)
        //stoptimertask()
    }

    private fun updateLatLngToServer(location: Location) {
        //call update lat lng api

        Log.w("LocationUpdateService", "updateLatLngToServer*********")
        if (WebServiceRetrofitUtil.webService == null) {
            WebServiceRetrofitUtil.init(this)
        }
        Log.w("LocationUpdateService", "updateLatLngToServer########")
        try {

            /*    val latitude = getLocationDecimalFormat().format(location.latitude).toDouble()
                val longitude = getLocationDecimalFormat().format(location.longitude).toDouble()*/

            val latitude = location.latitude
            val longitude = location.longitude

            if (MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).latitude == latitude
                && MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).longitude == longitude
            ) {
                return
            }

            MyAppPreferenceUtils.setUserCurrentLocation(
                applicationContext, latitude, longitude
            )

            val apiCall =
                WebServiceRetrofitUtil.webService!!.updateLatLng(latitude, longitude)

            WebServiceResponseHandler.handleApiResponse(
                apiCall,
                object : WebServiceResponseHandler.DataHandler {
                    override fun onSuccess(data: JsonElement, message: String) {
                        Log.w("LocationUpdateService", "updateLatLngToServer : $message")
                    }

                    override fun onFailure(message: String) {
                        Log.e("LocationUpdateService", "updateLatLngToServer : $message")
                    }

                    override fun noInternetConnection() {

                    }

                    override fun sessionExpired() {
                        Log.e("LocationUpdateService", "sessionExpired: stopping service" )
                        (MyAppPreferenceUtils.setServiceRunningStatus(applicationContext, false))
                        stopLocationUpdates()
                        stopSelf()

                    }

                })

        } catch (e: java.lang.NumberFormatException) {
            //catch block added because getting error

            /*
             * Fatal Exception: java.lang.NumberFormatException: For input string: "-21,528766"
             * crash reported in Huawai Mate9 & Y7 device
             */


            Log.e(
                "LocationUpdateService",
                "updateLatLngToServer : NumberFormatException : ${e.printStackTrace()} "
            )
        } catch (e: Exception) {
            Log.e("LocationUpdateService", "updateLatLngToServer : ${e.printStackTrace()} ")
        }
    }


}
