package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName

data class InitialDataBean(
    @SerializedName("GooglePlaceApiKey")
    val googlePlaceApiKey: String = "",
    @SerializedName("isActive")
    val isActive:String = "",
    @SerializedName("Orderlist")
    val orderlist: ArrayList<OrderBean> = arrayListOf()
)