package com.cEGrubHolic.driver


import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.FormValidationUtils
import com.cEGrubHolic.driver.utils.KeyboardUtils
import com.cEGrubHolic.driver.utils.LayoutUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import kotlinx.android.synthetic.main.activity_forgot_password.*

class ForgotPasswordActivity : BaseActivity(), View.OnClickListener {


    val UserAuthVM by lazy {
        ViewModelProvider(this).get(com.cEGrubHolic.driver.viewModelProviders.UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        tvForgotSend.setOnClickListener(this)
        imgForgotBack.setOnClickListener(this)

        if (!UserAuthVM.forgotPasswordApiResponseObservable.hasActiveObservers()) {
            UserAuthVM.forgotPasswordApiResponseObservable.observe(this, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            LayoutUtils.disableUI(this)
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                edtForgotEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({ finish() }, 1000)

                        }
                        ApiResponseStatus.ERROR -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                edtForgotEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            LayoutUtils.enableUI(this)
                            showSnackbar(
                                edtForgotEmail,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }

    override fun onClick(view: View) {
        when (view) {
            tvForgotSend -> {
                KeyboardUtils.hideKeyboard(this, tvForgotSend)
                if (!FormValidationUtils.isValidEmail(edtForgotEmail.text.toString().trim())) {
                    edtForgotEmail.requestFocus()
                    showSnackbar(
                        edtForgotEmail,
                        getString(R.string.error_invalid_email),
                        SnackbarUtils.SnackbarType.WARNING
                    )
                } else {
                    UserAuthVM.forgotPassword(edtForgotEmail.text.toString().trim())
                }
            }

            imgForgotBack -> {
                finish()
            }
        }

    }
}