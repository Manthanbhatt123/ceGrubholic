package com.cEGrubHolic.driver

import android.app.Activity
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.os.Bundle
import android.util.Log
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.google.firebase.crashlytics.FirebaseCrashlytics


class BaseApplication : Application() {

    var latestVersionOfApp = "0.0"

    private val activityLifecycleCallbacks = object : ActivityLifecycleCallbacks {
        override fun onActivityResumed(activity: Activity) {

            Log.i("BaseApplication", "onActivityResumed : $activity ")

            if (activity !is SplashActivity &&
                activity !is RegistrationActivity&&
                activity !is LoginActivity &&
                activity !is OtpVerificationActivity &&
                activity !is ForgotPasswordActivity &&
                activity !is TermsCondtionActivity&&
                activity !is PrivacyPolicyActivity
            ) {
                if (activity is BaseActivity) {
                    activity.checkAppVersion()

                }
            }
        }

        override fun onActivityPaused(activity: Activity) {

        }

        override fun onActivityStarted(activity: Activity) {

        }

        override fun onActivityDestroyed(activity: Activity) {

        }

        override fun onActivityStopped(activity: Activity) {

        }

        override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {

        }

        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

        }
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(activityLifecycleCallbacks)

        if (MyAppPreferenceUtils.isLoggedIn(this@BaseApplication)) {
            val userModel = MyAppPreferenceUtils.getUserSession(this@BaseApplication)
            try {
                FirebaseCrashlytics.getInstance()
                    .setCustomKey("Name", userModel.vName)
                FirebaseCrashlytics.getInstance().setCustomKey("Email", userModel.vEmail)
                FirebaseCrashlytics.getInstance().setCustomKey("UserID", userModel.id)
                FirebaseCrashlytics.getInstance()
                    .setCustomKey("BaseURL", BuildConfig.BaseURL)
                FirebaseCrashlytics.getInstance().setUserId(userModel.id)

            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            FirebaseCrashlytics.getInstance()
                .setCustomKey("BaseURL", BuildConfig.BaseURL)
        }


        //setAdvertiserIDCollectionEnabled(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            /* val notificationSoundUri: Uri =
                 Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/" + R.raw.notify)

             val notificationSoundUriForDestination: Uri =
                 Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/" + R.raw.ondestination)*/

            val audioAttributes: AudioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()


            /* val notificationChannelOnDestination = NotificationChannel(
                 getString(R.string.notificationChannelOnDestination),
                 getString(R.string.notificationChannelOnDestination),
                 NotificationManager.IMPORTANCE_DEFAULT
             )*/

            val notificationChannelGeneral = NotificationChannel(
                getString(R.string.notificationChannelGeneral),
                getString(R.string.notificationChannelGeneral),
                NotificationManager.IMPORTANCE_DEFAULT
            )

            val notifiationChannelForeground=NotificationChannel(
                getString(R.string.notificationChannelForegroundLocation),
                getString(R.string.notificationChannelForegroundLocation),
                NotificationManager.IMPORTANCE_LOW
            )


            //notificationChannelGeneral.setSound(notificationSoundUri, audioAttributes)
            // notificationChannelOnDestination.setSound(notificationSoundUriForDestination, audioAttributes)

            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager


            notificationManager.createNotificationChannel(notificationChannelGeneral)
            notificationManager.createNotificationChannel(notifiationChannelForeground)
        }

    }

    override fun onTerminate() {
        super.onTerminate()
        unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks)
    }
}