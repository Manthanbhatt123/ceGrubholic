package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class RestaurantData(
    @SerializedName("dLat")
    val dLat: String = "",
    @SerializedName("dLng")
    val dLng: String = "",
    @SerializedName("vAddress")
    val vAddress: String = "",
    @SerializedName("vName")
    val vName: String = ""
):Serializable