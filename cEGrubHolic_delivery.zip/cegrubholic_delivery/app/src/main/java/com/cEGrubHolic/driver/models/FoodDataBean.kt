package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class FoodDataBean(
    @SerializedName("dProductPrice")
    val dProductPrice: String="",
    @SerializedName("nProductId")
    val nProductId: String="",
    @SerializedName("nQty")
    val nQty: String="",
    @SerializedName("vProductName")
    val vProductName: String=""
):Serializable