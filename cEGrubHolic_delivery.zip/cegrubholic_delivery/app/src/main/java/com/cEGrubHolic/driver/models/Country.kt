package com.cEGrubHolic.driver.models

import android.text.TextUtils
import java.io.Serializable


data class Country(var code: String, var name: String, var dialCode: String) : Serializable,
    Comparator<Country> {
    override fun compare(s1: Country, s2: Country): Int {
        return if (TextUtils.isEmpty(s1.name) || TextUtils.isEmpty(s2.name)) {
            0
        } else s1.name.trim().compareTo(s2.name.trim())
    }
    override fun toString(): String {
        return "$dialCode - $name"
    }
}
