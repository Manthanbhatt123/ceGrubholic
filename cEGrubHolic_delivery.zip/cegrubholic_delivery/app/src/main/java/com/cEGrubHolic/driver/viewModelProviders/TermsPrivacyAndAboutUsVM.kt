package com.cEGrubHolic.driver.viewModelProviders

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.driver.network.ApiResponse
import com.cEGrubHolic.driver.network.Event
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.google.gson.JsonElement


class TermsPrivacyAndAboutUsVM : ViewModel() {

    val apiTermsObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getTermsCondition() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getTermsCondition()

        apiTermsObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    apiTermsObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    apiTermsObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    apiTermsObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    apiTermsObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val apiPrivacyObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getPrivacPolicy() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getPrivacPolicy()

        apiPrivacyObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    apiPrivacyObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    apiPrivacyObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    apiPrivacyObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    apiPrivacyObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

   /* val apiAboutObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun getAboutUs() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getAboutUs()

        apiAboutObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    apiAboutObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    apiAboutObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    apiAboutObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    apiAboutObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }*/
}