package com.cEGrubHolic.driver.fragment

import android.app.ProgressDialog
import android.content.Intent
import android.os.Build
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.cEGrubHolic.driver.BaseActivity
import com.cEGrubHolic.driver.LoginActivity
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.utils.*


open class BaseFragment : Fragment() {

    fun showShortToast(msg: String) {
        Toast.makeText(context!!, msg, Toast.LENGTH_SHORT).show()
    }

    fun showLongToast(msg: String) {
        Toast.makeText(context!!, msg, Toast.LENGTH_LONG).show()
    }

    fun destroyLoginSession(isDisplayMsg: Boolean) {
        hideProgress()
        if (isDisplayMsg)
            showShortToast(getString(R.string.msg_session_expire))
        MyAppPreferenceUtils.clearLoginSession(activity!!)
        (activity as BaseActivity).stopInAppLocationUpdates()
        (activity as BaseActivity).stopLocationUpdateService()
        activity!!.finish()
        val intent = Intent(activity, LoginActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)

    }

    /*fun logoutFacebook(){
        val accessToken = AccessToken.getCurrentAccessToken()
        val isLoggedIn = accessToken != null && !accessToken.isExpired
        if (isLoggedIn) {
            LoginManager.getInstance().logOut()
        }
    }*/


    fun showSnackbar(view: View, msg: String, type: SnackbarUtils.SnackbarType) {
        when (type) {

            SnackbarUtils.SnackbarType.SUCCESS -> {
                SnackbarUtils.success(activity!! as AppCompatActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.WARNING -> {
                SnackbarUtils.warning(activity!! as AppCompatActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.ERROR -> {
                SnackbarUtils.error(activity!! as AppCompatActivity, view, msg)
            }
        }
    }

    var progressDialog: ProgressDialog? = null

    fun showProgress(msg: String, cancelable: Boolean) {
        ProgressDialogWithCustomLoader.showProgressDialog(context!!, "", msg, cancelable)
    }

    fun hideProgress() {
        ProgressDialogWithCustomLoader.dismissProgressDialog()
    }

    fun setLightStatusBarWhite() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            var flags = (activity as BaseActivity).window.decorView.systemUiVisibility
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            //flags = flags or 0
            (activity as BaseActivity).window.decorView.systemUiVisibility = flags
            (activity as BaseActivity).window.statusBarColor =
                (activity as BaseActivity).getColor(R.color.white)
        }
    }

    fun setLightStatusBarRed() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            var flags = (activity as BaseActivity).window.decorView.systemUiVisibility
            //flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            flags = flags or 0
            (activity as BaseActivity).window.decorView.systemUiVisibility = flags
            (activity as BaseActivity).window.statusBarColor =
                (activity as BaseActivity).getColor(R.color.black)
        }
    }




}