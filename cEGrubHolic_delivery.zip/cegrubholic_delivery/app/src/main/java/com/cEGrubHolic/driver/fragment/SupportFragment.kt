package com.cEGrubHolic.driver.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.ReviwesModel
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.IntentUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_home.*
import kotlinx.android.synthetic.main.fragment_home.imgProfileHome
import kotlinx.android.synthetic.main.fragment_ratings.*
import kotlinx.android.synthetic.main.fragment_support.*

class SupportFragment : BaseFragment() {
    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_support, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!myOrderVM.contactUsObservable.hasActiveObservers()) {
            myOrderVM.contactUsObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {
                    when (it?.status) {
                        ApiResponseStatus.LOADING -> {
                           showProgress(getString(R.string.progress_please_wait),false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                          hideProgress()
                            edtDescription.setText("")
                            showSnackbar(
                                btnContectUs,
                               it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                btnContectUs,
                              it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnContectUs,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
        btnContectUs.setOnClickListener {
            if (edtDescription.text.toString().trim().isEmpty()){
                showSnackbar(
                    btnContectUs,
                    getString(R.string.please_enter_msg),
                    SnackbarUtils.SnackbarType.ERROR
                )
            }else{
                myOrderVM.contactUs(edtDescription.text.toString().trim())
            }
        }
        btnCallus.setOnClickListener {
            IntentUtils.callIntent(requireActivity(),Constants.SUPPORT_CONTECT_NO)
        }
    }


}