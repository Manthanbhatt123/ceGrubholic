package com.cEGrubHolic.driver.fragment


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.adapter.ReviwesListAdepter
import com.cEGrubHolic.driver.models.InitialDataBean
import com.cEGrubHolic.driver.models.ReviwesModel
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_ratings.*


class RatingsFragment : BaseFragment(), ReviwesListAdepter.ItemClickListener {

    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }

    val getRatingList = arrayListOf<ReviwesModel>()
    var getRatingListAdepter: ReviwesListAdepter = ReviwesListAdepter(getRatingList, this)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_ratings, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerReviewList.visibility = View.GONE



        if (!myOrderVM.getRatingAndReviewObservable.hasActiveObservers()) {
            myOrderVM.getRatingAndReviewObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            refreshRatingScreen.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            refreshRatingScreen.isRefreshing = false
                            getRatingList.clear()
                            getRatingList.addAll(
                                Gson().fromJson(
                                    it.data,
                                    object : TypeToken<List<ReviwesModel>>() {}.type
                            )
                            )
                            recyclerReviewList.adapter = getRatingListAdepter
                            showDetailView(true, "")
                        }
                        ApiResponseStatus.ERROR -> {
                            refreshRatingScreen.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            refreshRatingScreen.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            refreshRatingScreen.isRefreshing = false
                            showDetailView(false, getString(R.string.no_internet))
                        }
                    }

                }
            })
        }
        refreshRatingScreen.setOnRefreshListener {
            myOrderVM.getRatingAndReview()
        }
        myOrderVM.getRatingAndReview()
    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtErrorOrderLists.text = errorMsg

        if (isDataAvailable) {
            imgNoDataFoundOrderLists.visibility = View.GONE
            recyclerReviewList.visibility = View.VISIBLE
        } else {
            imgNoDataFoundOrderLists.visibility = View.VISIBLE
            recyclerReviewList.visibility = View.GONE
        }
    }

    override fun onItemClicked(onPosition: ReviwesModel) {


    }


}