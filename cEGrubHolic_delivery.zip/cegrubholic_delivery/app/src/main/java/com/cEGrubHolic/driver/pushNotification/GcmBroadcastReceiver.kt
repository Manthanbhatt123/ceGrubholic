package com.cEGrubHolic.driver.pushNotification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.cEGrubHolic.driver.utils.Constants
import org.json.JSONObject

/**
 * Created by Ashish on 13/12/19.
 */
class GcmBroadcastReceiver : BroadcastReceiver() {

    private val TAG = "GcmBroadcastReceiver"

    override fun onReceive(context: Context, intentData: Intent) {

        try {

            Log.d(TAG, "onReceive: " + intentData.component!!.packageName
                        + "\n" + intentData.extras)

            Log.d(TAG, "onReceive: " + intentData.component!!.packageName
                    + "\n" +"pushtype: "+ intentData.extras!!.get(Constants.KEY_NOTIFICATION_nPushType)
                    + "\n" +"other: "+ intentData.extras!!.get(Constants.KEY_NOTIFICATION_vOther)
                    + "\n" +"order id: "+ intentData.extras!!.get(Constants.KEY_NOTIFICATION_nId))
                   // + "\n" +"isSlientRequired"+ intentData.extras!!.get(Constants.KEY_NOTIFICATION_vOther_isSlientRequired))

            val comp = intentData.component!!.packageName

            if (comp == context.packageName
                && intentData.extras != null
            ) {
                val intent = Intent()

                //extra payload for silently update App UI without sending notification

                val notificationDataBundle = Bundle()

                if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_nPushType)) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_nPushType,
                        intentData.extras!!.getString(Constants.KEY_NOTIFICATION_nPushType)
                    )

                }

                if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_nId)) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_nId,
                        intentData.extras!!.getString(Constants.KEY_NOTIFICATION_nId)
                    )
                }

                val vOtherJson =
                    if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_vOther)
                        && !intentData.extras!!.getString(Constants.KEY_NOTIFICATION_vOther).isNullOrBlank()
                    ) {
                        JSONObject(intentData.extras!!.getString(Constants.KEY_NOTIFICATION_vOther))
                    } else {
                        null
                    }


                if (vOtherJson != null) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_vOther,
                        vOtherJson.toString()
                    )
                }

                intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
                intent.action = Constants.INTENT_ACTION_NOTIFICATION

                //context.sendBroadcast(intent)
               /* val isSilentPush = if (vOtherJson != null) {
                    vOtherJson.has(Constants.KEY_NOTIFICATION_vOther_isSlientRequired)
                            && vOtherJson[Constants.KEY_NOTIFICATION_vOther_isSlientRequired] == 1
                } else {
                    false
                }*/

                val isSilentPush =false

                if (isSilentPush || ( intentData.extras!!.getString(Constants.KEY_NOTIFICATION_nPushType)==Constants.nPushType_rideRequest)
                ) {
                    context.sendBroadcast(intent)
                }

            }
        } catch (e: Exception) {
            Log.e(TAG, "onReceive : ${e.printStackTrace()} ")
        }
    }
}