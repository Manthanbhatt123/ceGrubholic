package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OrderBean(
    @SerializedName("dGrandTotal")
    val dGrandTotal: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nTotalItems")
    val nTotalItems: String = "",
    @SerializedName("vOrderId")
    val vOrderId: String = "",
    @SerializedName("dOrderAssignDate")
    val dOrderAssignDate:String="",
    @SerializedName("nStatus")
    val nStatus:String="",
    @SerializedName("nRequestStatus")
    val nRequestStatus:String="",
    @SerializedName("nPreparationTime")
    val nPreparationTime: String = ""
) : Serializable