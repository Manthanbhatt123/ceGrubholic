package com.cEGrubHolic.driver.fragment

import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.FormValidationUtils
import com.cEGrubHolic.driver.utils.KeyboardUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import kotlinx.android.synthetic.main.fragment_change_password.*



class ChangePasswordFragment : BaseFragment(), View.OnClickListener {

    val userAuthVM by lazy {
        ViewModelProvider(this).get(com.cEGrubHolic.driver.viewModelProviders.UserAuthVM::class.java)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_change_password, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setViewResponseModel()
        tvChangePasswordSave.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view) {
            tvChangePasswordSave -> {
                if (activity != null) {
                    KeyboardUtils.hideKeyboard(activity!!, tvChangePasswordSave)
                    if (isValidData()) {
                        userAuthVM.changePassword(
                            edoldPassword.text.toString().trim(),
                            edNewPassword.text.toString().trim()
                        )
                    }
                }
            }

        }
    }

    private fun isValidData(): Boolean {
        if (!FormValidationUtils.isValidPassword(edoldPassword.text.toString())) {
            edoldPassword.requestFocus()
            showSnackbar(
                edoldPassword,
                getString(R.string.error_old_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPasswordLength(
                edoldPassword.text.toString().trim(),
                8
            )
        ) {
            edoldPassword.requestFocus()
            showSnackbar(
                edoldPassword,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(edNewPassword.text.toString())) {
            edNewPassword.requestFocus()
            showSnackbar(
                edNewPassword,
                getString(R.string.error_new_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPasswordLength(
                edNewPassword.text.toString().trim(),
                8
            )
        ) {
            edNewPassword.requestFocus()
            showSnackbar(
                edNewPassword,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(edretypePassword.text.toString())) {
            edretypePassword.requestFocus()
            showSnackbar(
                edretypePassword,
                getString(R.string.error_invalid_re_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPasswordLength(
                edretypePassword.text.toString().trim(),
                8
            )
        ) {
            edretypePassword.requestFocus()
            showSnackbar(
                edretypePassword,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidRePassword(
                edNewPassword.text.toString().trim(),
                edretypePassword.text.toString().trim()
            )
        ) {
            showSnackbar(
                edretypePassword,
                getString(R.string.error_mismatch_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.changePasswordObservable.hasActiveObservers()) {
            userAuthVM.changePasswordObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                edoldPassword,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({ if (activity != null) {
                                activity!!.supportFragmentManager.popBackStack()
                            } }, 1000)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                edoldPassword,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                edoldPassword,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }


}