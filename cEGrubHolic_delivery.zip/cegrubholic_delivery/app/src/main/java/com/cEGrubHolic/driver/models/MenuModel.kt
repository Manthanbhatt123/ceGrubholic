package com.cEGrubHolic.driver.models

import java.io.Serializable

class MenuModel(
    val menuName: Int = 0
) : Serializable {

    var isSelected = false
}