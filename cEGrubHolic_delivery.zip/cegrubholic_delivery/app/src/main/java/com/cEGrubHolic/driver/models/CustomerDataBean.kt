package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class CustomerDataBean(
    @SerializedName("dLat")
    val dLat: String="",
    @SerializedName("dLng")
    val dLng: String="",
    @SerializedName("vAddress")
    val vAddress: String="",
    @SerializedName("vName")
    val vName: String="",
    @SerializedName("vMobileNo")
    val vMobileNo:String=""
):Serializable