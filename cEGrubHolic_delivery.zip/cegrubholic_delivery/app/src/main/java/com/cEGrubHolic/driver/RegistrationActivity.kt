package com.cEGrubHolic.driver

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.UnderlineSpan
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.Constants.REGISTRATION_IMAGE_REQ_CODE
import com.github.dhaval2404.imagepicker.ImagePicker
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_registration.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File


class RegistrationActivity : BaseActivity(), View.OnClickListener {

    var selectedProfileFile: File? = null

    val userAuthVM by lazy {
        ViewModelProvider(this).get(com.cEGrubHolic.driver.viewModelProviders.UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)
        setViewResponseModel()
        setSpan()

        Glide.with(this)
            .applyDefaultRequestOptions(RequestOptions.placeholderOf(R.drawable.ic_profile_placeholder))
            .load(R.drawable.ic_profile_placeholder)
            .into(imgProfileUser)

        tvRegister.setOnClickListener(this)
        imgProfileUser.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view) {
            tvRegister -> {
                KeyboardUtils.hideKeyboard(this, tvRegister)
                if (isValidForm()) {
                    val multipartArray = arrayListOf<MultipartBody.Part>()

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vName",
                            edRegName.text.toString().trim()
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vEmail",
                            edRegEmail.text.toString().trim()
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vMobileNo",
                            edRegMobileNo.text.toString().trim()
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vVehicleNo",
                            edRegVehicleNo.text.toString().trim()
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vPassword",
                            edRegPassword.text.toString().trim()
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "nLoginDeviceType",
                            Constants.NLOGINDEVICE_TYPE_ANDROID
                        )
                    )

                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vPushToken",
                            MyAppPreferenceUtils.getPushToken(this)
                        )
                    )
                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vCountryCode",
                            "+91"
                        )
                    )
                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vCountryISOCode",
                            "in"
                        )
                    )

                    if (selectedProfileFile != null)
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vImagePath",
                                selectedProfileFile!!.name,
                                RequestBody.create(MediaType.parse("image/*"), selectedProfileFile)
                            )
                        )


                    userAuthVM.signUp(
                        multipartArray
                    )
                }
            }

            imgProfileUser -> {
                if (Build.VERSION.SDK_INT < 23) {
                    ImagePicker.with(this)
                        .crop()
                        .setImageProviderInterceptor { imageProvider -> // Intercept ImageProvider
                            Log.d(
                                "ImagePicker",
                                "Selected ImageProvider: " + imageProvider.name
                            )
                        }
                        .setDismissListener {
                            Log.d("ImagePicker", "Dialog Dismiss")
                        }
                        .start(REGISTRATION_IMAGE_REQ_CODE)
                    /*CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        //.setFixAspectRatio(true)
                        .start(this)*/
                } else {
                    checkAndAskStoragePermission { isStoragePermissionGranted ->
                        if (isStoragePermissionGranted) {
                            checkAndAskCameraPermission { isCameraPermissionGranted ->
                                if (isCameraPermissionGranted) {
                                    /*CropImage.activity()
                                        .setGuidelines(CropImageView.Guidelines.ON)
                                        .setFixAspectRatio(true)
                                        .start(this)*/
                                    ImagePicker.with(this)
                                        .crop()
                                        .setImageProviderInterceptor { imageProvider -> // Intercept ImageProvider
                                            Log.d(
                                                "ImagePicker",
                                                "Selected ImageProvider: " + imageProvider.name
                                            )
                                        }
                                        .setDismissListener {
                                            Log.d("ImagePicker", "Dialog Dismiss")
                                        }
                                        .start(REGISTRATION_IMAGE_REQ_CODE)
                                }
                            }
                        }
                    }
                }

            }
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.signUpApiResponseObservable.hasActiveObservers()) {

            userAuthVM.signUpApiResponseObservable.observe(this, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            LayoutUtils.disableUI(this)
                            showProgress(getString(R.string.progress_please_wait), false)

                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                imgProfileUser,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                            MyAppPreferenceUtils.saveUserSession(
                                this@RegistrationActivity, Gson().fromJson(
                                    it.data,
                                    object : TypeToken<UserSessionBean>() {}.type
                                )
                            )

                            val savedUserSession =
                                MyAppPreferenceUtils.getUserSession(this@RegistrationActivity)

                            MyAppPreferenceUtils.saveToken(
                                this@RegistrationActivity,
                                savedUserSession.vApiToken
                            )
                            //MyAppPreferenceUtils.setLoggedIn(this@RegistrationActivity, true)
                            var vLanguage = savedUserSession.vLanguage
                            if (vLanguage.isNotEmpty() && vLanguage.isNotBlank()) {
                                MyAppPreferenceUtils.setAppLanguage(
                                    this,
                                    savedUserSession.vLanguage
                                )
                            } else {
                                MyAppPreferenceUtils.setAppLanguage(
                                    this,
                                    Constants.AppLanguages_SPANISH[1].languageCode
                                )
                            }
                            WebServiceRetrofitUtil.destroyInstance() //for replacing old token with new one
                            WebServiceRetrofitUtil.init(this)

                            startActivity(
                                Intent(
                                    this,
                                    OtpVerificationActivity::class.java
                                ).putExtra(Constants.USERMODEL, savedUserSession)
                            )


                        }
                        ApiResponseStatus.ERROR -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                imgProfileUser,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            //destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            LayoutUtils.enableUI(this)
                            showSnackbar(
                                imgProfileUser,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                    }

                }
            })
        }
    }

    private fun setSpan() {
        val spannablDonTAccountString =
            SpannableString(getString(R.string.msg_already_account))

        spannablDonTAccountString.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                finish()
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
            }
        }, 25, spannablDonTAccountString.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannablDonTAccountString.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    this@RegistrationActivity,
                    R.color.icon_tint
                )
            ), 25, spannablDonTAccountString.length, 0
        )


        val spannablTCString = SpannableString(getString(R.string.msg_accept_terms) + " ")

        spannablTCString.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                startActivity(
                    Intent(this@RegistrationActivity, TermsCondtionActivity::class.java)
                )
                animateEnterTransition()
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
            }
        }, 15, 35, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        spannablTCString.setSpan(
            ForegroundColorSpan(Color.BLACK),
            15, 35,
            Spannable.SPAN_EXCLUSIVE_INCLUSIVE
        )

        spannablTCString.setSpan(
            UnderlineSpan(),
            15, 35,
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )


        spannablTCString.setSpan(
            StyleSpan(Typeface.BOLD),
            15,
            35,
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )


        spannablTCString.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                startActivity(
                    Intent(this@RegistrationActivity, PrivacyPolicyActivity::class.java)
                )
                animateEnterTransition()
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
            }
        }, 40, spannablTCString.length - 1, Spannable.SPAN_INCLUSIVE_INCLUSIVE)

        spannablTCString.setSpan(
            ForegroundColorSpan(Color.BLACK),
            40, spannablTCString.length - 1,
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )

        spannablTCString.setSpan(
            UnderlineSpan(),
            40, spannablTCString.length - 1,
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )

        spannablTCString.setSpan(
            StyleSpan(Typeface.BOLD),
            40,
            spannablTCString.length - 1,
            Spannable.SPAN_INCLUSIVE_INCLUSIVE
        )



        tvmsgTerms.text = spannablTCString
        tvmsgTerms.movementMethod = LinkMovementMethod.getInstance()
        tvmsgTerms.highlightColor = Color.TRANSPARENT


        tvSignIn.text = spannablDonTAccountString
        tvSignIn.movementMethod = LinkMovementMethod.getInstance()
        tvSignIn.highlightColor = Color.TRANSPARENT


    }


    private fun isValidForm(): Boolean {
        /* if (selectedProfileFile == null) {
             edRegName.requestFocus()
             showSnackbar(
                 edRegName,
                 getString(R.string.error_invalid_profile_pic),
                 SnackbarUtils.SnackbarType.WARNING
             )
             return false
         } else*/ if (!FormValidationUtils.isValidText(edRegName.text.toString().trim())) {
            edRegName.requestFocus()
            showSnackbar(
                edRegName,
                getString(R.string.error_invalid_name),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidEmail(edRegEmail.text.toString().trim())) {
            edRegEmail.requestFocus()
            showSnackbar(
                edRegEmail,
                getString(R.string.error_invalid_email),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPhone(edRegMobileNo.text.toString().trim())) {
            edRegMobileNo.requestFocus()
            showSnackbar(
                edRegMobileNo,
                getString(R.string.error_invalid_mob_no),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(edRegVehicleNo.text.toString().trim())) {
            edRegVehicleNo.requestFocus()
            showSnackbar(
                edRegVehicleNo,
                getString(R.string.error_empty_vehicle_no),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(edRegPassword.text.toString().trim())) {
            edRegPassword.requestFocus()
            showSnackbar(
                edRegPassword,
                getString(R.string.error_invalid_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPasswordLength(
                edRegPassword.text.toString().trim(),
                8
            )
        ) {
            edRegPassword.requestFocus()
            showSnackbar(
                edRegPassword,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(
                edRegConfirmPassword.text.toString().trim()
            )
        ) {
            edRegConfirmPassword.requestFocus()
            showSnackbar(
                edRegConfirmPassword,
                getString(R.string.error_invalid_confirm_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPasswordLength(
                edRegConfirmPassword.text.toString().trim(),
                8
            )
        ) {
            edRegConfirmPassword.requestFocus()
            showSnackbar(
                edRegConfirmPassword,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidRePassword(
                edRegPassword.text.toString().trim(),
                edRegConfirmPassword.text.toString().trim()
            )
        ) {
            showSnackbar(
                edRegConfirmPassword,
                getString(R.string.error_mismatch_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!chkTermsBording.isChecked) {
            showSnackbar(
                edRegEmail,
                getString(R.string.msg_accept_tc),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {

                REGISTRATION_IMAGE_REQ_CODE -> {
                    if (data != null) {
                        val uri: Uri = data?.data!!
                        selectedProfileFile = File(uri.path)
                        imgProfileUser.visibility = View.VISIBLE
                        Glide.with(this)
                            .applyDefaultRequestOptions(RequestOptions.placeholderOf(R.drawable.ic_profile_placeholder))
                            .load(selectedProfileFile)
                            .into(imgProfileUser)
                    }
                }

                /*CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE -> {
                    val cropResult = CropImage.getActivityResult(data)
                    if (data != null) {
                        selectedProfileFile = File(cropResult.uri.path)
                        imgProfileUser.visibility = View.VISIBLE
                        Glide.with(this)
                            .applyDefaultRequestOptions(RequestOptions.placeholderOf(R.drawable.ic_profile_placeholder))
                            .load(selectedProfileFile)
                            .into(imgProfileUser)

                    } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                        val error = cropResult.error

                        try {
                            showSnackbar(
                                imgProfileUser,
                                error.message!!,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        } catch (e: Exception) {
                            Log.e(
                                "RegistrationActivity",
                                "onActivityResult : ${e.printStackTrace()} "
                            )
                        }
                    }
                }*/
            }

        }
        super.onActivityResult(requestCode, resultCode, data)
    }


}