package com.cEGrubHolic.driver

import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.LayoutUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import kotlinx.android.synthetic.main.activity_privacy_policy_driver.*


class PrivacyPolicyDriverActivity : BaseActivity() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_policy_driver)

      //  clearLightStatusBar()
        imagedriverBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        userViewModel.privacyPolicy()


        if (!userViewModel.privacyPolicyApiObservable.hasActiveObservers()) {
            userViewModel.privacyPolicyApiObservable.observe(this, Observer {

                when (it?.status) {
                    ApiResponseStatus.LOADING -> {
                        showProgress(getString(R.string.loding), false)
                    }

                    ApiResponseStatus.SUCCESS -> {
                        hideProgress()

                        var termsText = (it.data!!.asJsonObject).get("vDesc").asString
                        termsText.replace("&#39;", "'")
                        wvPrivacyPolicy.settings.javaScriptEnabled = true
                        // show # from html string
                        wvPrivacyPolicy.loadDataWithBaseURL(null, termsText, "text/html", "UTF-8", null)
                    }

                    ApiResponseStatus.ERROR -> {
                        hideProgress()
                        showSnackbar(
                            wvPrivacyPolicy,
                            it.message,
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                    ApiResponseStatus.SESSION_EXPIRED -> {
                        LayoutUtils.enableUI(this)
                        hideProgress()

                    }

                    ApiResponseStatus.NO_INTERNET -> {
                        LayoutUtils.enableUI(this)
                        hideProgress()
                        showSnackbar(
                            wvPrivacyPolicy,
                            getString(R.string.no_internet),
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                }

            })
        }

        /*    userViewModel.getPrivacPolicy()

            if (!userViewModel.apiPrivacyObservable.hasActiveObservers()) {
                userViewModel.apiPrivacyObservable.observe(this, Observer {

                    when (it?.status) {
                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }

                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            var termsText = (it.data!!.asJsonObject).get("vDesc").asString
                            termsText.replace("&#39;", "'")
                            wvPrivacyPolicy.settings.javaScriptEnabled = true
                            // show # from html string
                            wvPrivacyPolicy.loadDataWithBaseURL(null, termsText, "text/html", "UTF-8", null)
                        }

                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                tvDescPrivacy,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                        ApiResponseStatus.SESSION_EXPIRED -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            destroyLoginSession()

                        }

                        ApiResponseStatus.NO_INTERNET -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                tvDescPrivacy,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                    }

                })
            }*/
    }
}