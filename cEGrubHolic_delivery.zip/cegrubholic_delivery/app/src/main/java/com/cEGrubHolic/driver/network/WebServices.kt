package com.cEGrubHolic.driver.network


import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*


/**
 * Created by Ashish on 7/3/19.
 */
interface WebServices {

    companion object {


        const val driver = "Deliveryboy/"


        const val AUTH_SIGNUP = driver + "Signup"
        const val LOGIN = driver + "login"
        const val AUTH_FORGOT_PASSWORD = driver + "forgotPassword"
        const val RESEND_OTP = driver + "resentOTP"

        const val GENERAL_GET_PRIVACY_POLICY = driver + "getPrivacyAndPolicy"
        const val GENERAL_GET_TERMS = driver + "getTermAndCondition"
        const val GET_PRIVACY_POLICY = driver + "getPrivacyPolicy"
        const val GET_TERMS = driver + "getTerms"


        const val GENERAL_UPDATE_PROFILE= driver+ "updateProfile"
        const val AUTH_LOG_OUT = driver + "logout"
        const val AUTH_CHANGE_PASSWORD = driver + "changePassword"
        const val AUTH_EDIT_PROFILE = driver + "updateProfile"
        const val AUTH_GET_PROFILE_DATA = driver + "getProfileDetails"

        const val GENERAL_CHECK_VERSION = driver + "checkAppVersion"

        const val GENERAL_GET_INITIAL_DATA = driver + "getInitialData"
        const val GENERAL_GET_HISTORY_ORDER = driver + "getOrderHistorylist"
        const val GENERAL_GET_ORDER_DETAILS = driver + "getOrderDetails"
        const val GENERAL_CHANGE_ORDER_STATUS = driver + "changeOrderStatus"
        const val GENERAL_UPDATE_LATLNG= driver+"updateLatLng"

        const val GET_RATING_AND_REVIEWS = driver + "getReviewList"
        const val CONTECT_US = driver + "contactUs"
        const val DRIVER_ERNING_DATA = driver + "driverEarningData"

    }


    @Multipart
    @POST(AUTH_SIGNUP)
    fun SignUp(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(LOGIN)
    fun login(
        @Field("vEmail") vEmail: String,
        @Field("vPassword") vPassword: String,
        @Field("nLoginDeviceType") nLoginDeviceType: String,
        @Field("vPushToken") vPushToken: String
        //@Field("vPushToken") vPushToken: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @FormUrlEncoded
    @POST(AUTH_FORGOT_PASSWORD)
    fun forgotPassword(
        @Field("vEmail") vEmail: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @GET(GENERAL_GET_TERMS)
    fun getTermsCondition(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_RATING_AND_REVIEWS)
    fun getRatingAndReview(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(CONTECT_US)
    fun contactUs(
        @Field("vMessage") vMessage: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_GET_PRIVACY_POLICY)
    fun getPrivacPolicy(): Call<WebServiceResponseHandler.ResponseBody>


    @GET(RESEND_OTP)
    fun resentOTP(): Call<WebServiceResponseHandler.ResponseBody>


    @GET(AUTH_LOG_OUT)
    fun logout(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_PRIVACY_POLICY)
    fun privacyPolicy(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(AUTH_CHANGE_PASSWORD)
    fun changePassword(
        @Field("vOldPassword") vOldPassword: String,
        @Field("vNewPassword") vNewPassword: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_TERMS)
    fun getTerms(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(AUTH_GET_PROFILE_DATA)
    fun getProfileDetails(): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(AUTH_EDIT_PROFILE)
    fun editProfile(@Part fields: ArrayList<MultipartBody.Part>): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(AUTH_FORGOT_PASSWORD)
    fun getLatestApkVersion(
        @Field("nAppType") vEmail: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @FormUrlEncoded
    @POST(GENERAL_CHECK_VERSION)
    fun checkAppVersion(
        @Field("nAppType") nAppType: String,
        @Field("nRecordFor") nRecordFor: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_GET_INITIAL_DATA)
    fun getInitialData(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_GET_HISTORY_ORDER)
    fun getHistoryOrder(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GENERAL_GET_ORDER_DETAILS)
    fun getOrderDetails(
        @Field("nOrderId") nOrderId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GENERAL_CHANGE_ORDER_STATUS)
    fun changeOrderStatus(
        @Field("nOrderId") nOrderId: String,
        @Field("nStatus") nStatus: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @FormUrlEncoded
    @POST(GENERAL_UPDATE_PROFILE)
    fun updateProfile(
        @Field("isActive") isActive: String,
        @Field("vLanguage") vLanguage: String,
        @Field("isMobileVerified") isMobileVerified: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GENERAL_UPDATE_LATLNG)
    fun updateLatLng(
        @Field("dLat") dLat: Double,
        @Field("dLng") dLng: Double
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(DRIVER_ERNING_DATA)
    fun vDriverErning(
        @Field("dStartDate") dStartDate : String,
        ): Call<WebServiceResponseHandler.ResponseBody>


}