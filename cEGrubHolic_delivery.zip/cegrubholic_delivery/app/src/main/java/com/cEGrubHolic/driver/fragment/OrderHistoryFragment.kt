package com.cEGrubHolic.driver.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.adapter.OrderHistoryAdapter
import com.cEGrubHolic.driver.models.HistoryOrderBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.MyOrderVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_order_history.*


class OrderHistoryFragment : BaseFragment() {

    val myOrderVM by lazy {
        ViewModelProvider(this).get(MyOrderVM::class.java)
    }

    var listOfHistoryOrder= arrayListOf<HistoryOrderBean>()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_order_history, container, false)
    }

    private val orderHistoryAdapter by lazy {
        OrderHistoryAdapter(arrayListOf())
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setViewResponseModel()
        rvHistoryOrder.adapter = orderHistoryAdapter
        myOrderVM.getHistoryOrder()
        swipeRefreshHistory.setOnRefreshListener {
            myOrderVM.getHistoryOrder()
        }
    }

    private fun setViewResponseModel() {
        if (!myOrderVM.getHistoryOrderObservable.hasActiveObservers()) {
            myOrderVM.getHistoryOrderObservable.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swipeRefreshHistory.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            swipeRefreshHistory.isRefreshing = false
                            listOfHistoryOrder.clear()
                            listOfHistoryOrder.addAll(
                                Gson().fromJson(
                                it.data,
                                object : TypeToken<ArrayList<HistoryOrderBean>>() {}.type
                            ))
                            orderHistoryAdapter.updateOrderList(listOfHistoryOrder)
                            showDetailView(true, "")
                        }
                        ApiResponseStatus.ERROR -> {
                            swipeRefreshHistory.isRefreshing = false
                            showDetailView(false, it.message)
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            swipeRefreshHistory.isRefreshing = false
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swipeRefreshHistory.isRefreshing = false
                            showSnackbar(
                                swipeRefreshHistory,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtErrorHistoryOrderList.text = errorMsg

        if (isDataAvailable) {
            imgNoDataFoundHistoryOrderList.visibility = View.GONE
            rvHistoryOrder.visibility = View.VISIBLE
        } else {
            rvHistoryOrder.visibility = View.GONE
            imgNoDataFoundHistoryOrderList.visibility = View.VISIBLE


        }
    }


}