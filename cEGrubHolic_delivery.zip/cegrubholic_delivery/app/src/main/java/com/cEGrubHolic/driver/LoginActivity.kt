package com.cEGrubHolic.driver

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.Constants.NLOGINDEVICE_TYPE_ANDROID
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : BaseActivity(), View.OnClickListener {
    val userAuthVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        setViewResponseModel()
        tvLoginForgotPassword.setOnClickListener(this)
        tvLoginSignin.setOnClickListener(this)
        edtLoginPwd.setOnEditorActionListener(TextView.OnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                tvLoginSignin.performClick()
            }
            false
        })
        setSpan()
    }

    private fun setSpan() {
        val spannablDonTAccountString =
            SpannableString(getString(R.string.msg_don_t_account))
        spannablDonTAccountString.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                startActivity(Intent(this@LoginActivity, RegistrationActivity::class.java))
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.isUnderlineText = true
            }
        }, 24, spannablDonTAccountString.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannablDonTAccountString.setSpan(
            ForegroundColorSpan(
                ContextCompat.getColor(
                    this@LoginActivity,
                    R.color.icon_tint
                )
            ), 24, spannablDonTAccountString.length, 0
        )
        tvRegistration.text = spannablDonTAccountString
        tvRegistration.movementMethod = LinkMovementMethod.getInstance()
        tvRegistration.highlightColor = Color.TRANSPARENT
    }

    override fun onClick(view: View) {
        when (view) {
            tvLoginForgotPassword -> {
                val intent = Intent(this, ForgotPasswordActivity::class.java)
                startActivity(intent)
            }
            tvLoginSignin -> {
                KeyboardUtils.hideKeyboard(this, tvLoginSignin)
                if (isValidForm()) {
                    userAuthVM.getLoggedIn(
                        edtLoginEmail.text.toString().trim(),
                        edtLoginPwd.text.toString().trim(),
                        NLOGINDEVICE_TYPE_ANDROID,
                        MyAppPreferenceUtils.getPushToken(this)
                    )
                }
            }
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.loginObserver.hasActiveObservers()) {
            userAuthVM.loginObserver.observe(this, Observer { it ->
                it.getContentIfNotHandled()?.let {
                    when (it?.status) {
                        ApiResponseStatus.LOADING -> {
                            LayoutUtils.disableUI(this)
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                edtLoginEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            MyAppPreferenceUtils.saveUserSession(
                                this@LoginActivity, Gson().fromJson(
                                    it.data,
                                    object : TypeToken<UserSessionBean>() {}.type
                                )
                            )
                            val savedUserSession =
                                MyAppPreferenceUtils.getUserSession(this@LoginActivity)
                            MyAppPreferenceUtils.saveToken(
                                this@LoginActivity,
                                savedUserSession.vApiToken
                            )
                            var vLanguage = savedUserSession.vLanguage
                            if (vLanguage.isNotEmpty() && vLanguage.isNotBlank()) {
                                MyAppPreferenceUtils.setAppLanguage(
                                    this,
                                    savedUserSession.vLanguage
                                )
                            } else {
                                MyAppPreferenceUtils.setAppLanguage(
                                    this,
                                    Constants.AppLanguages_SPANISH[0].languageCode
                                )
                            }
                            WebServiceRetrofitUtil.destroyInstance() //for replacing old token with new one
                            WebServiceRetrofitUtil.init(this)
                            if (savedUserSession.isMobileVerified == Constants.MOBILE_VERIFIED_NO) {
                                startActivity(
                                    Intent(
                                        this,
                                        OtpVerificationActivity::class.java
                                    ).putExtra(Constants.USERMODEL, savedUserSession)
                                )
                            } else {
                                MyAppPreferenceUtils.setLoggedIn(this@LoginActivity, true)
                                val i = Intent(this, MainActivity::class.java)
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                startActivity(i)
                                animateEnterTransition()
                                finish()
                            }
                        }
                        ApiResponseStatus.ERROR -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                edtLoginEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            //destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            LayoutUtils.enableUI(this)
                            showSnackbar(
                                edtLoginEmail,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }
                }
            })
        }
    }

    private fun isValidForm(): Boolean {
        if (!FormValidationUtils.isValidEmail(edtLoginEmail.text.toString().trim())) {
            edtLoginEmail.requestFocus()
            showSnackbar(
                edtLoginEmail,
                getString(R.string.error_invalid_email),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(edtLoginPwd.text.toString().trim())) {
            edtLoginPwd.requestFocus()
            showSnackbar(
                edtLoginPwd,
                getString(R.string.error_empty_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(edtLoginPwd.text.toString().trim())) {
            edtLoginPwd.requestFocus()
            showSnackbar(
                edtLoginPwd,
                getString(R.string.password8charrcater),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }
    }
}