package com.cEGrubHolic.driver.fragment

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.cEGrubHolic.driver.MainActivity
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.AppLanguageModel
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.Constants.AppLanguages_SPANISH
import com.cEGrubHolic.driver.utils.Constants.vCurrentCurrencySymbol
import com.cEGrubHolic.driver.utils.Constants.vSymbol
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.fragment_my_profile.*


class MyProfileFragment : BaseFragment() {

    val userAuthVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    var crtlngCode = ""


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_my_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setViewResponseModel()

        llProfileMain.visibility=View.GONE
        userAuthVM.getProfileData()

        btnUpdateProfile.setOnClickListener {

            if (MyAppPreferenceUtils.getAppLanguage(context!!) != crtlngCode) {
                userAuthVM.updateProfile(vLanguage=crtlngCode)
            } else {
                if (activity != null) {
                    activity!!.supportFragmentManager.popBackStack()
                }
            }
        }
    }

    private fun setViewResponseModel() {
        if (!userAuthVM.profileDataApiResponseObserver.hasActiveObservers()) {
            userAuthVM.profileDataApiResponseObserver.observe(viewLifecycleOwner) { it ->
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            if (context != null) {
                                MyAppPreferenceUtils.saveUserSession(
                                    context!!, Gson().fromJson(
                                        it.data,
                                        object : TypeToken<UserSessionBean>() {}.type
                                    )
                                )

                                updateui(
                                    context!!,
                                    MyAppPreferenceUtils.getUserSession(context!!)
                                )
                            }

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                imgProfileUser,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                imgProfileUser,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            }
        }

        if (!userAuthVM.updateProfileObserver.hasActiveObservers()) {
            userAuthVM.updateProfileObserver.observe(viewLifecycleOwner, {
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            if (context != null) {
                                MyAppPreferenceUtils.saveUserSession(
                                    context!!, Gson().fromJson(
                                        it.data,
                                        object : TypeToken<UserSessionBean>() {}.type
                                    )
                                )

                                LocaleManager.setNewLocale(context!!, crtlngCode)
                                WebServiceRetrofitUtil.destroyInstance()
                                WebServiceRetrofitUtil.init(context!!)
                                val i = Intent(activity, MainActivity::class.java)
                                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                                activity!!.finish()
                                startActivity(i)

                                /*if (activity != null) {
                                    activity!!.supportFragmentManager.popBackStack()
                                }*/
                            }

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                imgProfileUser,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                imgProfileUser,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }

                }
            })
        }
    }


    private fun updateui(context: Context, userdata: UserSessionBean) {


        Glide.with(context)
            .load(userdata.vImagePath)
            .placeholder(R.drawable.ic_profile_placeholder)
            .into(imgProfileUser)
        imgProfileUser.visibility = View.VISIBLE

        tvName.text = userdata.vName
        tvEmail.text = userdata.vEmail
        tvPhone.text = userdata.vMobileNo
        tvVehicleNo.text = userdata.vVehicleNo
        llWalletBalance.text= FormValidationUtils.getValueWithCurrencySymbolCode(
            userdata.dWallet, vSymbol, context.getString(R.string.defult_conversion_rate))

        when (Constants.currentLanguage) {
            "en" -> {
                spinnerAppLanguage.adapter = object : ArrayAdapter<AppLanguageModel>(
                    context,
                    R.layout.raw_item_spinner,
                    Constants.AppLanguages_ENGLISH
                ) {
                    override fun getView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        val v = super.getView(position, convertView, parent)
                        (v as TextView).textSize = 0f
                        v.setTextColor(Color.TRANSPARENT)
                        return v
                    }
                }
            }

            "es" -> {
                spinnerAppLanguage.adapter = object : ArrayAdapter<AppLanguageModel>(
                    context,
                    R.layout.raw_item_spinner,
                    AppLanguages_SPANISH
                ) {
                    override fun getView(
                        position: Int,
                        convertView: View?,
                        parent: ViewGroup
                    ): View {
                        val v = super.getView(position, convertView, parent)
                        (v as TextView).textSize = 0f
                        v.setTextColor(Color.TRANSPARENT)
                        return v
                    }
                }
            }
        }


        spinnerAppLanguage.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }

                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    if (btnUpdateProfile.text.toString().length > 6) {
                        txtAppLanguage.text = AppLanguages_SPANISH[position].language
                        crtlngCode = AppLanguages_SPANISH[position].languageCode
                    } else {
                        txtAppLanguage.text = Constants.AppLanguages_ENGLISH[position].language
                        crtlngCode = Constants.AppLanguages_ENGLISH[position].languageCode
                    }
                }
            }


        for ((index, language) in AppLanguages_SPANISH.withIndex()) {
            if (userdata.vLanguage == language.languageCode) {
                spinnerAppLanguage.setSelection(index)
            }
        }

        var vLanguage = userdata.vLanguage

        if (vLanguage.isNotBlank() && vLanguage.isNotEmpty()) {

            if (MyAppPreferenceUtils.getAppLanguage(context) == userdata.vLanguage) {
                llProfileMain.visibility=View.VISIBLE
                return
            }

            LocaleManager.setNewLocale(context, userdata.vLanguage)
            WebServiceRetrofitUtil.destroyInstance()
            WebServiceRetrofitUtil.init(context)
            val i = Intent(activity, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            activity!!.finish()
            startActivity(i)
        }
        llProfileMain.visibility=View.VISIBLE
    }




}