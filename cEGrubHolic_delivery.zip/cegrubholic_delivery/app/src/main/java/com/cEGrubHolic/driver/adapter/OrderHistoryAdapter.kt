package com.cEGrubHolic.driver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.HistoryOrderBean
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.DateTimeUtils
import com.cEGrubHolic.driver.utils.FormValidationUtils
import kotlinx.android.synthetic.main.raw_active_order.view.*
import kotlinx.android.synthetic.main.raw_history_order.view.*
import kotlinx.android.synthetic.main.raw_history_order.view.tvAmount
import kotlinx.android.synthetic.main.raw_history_order.view.tvorderId
import kotlinx.android.synthetic.main.raw_history_order.view.tvtotalItem


class OrderHistoryAdapter(
    private val listOfHistoryOrder: ArrayList<HistoryOrderBean>
) : RecyclerView.Adapter<OrderHistoryAdapter.MenuViewHolder>() {

    private var context: Context? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MenuViewHolder {
        context = viewGroup.context
        return MenuViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.raw_history_order, null
            )
        )
    }

    override fun onBindViewHolder(menuViewHolder: MenuViewHolder, position: Int) {

        val orderBean = listOfHistoryOrder[position]
        var itemView = menuViewHolder.itemView


        itemView.tvorderId.text =
            String.format(context!!.getString(R.string.placeholder_order_no), orderBean.vOrderId)
        itemView.tvtotalItem.text = String.format(
            context!!.getString(R.string.placeholder_items), orderBean.totalItems
        )
        itemView.tvOrderDate.text = DateTimeUtils.convertDateFormat(
            orderBean.dCreatedDate,
            Constants.server_dateformat, Constants.DATE_FORMAT_ONLY_DATE
        )
        itemView.tvOrderTime.text = DateTimeUtils.convertDateFormat(
            orderBean.dCreatedDate,
            Constants.server_dateformat,
            Constants.DATE_FORMAT_ONLY_TIME
        )
        itemView.tvAmount.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            orderBean.dGrandTotal,Constants.vCurrentCurrencySymbol, context!!.getString(R.string.defult_conversion_rate)
        )
        itemView.tvlblDeliveryPersonName.text = orderBean.vCustomerName.toUpperCase()
        itemView.tvDeliveryAddress.text = orderBean.vAddress


        if (orderBean.nStatus == "0"){
            itemView.tvOrderHistoryStatus.text = itemView.context.getString(R.string.order_received) + " " + "on"
        }else   if (orderBean.nStatus == "1"){
            itemView.tvOrderHistoryStatus.text = itemView.context.getString(R.string.orderaccepted)+ " " + "on"
        }else   if (orderBean.nStatus == "2"){
            itemView.tvOrderHistoryStatus.text = itemView.context.getString(R.string.orderdispatched)+ " " + "on"
        }else   if (orderBean.nStatus == "3"){
            itemView.tvOrderHistoryStatus.text = itemView.context.getString(R.string.order_delivered)+ " " + "on"
        }else   if (orderBean.nStatus == "4"){
            itemView.tvOrderHistoryStatus.text = itemView.context.getString(R.string.order_cencel)+ " " + "on"
        }

    }


    override fun getItemCount(): Int {
        return listOfHistoryOrder.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                //onOrderClickListener.onOrderClicked()
            }
        }
    }

    fun updateOrderList(updatedOrderList: ArrayList<HistoryOrderBean>) {
        listOfHistoryOrder.clear()
        listOfHistoryOrder.addAll(updatedOrderList)
        notifyDataSetChanged()
    }

    interface OnOrderClickListener {
        fun onOrderClicked()

    }
}
