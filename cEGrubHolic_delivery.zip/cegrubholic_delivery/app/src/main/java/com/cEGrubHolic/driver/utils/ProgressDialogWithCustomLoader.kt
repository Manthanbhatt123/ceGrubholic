package com.cEGrubHolic.driver.utils

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.cEGrubHolic.driver.R
import kotlinx.android.synthetic.main.dialog_progress_with_content.view.*


/**
 * Created by codexalters on 20/9/17.
 */

object ProgressDialogWithCustomLoader {

    var alertDialog: AlertDialog? = null

    fun showProgressDialog(
        context: Context,
        title: String,
        message: String,
        isCancelable: Boolean
    ) {
        dismissProgressDialog()
        createProgressDialog(context, title, message, isCancelable)
//        createProgressDialog(context, isCancelable)
        alertDialog!!.show()

    }

    private fun createProgressDialog(
        context: Context,
        title: String,
        message: String,
        isCancelable: Boolean
    ) {

        val dialogBuilder = AlertDialog.Builder(context, R.style.DialogTheme)

        val dialogView =
            LayoutInflater.from(context).inflate(R.layout.dialog_progress_with_content, null)

        if (title.isEmpty()) {
            dialogView.txtProgressTitle.visibility = View.GONE
        } else {
            dialogView.txtProgressTitle.visibility = View.VISIBLE
            dialogView.txtProgressTitle.text = title
        }
        if (message.isEmpty()) {
            dialogView.txtProgressMessage.visibility = View.GONE
        } else {
            dialogView.txtProgressMessage.visibility = View.VISIBLE
            dialogView.txtProgressMessage.text = message
        }

        dialogBuilder.setView(dialogView)
        dialogBuilder.setCancelable(isCancelable)
        alertDialog = dialogBuilder.create()
        alertDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))


    }

    /* private fun createProgressDialog(context: Context, isCancelable: Boolean) {

         val dialogBuilder = AlertDialog.Builder(context, R.style.DialogTheme)

         val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_progress_with_gif_loader, null)

         Glide.with(context).asGif()
             .load(R.raw.loader_iviiew)
             .apply(RequestOptions().transform(RoundedCorners(16)))
             .into(dialogView.imgLoader)

         dialogBuilder.setView(dialogView)
         dialogBuilder.setCancelable(isCancelable)
         alertDialog = dialogBuilder.create()
         alertDialog!!.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))


     }*/

    fun dismissProgressDialog() {
        if (alertDialog != null) {
            if (alertDialog!!.isShowing)
                alertDialog!!.dismiss()
            alertDialog = null
        }
    }


}
