package com.cEGrubHolic.driver.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.util.Log
import android.util.TypedValue
import androidx.core.content.res.ResourcesCompat

/**
 * Created by Ashish on 30-Jan-20.
 */


object BitmapMarkerUtil {
    fun createBitmapMapMarker(context: Context,drawable: Int): Bitmap {
        var px = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, 40f, context.resources.displayMetrics
        )
        Log.d(
            "dpfrompx", px.toString()
        )
        //set up  MapView
        // val height = 120
        //val width = 120
        var bitmap: BitmapDrawable =
            ResourcesCompat.getDrawable(
                context.resources,
                drawable,
                null
            ) as BitmapDrawable
        var b: Bitmap = bitmap.bitmap
       return  Bitmap.createScaledBitmap(b, px.toInt(), px.toInt(), false)
    }
}