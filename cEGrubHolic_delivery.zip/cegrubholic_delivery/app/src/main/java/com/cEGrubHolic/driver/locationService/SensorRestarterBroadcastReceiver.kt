package com.cEGrubHolic.driver.locationService

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils


class SensorRestarterBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.i(
            SensorRestarterBroadcastReceiver::class.java.simpleName,
            "Service Stops! Oooooooooooooppppssssss!!!!"
        )

        if (MyAppPreferenceUtils.getServiceRunningStatus(context)) {
            context.startService(Intent(context, LocationUpdateService::class.java))
            MyAppPreferenceUtils.setServiceRunningStatus(context, true)

        }
    }
}
