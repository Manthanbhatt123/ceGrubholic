package com.cEGrubHolic.driver.adapter


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.ReviwesModel
import com.cEGrubHolic.driver.utils.DateTimeUtils
import kotlinx.android.synthetic.main.raw_for_review.view.*
import java.util.*

class ReviwesListAdepter(
    val mOrderListModel: ArrayList<ReviwesModel>,
    val itemClickListener: ItemClickListener
) : RecyclerView.Adapter<ReviwesListAdepter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_for_review,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mOrderListModel.size
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {


        holder.itemView.tvUserNameReviews.text = mOrderListModel[position].vFullName
        Glide.with(holder.itemView.context).load(mOrderListModel[position].vImagePath)
            .apply(RequestOptions().circleCrop()).placeholder(R.drawable.ic_no_history)
            .into(holder.itemView.imageUserReviews)
        holder.itemView.tvOrderId.text = "#"+mOrderListModel[position].vOrderId


        holder.itemView.tvDateOfReview.text = DateTimeUtils.convertDateFormat(
            mOrderListModel[position].dCreatedDate,
            "yyyy-MM-dd HH:mm:ss", "dd-MM-yyyy, HH:mm a"
        )


        if (mOrderListModel[position].nRating.isNotEmpty()) {
            holder.itemView.ratingReview.rating = mOrderListModel[position].nRating.toFloat()
        }


    }


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(mOrderListModel[layoutPosition])
            }

        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            onPosition: ReviwesModel
        )


    }


}