package com.cEGrubHolic.driver.viewModelProviders

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.driver.network.ApiResponse
import com.cEGrubHolic.driver.network.Event
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.google.gson.JsonElement
import java.text.SimpleDateFormat
import java.util.*


class MyOrderVM : ViewModel() {

    val getInitialDataObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getInitialData() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getInitialData()

        getInitialDataObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getInitialDataObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getInitialDataObservable.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    getInitialDataObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getInitialDataObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val getHistoryOrderObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getHistoryOrder() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getHistoryOrder()

        getHistoryOrderObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getHistoryOrderObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getHistoryOrderObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getHistoryOrderObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getHistoryOrderObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val getOrderDetailsObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getOrderDetails(nOrderId: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getOrderDetails(nOrderId)

        getOrderDetailsObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrderDetailsObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrderDetailsObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getOrderDetailsObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getOrderDetailsObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }


    val changeOrderStatusObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun changeOrderStatus(
        nOrderId: String,
        nStatus: String
    ) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.changeOrderStatus(
                nOrderId = nOrderId,
                nStatus = nStatus
            )

        changeOrderStatusObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    changeOrderStatusObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    changeOrderStatusObservable.postValue(
                        Event(ApiResponse().success(data, message,nStatus))
                    )
                }

                override fun onFailure(message: String) {
                    changeOrderStatusObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    changeOrderStatusObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val getRatingAndReviewObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getRatingAndReview() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getRatingAndReview()

        getRatingAndReviewObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getRatingAndReviewObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getRatingAndReviewObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getRatingAndReviewObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getRatingAndReviewObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }
    val contactUsObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun contactUs(vMessage: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.contactUs(vMessage)

        contactUsObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    contactUsObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    contactUsObservable.postValue(
                        Event(ApiResponse().success(data, message))
                    )
                }

                override fun onFailure(message: String) {
                    contactUsObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    contactUsObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
    val earningObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun drivrEarning(dStartDate: Date) {  // YYYY-MM-DD

        val apiCall =
            WebServiceRetrofitUtil.webService!!.vDriverErning( sdf.format(dStartDate))

        earningObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    earningObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    earningObservable.postValue(
                        Event(ApiResponse().success(data, message))
                    )
                }

                override fun onFailure(message: String) {
                    earningObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    earningObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

}