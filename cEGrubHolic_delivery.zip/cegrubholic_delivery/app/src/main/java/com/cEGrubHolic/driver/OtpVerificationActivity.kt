package com.cEGrubHolic.driver

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.models.UserSessionBean
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.*
import com.cEGrubHolic.driver.utils.Constants.MOBILE_VERIFIED_YES
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_otp_verification.*
import java.util.*

class OtpVerificationActivity : BaseActivity(), View.OnClickListener {

    private var userSessionBean: UserSessionBean? = null
    private val SECONDS_TO_COMPLETE = 60
    private var secondsToResendOTP = SECONDS_TO_COMPLETE
    private var countdownTimerRunnable: Runnable? = null
    private val mHandler = Handler()

    private val userVM: UserAuthVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (intent == null || !intent.hasExtra(Constants.USERMODEL)) {
            finish()
            showShortToast(getString(R.string.msg_something_went_wrong))
            return
        }

        userSessionBean = intent.getSerializableExtra(Constants.USERMODEL) as UserSessionBean

        setContentView(R.layout.activity_otp_verification)
        setViewResponseModel()

        tvNumber.text=userSessionBean!!.vMobileNo


        //tvresendOtp.visibility = View.GONE

        pinEntryView.onPinEnteredListener = PinEntryView.OnPinEnteredListener {
            KeyboardUtils.hideKeyboard(this@OtpVerificationActivity, pinEntryView)
            if (pinEntryView.inputValue.length == 4) {
                checkOtp(pinEntryView.inputValue)
            } else {
                showSnackbar(
                    pinEntryView,
                    getString(R.string.error_otp),
                    SnackbarUtils.SnackbarType.WARNING
                )
            }
        }

        imgOtpVerificationBack.setOnClickListener(this)
        tvOtpVerify.setOnClickListener(this)
        tvresendOtp.setOnClickListener(this)

    }

    private fun setViewResponseModel() {
        if (!userVM.resentOTPObserver.hasActiveObservers())
            userVM.resentOTPObserver.observe(this, { it ->
                it.getContentIfNotHandled()?.let {
                    when (it.status) {
                        ApiResponseStatus.LOADING -> {
                            //resetCounter()
                            showProgress(getString(R.string.progress_please_wait), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                pinEntryView,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            userSessionBean!!.nMobileOTPCode =
                                (it.data!!.asJsonObject).get("nMobileOTPCode").asString
                        }

                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                pinEntryView,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            //destroyLoginSession(this)
                        }

                        ApiResponseStatus.NO_INTERNET -> {
                            LayoutUtils.enableUI(this)
                            showSnackbar(
                                pinEntryView,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }
                }
            })

        if (!userVM.updateProfileObserver.hasActiveObservers())
            userVM.updateProfileObserver.observe(this, { it ->
                it.getContentIfNotHandled()?.let {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            LayoutUtils.disableUI(this)
                            showProgress(getString(R.string.progress_please_wait), false)

                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                tvOtpVerify,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                            MyAppPreferenceUtils.saveUserSession(
                                this@OtpVerificationActivity, Gson().fromJson(
                                    it.data,
                                    object : TypeToken<UserSessionBean>() {}.type
                                )
                            )

                            MyAppPreferenceUtils.setLoggedIn(this@OtpVerificationActivity, true)
                            val i = Intent(this, MainActivity::class.java)
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                            startActivity(i)
                            finish()
                        }
                        ApiResponseStatus.ERROR -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                tvOtpVerify,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            //destroyLoginSession(false)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            LayoutUtils.enableUI(this)
                            showSnackbar(
                                tvOtpVerify,
                                getString(R.string.no_internet_connection),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                    }

                }
            })
    }

    override fun onClick(view: View) {
        when (view) {
            imgOtpVerificationBack -> {
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags =
                    Intent.FLAG_ACTIVITY_NEW_TASK.and(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
                finish()
            }

            tvOtpVerify -> {
                KeyboardUtils.hideKeyboard(this@OtpVerificationActivity, pinEntryView)
                if (pinEntryView.inputValue.length == 4) {
                    checkOtp(pinEntryView.inputValue)
                } else {
                    showSnackbar(
                        pinEntryView,
                        getString(R.string.error_otp),
                        SnackbarUtils.SnackbarType.WARNING
                    )
                }
            }

            tvresendOtp -> {
                userVM.resentOTP()
            }
        }
    }

    fun checkOtp(inputOtp: String) {
        //check response and enter otp is match ot not
        if (userSessionBean!!.nMobileOTPCode == inputOtp) {
            userVM.updateProfile(isMobileVerified=MOBILE_VERIFIED_YES)
        } else {
            showSnackbar(
                pinEntryView,
                getString(R.string.msg_wrong_pin),
                SnackbarUtils.SnackbarType.ERROR
            )
        }
    }

   /* private fun resetCounter() {

        countdownTimerRunnable = Runnable {

            if (secondsToResendOTP < 0) {
                tvresendOtp.visibility = View.VISIBLE
                //txtResendOTP_Timer.visibility = View.GONE
                countdownTimerRunnable = null

                return@Runnable
            }

            *//*txtResendOTP_Timer.text =
                String.format(
                    getString(R.string.resent_otp_in_00_1_s),
                    pad(secondsToResendOTP),
                    Locale.ENGLISH
                )*//*

            secondsToResendOTP--

            //mHandler.postDelayed(countdownTimerRunnable, 1000)
        }

        secondsToResendOTP = SECONDS_TO_COMPLETE

        tvresendOtp.visibility = View.GONE
        //txtResendOTP_Timer.visibility = View.VISIBLE

        countdownTimerRunnable?.run()

    }*/

   /* override fun onDestroy() {
        super.onDestroy()
        if (countdownTimerRunnable != null) {
            mHandler.removeCallbacksAndMessages(countdownTimerRunnable)
        }
        try {
//            unregisterReceiver(mSmsBroadcastReceiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }


    }*/



}
