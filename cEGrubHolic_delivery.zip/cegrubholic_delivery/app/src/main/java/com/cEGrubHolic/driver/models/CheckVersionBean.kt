package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class CheckVersionBean(
    @SerializedName("isForceUpdate")
    var isForceUpdate: String = "",
    @SerializedName("vStoreURL")
    var vStoreURL: String = "",
    @SerializedName("dVersionName")
    var dVersionName: String = "",
    @SerializedName("isMaintenanceMode")
    val isMaintenanceMode: String = ""
):Serializable