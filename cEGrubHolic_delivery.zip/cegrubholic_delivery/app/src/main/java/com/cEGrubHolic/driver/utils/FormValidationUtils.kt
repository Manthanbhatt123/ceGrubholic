package  com.cEGrubHolic.driver.utils


import android.content.Context
import android.text.InputFilter
import android.text.Spanned
import android.text.TextUtils
import android.util.Log
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import java.util.regex.Pattern
import kotlin.math.roundToInt


/**
 * Created by codexalters on 6/2/18.
 */
object FormValidationUtils {

    fun isValidEmail(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches()
    }

    fun isValidText(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && target.length >= 1
    }

    fun isValidPhone(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && android.util.Patterns.PHONE.matcher(target).matches() && target.length > 7
    }

    fun isValidPassword(password: String?): Boolean {

        /*  Pattern pattern;
        Matcher matcher;
//        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();*/


        var flag = false
        if (password != null && !password.equals("", false)
            && !password.equals(" ", false)
            && password.trim().length >= 7
        ) {
            flag = true
        }
        return flag
    }

    fun isStringValid(value: String?): Boolean {
        var flag = false
        if (value != null && !value.equals("", false)
            && value.trim().isNotEmpty()
        ) {
            flag = true
        }
        return flag
    }


    fun isValidRePassword(pass1: String, pass2: String): Boolean {
        return pass1 == pass2
    }

    fun isValidPasswordLength(password: String?, length: Int): Boolean {
        var flag = false
        if (password != null && password.trim().length >= 4
        ) {
            flag = true
        }
        return flag
    }

    fun upperCaseFirstLetter(string: String): String {
        if (TextUtils.isEmpty(string)) {
            return string
        } else {
            val sb = StringBuilder(string)
            sb.setCharAt(0, Character.toUpperCase(sb.get(0)))
            return sb.toString()
        }
    }

    fun getValueWithCurrencyCode(amount: Any): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            "$" + String.format("%.2f", 0f)
        } else {
            "$" + String.format("%.2f", amount.toString().toDouble())

        }
    }



    fun showValueWithDynamicCurrencyCode(context: Context,amount:String,currencyCode: String): String{
        return if (currencyCode.isNotEmpty() || currencyCode.isNotBlank()) {
            MyAppPreferenceUtils.getCurrencySysmbol(context) + amount
        } else {
            amount

        }
    }




    fun convertToDecimal(str: String): String {
        return try {
            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
            DecimalFormat("0.00",symbols).format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }
    }

    fun convertToDecimalNew(str: String): String {
        return try {
            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
            DecimalFormat("0.0",symbols).format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }
    }

    fun convertLatToDecimal(str: String): String {
        return try {
            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
            val decimalFormat = DecimalFormat("#.#######", symbols)
            decimalFormat.roundingMode = RoundingMode.HALF_UP
            decimalFormat.format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }
        return str
    }

    fun convertToDecimalWithoutDecimal(str: String): String {
        return try {

            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
            DecimalFormat("0", symbols).format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }

    }

    fun getValueWithDynamicCurrencyCode(context: Context,amount: String): String {
        return if (amount.isNotEmpty() || amount.isNotBlank()) {
            Log.d("amountwithDiscount", "getValueWithDynamicCurrencyCode ${amount.toDouble()} * ${MyAppPreferenceUtils.getConversionRate(context).toDouble()} = ${amount.toDouble() * (MyAppPreferenceUtils.getConversionRate(context)).toDouble()}")
            var finalAmount:Float=(amount.toFloat() * MyAppPreferenceUtils.getConversionRate(context).toFloat())
            MyAppPreferenceUtils.getCurrencySysmbol(context) + convertToDecimal(finalAmount.toString())
        } else {
            MyAppPreferenceUtils.getCurrencySysmbol(context) + convertToDecimal("0")

        }
    }

    fun getValueWithDynamicCurrencyCodeWithoutSymbol(context: Context,amount: String): String {
        return if (amount.isNotEmpty() || amount.isNotBlank()) {
            var finalAmount:Float=(amount.toFloat() * MyAppPreferenceUtils.getConversionRate(context).toFloat())
            convertToDecimal(finalAmount.toString())
        } else {
            convertToDecimal("0")

        }
    }

    fun getValueWithCurrencySymbolCode(
        amount: Any,
        currencySymbol: String,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            currencySymbol + convertToDecimal(amount.toString())
        } else {
            currencySymbol + convertToDecimal((amount.toString().toDouble() * conversionRate.toDouble()).toString())

        }
    }

    fun getValueWithCurrencyWithoutSymbolCode(
        amount: Any,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            convertToDecimal(amount.toString())
        } else {
             convertToDecimal((amount.toString().toDouble() * conversionRate.toDouble()).toString())

        }
    }

    fun getValueWithCurrencyCodeWithoutDecimalValue(
        amount: String,
        currencySymbol: String,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            currencySymbol + convertToDecimalWithoutDecimal(amount.toString().toDouble().roundToInt().toString())
        } else {
            Log.d("amountwithDiscount", "getValueWithCurrencyCodeWithoutDecimalValue ${amount.toDouble()} * ${conversionRate.toDouble()} = ${amount.toDouble() * conversionRate.toDouble()}")
            currencySymbol + convertToDecimalWithoutDecimal((amount.toString().toDouble() * conversionRate.toDouble()).roundToInt().toString())

        }
    }

    fun getValueWithCurrencyCodeWithoutDecimalValueAndWithoutCurrency(
        amount: Any,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            convertToDecimalWithoutDecimal(amount.toString().toDouble().roundToInt().toString())
        } else {
            convertToDecimalWithoutDecimal((amount.toString().toDouble() * conversionRate.toDouble()).roundToInt().toString())

        }
    }



    fun getRatingDecimal(str: String): String {
        return try {
            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
            DecimalFormat("0.0",symbols).format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }
    }

    fun getNameWithCompany(projectName: String, companyName: String): String {
        return if (projectName.isEmpty() || projectName.isBlank() || companyName.isEmpty() || companyName.isBlank()) {
            "$projectName at  $companyName"
        } else {
            "$projectName  at $companyName"
        }
    }

    fun getValueWithHashCode(id: Any): String {
        return if (id.toString().isEmpty() || id.toString().isBlank()) {
            "#" + String.format("%s", id)
        } else {
            "#" + String.format("%s", id)

        }
    }


    fun getFullName(firstName: String, lastName: String): String {
        return if (firstName.isEmpty() || firstName.isBlank() || lastName.isEmpty() || lastName.isBlank()) {
            "$firstName $lastName"
        } else {
            "$firstName $lastName"
        }
    }

    fun getValueWithQtyText(qtyno: Any): String {
        return if (qtyno.toString().isEmpty() || qtyno.toString().isBlank()) {
            "Qty " + String.format("%s", qtyno)
        } else {
            "Qty " + String.format("%s", qtyno)


        }
    }

    fun getValueWithItemReviews(totalReviews: String?): String {
        return if (totalReviews.toString().isEmpty() || totalReviews.toString().isBlank()) {
            if (totalReviews == "1") {
                String.format("%s", totalReviews) + " ReviewBean"
            } else {
                String.format("%s", totalReviews) + " Reviews"
            }

        } else {
            String.format("%s", totalReviews) + " Reviews"

        }
    }


    fun getValueWithItemAvailablein(totalReviews: String?): String {
        return if (totalReviews.toString().isEmpty() || totalReviews.toString().isBlank()) {
            "Available in - " + String.format("%s", totalReviews)
        } else {
            "Available in - " + String.format("%s", totalReviews)

        }
    }


    fun getValueWithQuantityCode(qtyno: Any): String {
        return if (qtyno.toString().isEmpty() || qtyno.toString().isBlank()) {
            "x" + String.format("%s", qtyno)
        } else {
            "x" + String.format("%s", qtyno)

        }
    }

    fun getValueWithNamePriceCode(name: Any, price: Any): String {
        return if (name.toString().isEmpty() || name.toString().isBlank() || price.toString().isEmpty() || price.toString().isBlank()) {
            String.format("%s(%s)", name,
                getValueWithCurrencyCode(price)
            )
        } else {
            String.format("%s(%s)", name,
                getValueWithCurrencyCode(price)
            )

        }
    }

    class DecimalDigitsInputFilter(digitsBeforeZero: Int, digitsAfterZero: Int) : InputFilter {

        var mPattern: Pattern =
            Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?")

        override fun filter(
            source: CharSequence,
            start: Int,
            end: Int,
            dest: Spanned,
            dstart: Int,
            dend: Int
        ): CharSequence? {

            val matcher = mPattern.matcher(dest)
            return if (!matcher.matches()) "" else null
        }

    }

    class AlphaNumericInputFilter : InputFilter {
        override fun filter(
            source: CharSequence, start: Int, end: Int,
            dest: Spanned, dstart: Int, dend: Int
        ): CharSequence? {

            // Only keep characters that are alphanumeric
            val builder = StringBuilder()
            for (i in start until end) {
                val c = source[i]
                if (Character.isLetterOrDigit(c)) {
                    builder.append(c)
                }
            }

            // If all characters are valid, return null, otherwise only return the filtered characters
            val allCharactersValid = builder.length == end - start
            return if (allCharactersValid) null else builder.toString().toUpperCase()
        }
    }
}