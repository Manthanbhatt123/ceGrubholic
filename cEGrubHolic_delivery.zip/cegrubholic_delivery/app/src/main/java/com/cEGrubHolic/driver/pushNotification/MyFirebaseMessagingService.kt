package com.cEGrubHolic.driver.pushNotification

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.cEGrubHolic.driver.MainActivity
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.utils.Constants
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_nId
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_nPushType
import com.cEGrubHolic.driver.utils.Constants.KEY_NOTIFICATION_vOther
//import com.egodelivery.driver.utils.Constants.KEY_NOTIFICATION_vOther_isSlientRequired
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import org.json.JSONObject
import java.util.*


class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)

        Log.i("MyFirebaseInstanceID", "onTokenRefresh pushToken: $token")

        MyAppPreferenceUtils.savePushToken(applicationContext, token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        //  Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage!!.notification!!.body!!)
        //  Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage.data)

        try {
            Log.d("MyFirebaseMessagingServ", "onMessageReceived : $remoteMessage ")
            Log.i(
                "FirebaseMessagingSrvice",
                "onMessageReceived: " + remoteMessage.notification!!.body!!
            )
            Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage.data)

            sendNotification(remoteMessage)

        } catch (e: Exception) {
            Log.e("MyFirebaseMessagingServ", "onMessageReceived : ${e.printStackTrace()} ")
        }

    }

    /* private val channelGeneral: String = "General Notifications"
     private val channelRide: String = "Ride Notifications"
     private val channelChat: String = "Chat Notifications"*/

    private fun sendNotification(remoteMessage: RemoteMessage) {

        val vOtherJson =
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_vOther) && !remoteMessage.data[KEY_NOTIFICATION_vOther].isNullOrBlank()) {
                JSONObject(remoteMessage.data[KEY_NOTIFICATION_vOther])
            } else {
                null
            }

        /*val isSilentPush = if (vOtherJson != null) {
            vOtherJson.has(KEY_NOTIFICATION_vOther_isSlientRequired) && vOtherJson[KEY_NOTIFICATION_vOther_isSlientRequired] == 1
        } else {
            false
        }*/

        val isSilentPush=false

        if (isSilentPush) {
            val intent = Intent()
            //extra payload for silently update App UI without sending notification
            val notificationDataBundle = Bundle()
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType)) {
                notificationDataBundle.putString(
                    KEY_NOTIFICATION_nPushType,
                    remoteMessage.data[KEY_NOTIFICATION_nPushType]
                )
            }
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)) {
                notificationDataBundle.putString(
                    KEY_NOTIFICATION_nId,
                    remoteMessage.data[KEY_NOTIFICATION_nId]
                )
            }
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_vOther)) {
                notificationDataBundle.putString(
                    KEY_NOTIFICATION_vOther,
                    remoteMessage.data[KEY_NOTIFICATION_vOther]
                )
            }
            intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
            intent.action = Constants.INTENT_ACTION_NOTIFICATION
            //sendBroadcast(intent)
            return
        } else {
            val intent = Intent()
            //extra payload for silently update App UI without sending notification
            val notificationDataBundle = Bundle()
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType)) {
                notificationDataBundle.putString(
                    KEY_NOTIFICATION_nPushType,
                    remoteMessage.data[KEY_NOTIFICATION_nPushType]
                )
            }
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)) {
                notificationDataBundle.putString(
                    KEY_NOTIFICATION_nId,
                    remoteMessage.data[KEY_NOTIFICATION_nId]
                )
            }
            intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
            intent.action = Constants.INTENT_ACTION_NOTIFICATION
            //sendBroadcast(intent)
            //return
        }
        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        /*************/



        /***********/


        val intent = Intent(this, MainActivity::class.java)

        //extra payload

        val notificationDataBundle = Bundle()

        if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType)) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_nPushType,
                remoteMessage.data[KEY_NOTIFICATION_nPushType]
            )
        }
        if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_nId,
                remoteMessage.data[KEY_NOTIFICATION_nId]
            )
        }

        notificationDataBundle.putString(
            Constants.KEY_NOTIFICATION_TITLE,
            remoteMessage.notification!!.title
        )
        notificationDataBundle.putString(
            Constants.KEY_NOTIFICATION_MESSAGE,
            remoteMessage.notification!!.body
        )
        if (vOtherJson != null) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_vOther,
                vOtherJson.toString()
            )
        }

        intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
        intent.action = Constants.INTENT_ACTION_NOTIFICATION


        val pendingIntent =
            PendingIntent.getActivity(
                this,
                Random(100).nextInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )

       /* val notificationSoundUri: Uri =
            Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/" + R.raw.notify)*/

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val notificationChannel: NotificationChannel? = let {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType) &&
                        remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)
                    ) {
                        when (remoteMessage.data[KEY_NOTIFICATION_nPushType]) {
                            Constants.nPushType_rideRequest-> {
                                notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                            }

                            else -> { //general notifications
                                notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                            }
                        }
                    } else { //general notifications
                        notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                    }
                } else {// not required to create channel
                    null
                }
            }

            /*  val audioAttributes: AudioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

          notificationChannel?.setSound(notificationSoundUri, audioAttributes)
            notificationManager.createNotificationChannel(notificationChannel!!)
*/
            notificationManager.notify(
                getNotificationId(),
                NotificationCompat.Builder(this, notificationChannel!!.id)
                    .setColorized(false)
                    .setSmallIcon(R.drawable.ic_driver_noti)
                    .setContentTitle(remoteMessage.notification!!.title)
                    .setContentText(remoteMessage.notification!!.body!!)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    //.setSound(notificationSoundUri)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setColor(ContextCompat.getColor(this, R.color.icon_tint))
                    .setContentIntent(pendingIntent).build()
            )
        } else {
            notificationManager.notify(
                getNotificationId(), NotificationCompat.Builder(this, "")
                    .setColorized(false)
                    .setSmallIcon(R.drawable.ic_driver_noti)
                    .setContentTitle(remoteMessage.notification!!.title)
                    .setContentText(remoteMessage.notification!!.body!!)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    //.setSound(notificationSoundUri)
                    .setCategory(Notification.CATEGORY_MESSAGE)
                    .setColor(ContextCompat.getColor(this, R.color.icon_tint))
                    .setContentIntent(pendingIntent).build()
            )
        }
    }


    private fun getNotificationId(): Int {
        val notificationId = ((Date().time / 1000L % Integer.MAX_VALUE).toInt())
        Log.i("MyFirebaseMessage", "getNotificationId : $notificationId ")
        return notificationId
    }

}
