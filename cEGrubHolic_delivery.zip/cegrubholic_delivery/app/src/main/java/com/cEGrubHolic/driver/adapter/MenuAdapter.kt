package com.cEGrubHolic.driver.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.models.MenuModel
import kotlinx.android.synthetic.main.raw_item_menu.view.*


class MenuAdapter(
    private val listOfMenus: ArrayList<MenuModel>,
     val onMenuClickListener: OnMenuClickListener
) :
    RecyclerView.Adapter<MenuAdapter.MenuViewHolder>() {

    private var context: Context? = null

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MenuViewHolder {
        context = viewGroup.context
        return MenuViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.raw_item_menu, null
            )
        )
    }

    override fun onBindViewHolder(menuViewHolder: MenuViewHolder, position: Int) {


        val menuBean = listOfMenus[position]
        var itemView = menuViewHolder.itemView

        if (menuBean.menuName == R.string.logout) {
            itemView.ll_side_menu.visibility = View.GONE
            itemView.ll_side_menu_logout.visibility = View.VISIBLE

            menuViewHolder.itemView.txtMenuLogout.text =
                menuViewHolder.itemView.context.getString(listOfMenus[position].menuName)


        } else {
            itemView.ll_side_menu_logout.visibility = View.GONE
            itemView.ll_side_menu.visibility = View.VISIBLE

            menuViewHolder.itemView.txtMenuName.text =
                menuViewHolder.itemView.context.getString(listOfMenus[position].menuName)
        }
        itemView.txtMenuName.isSelected = listOfMenus[position].isSelected


    }


    override fun getItemCount(): Int {
        return listOfMenus.size
    }

    inner class MenuViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener{
                    onMenuClickListener.onMenuClicked(listOfMenus[layoutPosition])
                }

        }
    }

    interface OnMenuClickListener {
        fun onMenuClicked(sideMenuModel: MenuModel)

    }
}
