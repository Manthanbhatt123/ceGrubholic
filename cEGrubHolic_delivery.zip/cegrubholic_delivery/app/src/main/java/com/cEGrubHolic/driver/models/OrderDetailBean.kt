package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OrderDetailBean(
    @SerializedName("CustomerData")
    val customerDatumBeans: CustomerDataBean = CustomerDataBean(),
    @SerializedName("dCreatedDate")
    val dCreatedDate: String = "",
    @SerializedName("dGrandTotal")
    val dGrandTotal: String = "",
    @SerializedName("FoodData")
    val foodDatumBeans: ArrayList<FoodDataBean> = arrayListOf<FoodDataBean>(),
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nPaymentType")
    val nPaymentType: String = "",
    @SerializedName("nStatus")
    val nStatus: String = "",
    @SerializedName("RestaurantData")
    val restaurantData: RestaurantData = RestaurantData(),
    @SerializedName("vOrderId")
    val vOrderId: String = "",
    @SerializedName("vPromoCode")
    val vPromoCode: String = "",
    @SerializedName("nRequestStatus")
    val nRequestStatus: String = "",
    @SerializedName("dOrderAssignDate")
    val dOrderAssignDate:String,
    @SerializedName("nDeliveryBoyId")
    val nDeliveryBoyId:String="",
    @SerializedName("dOnlinePaymentChargeAmount")
    val dOnlinePaymentChargeAmount: String = "",
    @SerializedName("vPickupVerificationCode")
    val vPickupVerificationCode: String = "",
    @SerializedName("nPreparationTime")
    val nPreparationTime: String = ""
) : Serializable