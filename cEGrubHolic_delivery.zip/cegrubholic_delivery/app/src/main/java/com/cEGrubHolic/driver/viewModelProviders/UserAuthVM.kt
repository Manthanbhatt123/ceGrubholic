package com.cEGrubHolic.driver.viewModelProviders

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.driver.network.ApiResponse
import com.cEGrubHolic.driver.network.Event
import com.cEGrubHolic.driver.network.WebServiceResponseHandler
import com.cEGrubHolic.driver.network.WebServiceRetrofitUtil
import com.google.gson.JsonElement
import okhttp3.MultipartBody
import java.util.*

class UserAuthVM : ViewModel() {

    // login
    val loginObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getLoggedIn(
        vEmail: String,
        vPassword: String,
        nLoginDeviceType: String,
        vPushToken: String
    ) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.login(
                vEmail,
                vPassword,
                nLoginDeviceType,
                vPushToken
            )
        loginObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    loginObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    loginObserver.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    loginObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    loginObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    //logout
    val logoutApiObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun logout() {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.logout()
        logoutApiObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    logoutApiObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    logoutApiObservable.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    logoutApiObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    logoutApiObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //changePassword
    val changePasswordObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun changePassword(vOldPassword: String, vNewPassword: String) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.changePassword(vOldPassword, vNewPassword)
        changePasswordObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    changePasswordObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    changePasswordObservable.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    changePasswordObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    changePasswordObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //privacyPolicy
    val privacyPolicyApiObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun privacyPolicy() {
        val apiCall = WebServiceRetrofitUtil.webService!!.privacyPolicy()
        privacyPolicyApiObservable.postValue(ApiResponse().loading())
        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    privacyPolicyApiObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    privacyPolicyApiObservable.postValue(
                        ApiResponse().success(
                            data,
                            message
                        )
                    )
                }

                override fun onFailure(message: String) {
                    privacyPolicyApiObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    privacyPolicyApiObservable.postValue(ApiResponse().noInternet())
                }
            })
    }

    //getTerms
    val getTermsApiObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getTerms() {
        val apiCall = WebServiceRetrofitUtil.webService!!.getTerms()
        getTermsApiObservable.postValue(ApiResponse().loading())
        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {

                override fun sessionExpired() {
                    getTermsApiObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getTermsApiObservable.postValue(
                        ApiResponse().success(
                            data,
                            message
                        )
                    )
                }

                override fun onFailure(message: String) {
                    getTermsApiObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getTermsApiObservable.postValue(ApiResponse().noInternet())
                }

            })
    }

    //forgotPassword
    val forgotPasswordApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun forgotPassword(vEmail: String) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.forgotPassword(vEmail)
        forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    forgotPasswordApiResponseObservable.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //registration -signup
    val signUpApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun signUp(
        fields: ArrayList<MultipartBody.Part>
    ) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.SignUp(
                fields
            )

        signUpApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    signUpApiResponseObservable.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    val profileDataApiResponseObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getProfileData() {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.getProfileDetails()
        profileDataApiResponseObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    profileDataApiResponseObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    profileDataApiResponseObserver.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    profileDataApiResponseObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    profileDataApiResponseObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //update profile - onboard
    val updateProfileObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun updateProfile(isActive: String="", vLanguage: String="", isMobileVerified: String="") {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.updateProfile(
                isActive = isActive,
                vLanguage = vLanguage,
                isMobileVerified = isMobileVerified
            )
        updateProfileObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateProfileObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateProfileObserver.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    updateProfileObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    updateProfileObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //resend otp
    val resentOTPObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun resentOTP() {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.resentOTP()
        resentOTPObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    resentOTPObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    resentOTPObserver.postValue(
                        Event(
                            ApiResponse().success(
                                data,
                                message
                            )
                        )
                    )
                }

                override fun onFailure(message: String) {
                    resentOTPObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    resentOTPObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


}