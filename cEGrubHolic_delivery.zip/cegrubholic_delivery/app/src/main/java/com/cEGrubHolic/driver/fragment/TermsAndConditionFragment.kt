package com.cEGrubHolic.driver.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.driver.R
import com.cEGrubHolic.driver.network.ApiResponseStatus
import com.cEGrubHolic.driver.utils.LayoutUtils
import com.cEGrubHolic.driver.utils.MyAppPreferenceUtils
import com.cEGrubHolic.driver.utils.SnackbarUtils
import com.cEGrubHolic.driver.viewModelProviders.UserAuthVM
import kotlinx.android.synthetic.main.fragment_terms_and_condition.*


class TermsAndConditionFragment : BaseFragment() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_terms_and_condition, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        userViewModel.getTerms()

        if (!userViewModel.getTermsApiObservable.hasActiveObservers()) {
            userViewModel.getTermsApiObservable.observe(viewLifecycleOwner, Observer {

                when (it?.status) {
                    ApiResponseStatus.LOADING -> {
                        showProgress(getString(R.string.loding), false)
                    }

                    ApiResponseStatus.SUCCESS -> {
                        hideProgress()

                        var termsText = (it.data!!.asJsonObject).get("vDesc").asString
                        termsText.replace("&#39;", "'")
                        wvTermsCondition.settings.javaScriptEnabled = true
                        // show # from html string
                        wvTermsCondition.loadDataWithBaseURL(
                            null,
                            termsText,
                            "text/html",
                            "UTF-8",
                            null
                        )
                    }

                    ApiResponseStatus.ERROR -> {
                        hideProgress()
                        showSnackbar(
                            wvTermsCondition,
                            it.message,
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                    ApiResponseStatus.SESSION_EXPIRED -> {
                        LayoutUtils.enableUI(this)
                        hideProgress()

                    }

                    ApiResponseStatus.NO_INTERNET -> {
                        LayoutUtils.enableUI(this)
                        hideProgress()
                        showSnackbar(
                            wvTermsCondition,
                            getString(R.string.no_internet),
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }

                }

            })
        }
    }


}