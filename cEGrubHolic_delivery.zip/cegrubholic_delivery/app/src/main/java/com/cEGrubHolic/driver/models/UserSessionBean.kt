package com.cEGrubHolic.driver.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class UserSessionBean(
    @SerializedName("dCommission")
    val dCommission: String = "",
    @SerializedName("dCreatedDate")
    val dCreatedDate: String = "",
    @SerializedName("dLat")
    val dLat: String = "",
    @SerializedName("dLng")
    val dLng: String = "",
    @SerializedName("dModifiedDate")
    val dModifiedDate: String = "",
    @SerializedName("dWallet")
    val dWallet: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("isActive")
    val isActive: String = "",
    @SerializedName("nLoginDeviceType")
    val nLoginDeviceType: String = "",
    @SerializedName("nMobileOTPCode")
    var nMobileOTPCode: String = "",
    @SerializedName("vApiToken")
    val vApiToken: String = "",
    @SerializedName("vEmail")
    val vEmail: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("vLanguage")
    val vLanguage: String = "",
    @SerializedName("vMobileNo")
    val vMobileNo: String = "",
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("vPushToken")
    val vPushToken: String = "",
    @SerializedName("vVehicleNo")
    val vVehicleNo: String = "",
    @SerializedName("isMobileVerified")
    val isMobileVerified: String = "",
    @SerializedName("isOnline")
    val isOnline:String= ""
) : Serializable