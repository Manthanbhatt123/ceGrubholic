package com.egodelivery.business.models

import com.cEGrubHolic.business.models.MonthlyOrderModel
import com.cEGrubHolic.business.models.MontholyIncomeModel
import com.google.gson.annotations.SerializedName

data class RepoetsModel(
    @SerializedName("MonthlyOrder")
    val monthlyOrder: ArrayList<MonthlyOrderModel> =  arrayListOf(),
    @SerializedName("MonthlyIncome")
    val monthlyIncome: ArrayList<MontholyIncomeModel> = arrayListOf()
)
