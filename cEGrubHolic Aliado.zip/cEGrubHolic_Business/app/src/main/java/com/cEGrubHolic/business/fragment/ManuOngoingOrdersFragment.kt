package com.cEGrubHolic.business.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.OrderDetailsActivity
import com.egodelivery.business.adapter.OnGoingOrderForDispetchadAdepter
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM

import com.egodelivery.business.adapter.OnGoingOrderForAcceptedAdepter
import com.egodelivery.business.models.OngoingOrderModel
import com.egodelivery.business.utils.Constants
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_menu_ongoing_orders.*


class ManuOngoingOrdersFragment : BaseFragment(), OnGoingOrderForAcceptedAdepter.ItemClickListener,
    OnGoingOrderForDispetchadAdepter.ItemClickListener {

    val vOrderAcceptedListModel = arrayListOf<OngoingOrderModel>()
    var mOrderAcceptedListAdepter: OnGoingOrderForAcceptedAdepter = OnGoingOrderForAcceptedAdepter(vOrderAcceptedListModel,this)


    val vOrderDispetiedListModel = arrayListOf<OngoingOrderModel>()
    var mOrderDispecherAadepter:OnGoingOrderForDispetchadAdepter = OnGoingOrderForDispetchadAdepter(vOrderDispetiedListModel,this)



    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_ongoing_orders, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        relAccepted.isSelected = true

        recyclerOngoingOrders.visibility = View.GONE
        recyclerOngoingOrders.adapter = mOrderAcceptedListAdepter

        userViewModel.getOngoingOrderList()

        if (!userViewModel.getOngoingOrderListApi.hasActiveObservers()) {
            userViewModel.getOngoingOrderListApi.observe(
                requireActivity(),
                androidx.lifecycle.Observer { it->
                    it.getContentIfNotHandled()?.let { it ->

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                               refreshOnGoingOrders.isRefreshing = true
                            }
                            ApiResponseStatus.SUCCESS -> {
                                refreshOnGoingOrders.isRefreshing = false

                                vOrderAcceptedListModel.clear()
                                vOrderAcceptedListModel.addAll(
                                    Gson().fromJson(
                                        it.data!!.asJsonObject["Accepted"],
                                        object : TypeToken<List<OngoingOrderModel>>() {}.type
                                    )
                                )




                                vOrderDispetiedListModel.clear()
                                vOrderDispetiedListModel.addAll(
                                    Gson().fromJson(
                                        it.data!!.asJsonObject["Dispatched"],
                                        object : TypeToken<List<OngoingOrderModel>>() {}.type
                                    )
                                )


                                    showDetailViewS(txtErrorr.text.toString())





                            }
                            ApiResponseStatus.ERROR -> {

                                refreshOnGoingOrders.isRefreshing = false
                                showDetailViewS(txtErrorr.text.toString())

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                               refreshOnGoingOrders.isRefreshing = false
                                showDetailViewS(txtErrorr.text.toString())

                            }
                            else -> {
                               refreshOnGoingOrders.isRefreshing = false
                            }

                        }
                    }

                })
        }





        refreshOnGoingOrders.setOnRefreshListener {
            userViewModel.getOngoingOrderList()
        }



        relDispatched.setOnClickListener {
            relDispatched.isSelected = true
            relAccepted.isSelected = false
            showDetailViewS(txtErrorr.text.toString())
        }
        relAccepted.setOnClickListener {
            relDispatched.isSelected = false
            relAccepted.isSelected = true
            showDetailViewS(txtErrorr.text.toString())
        }



    }


    private fun showDetailViewS(errorMsg: String) {

        txtErrorr.text = errorMsg

        if (relAccepted.isSelected) {

            if (vOrderAcceptedListModel.isEmpty()) {
                imageNoOrderFound.visibility = View.VISIBLE
                recyclerOngoingOrders.visibility = View.GONE
                return
            } else {
                imageNoOrderFound.visibility = View.GONE
                recyclerOngoingOrders.visibility = View.VISIBLE
            }
            mOrderAcceptedListAdepter     = OnGoingOrderForAcceptedAdepter(vOrderAcceptedListModel,this)
            recyclerOngoingOrders.adapter = mOrderAcceptedListAdepter
        //    mOrderAcceptedListAdepter.notifyDataSetChanged()

        }else if (relDispatched.isSelected){

            if (vOrderDispetiedListModel.isEmpty()) {
                imageNoOrderFound.visibility = View.VISIBLE
                recyclerOngoingOrders.visibility = View.GONE
                return
            } else {
                imageNoOrderFound.visibility = View.GONE
                recyclerOngoingOrders.visibility = View.VISIBLE
            }
            mOrderDispecherAadepter =    OnGoingOrderForDispetchadAdepter(vOrderDispetiedListModel,this)
            recyclerOngoingOrders.adapter = mOrderDispecherAadepter
          //  mOrderDispecherAadepter.notifyDataSetChanged()

        }

    }
    override fun vAcceptedOrderClicked(vAcceptedOrder: OngoingOrderModel) {
        startActivityForResult(
            Intent(requireContext(), OrderDetailsActivity::class.java)
                .putExtra(Constants.KEY_FOR_ORDER_DETIASL,vAcceptedOrder.id)
            , Constants.RC_ORDER_DITAISLS
        )

    }

    override fun vDispachedonItemClicked(vDispactedOrder: OngoingOrderModel) {

        startActivityForResult(
            Intent(requireContext(), OrderDetailsActivity::class.java)
                .putExtra(Constants.KEY_FOR_ORDER_DETIASL,vDispactedOrder.id)
            , Constants.RC_ORDER_DITAISLS
        )
    }


}