package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class CategoryitemListModel(
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("isActive")
    val isActive: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nCategoryId")
    val nCategoryId: String = "",
    @SerializedName("vTitle")
    val vTitle: String = "",
    @SerializedName("vDesc")
    val vDesc: String = "",
    @SerializedName("dCost")
    val dCost: String = "",
    @SerializedName("isCrossSelling")
    val isCrossSelling: String = "",
    @SerializedName("vModifierIds")
    val vModifierIds: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("vModifierGroup")
    val vModifierGroup: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = "",
    @SerializedName("nSequenceNo")
    val nSequenceNo: String = ""

): Serializable
{
    var isSelected = false
}