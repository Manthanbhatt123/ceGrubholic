package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.FoodTitleModel
import kotlinx.android.synthetic.main.row_food_itemlist.view.*

import java.util.ArrayList

class FoodListForOngoingAdepter(val mFoodItemModel: ArrayList<FoodTitleModel>

): RecyclerView.Adapter<FoodListForOngoingAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_food_itemlist,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mFoodItemModel.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
   //     holder.itemView.tvOrderAmount.visibility = View.VISIBLE
        holder.itemView.tvItemNumer.text = mFoodItemModel[position].mQuntitie + "x"
        holder.itemView.tvItemName.text = mFoodItemModel[position].mItemNAme
    //    holder.itemView.tvOrderAmount.text = "Bs "+mFoodItemModel[position].dProductPrice
    //    holder.itemView.tvItemExtra.text = mFoodItemModel[position].vModifier
    //    holder.itemView.tvItemDetailsNote.text = mFoodItemModel[position].vDesc
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    }


}