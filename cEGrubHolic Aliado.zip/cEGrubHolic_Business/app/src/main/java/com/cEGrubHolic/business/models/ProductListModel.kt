package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ProductListModel(
        @SerializedName("vImagePath")
        val vImagePAth: String = "",
        @SerializedName("vName")
        val vProductName: String = "",
        @SerializedName("dNewPrice")
        val vProductPrice: String = "",
        @SerializedName("dOldPrice")
        val vProductOldPrice: String = "",
        @SerializedName("id")
        val id: String = "",
        @SerializedName("vDesc")
        val vDesc: String = "",
        @SerializedName("isActive")
        val isActive: String = "",
        @SerializedName("vModifierIds")
        val vModifierIds: String = ""
):Serializable