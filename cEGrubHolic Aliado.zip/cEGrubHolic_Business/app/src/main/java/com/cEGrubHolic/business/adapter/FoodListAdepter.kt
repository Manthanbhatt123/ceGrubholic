package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.FoodTitleModel
import kotlinx.android.synthetic.main.row_food_itemlist.view.*

import java.util.ArrayList

class FoodListAdepter(val mFoodItemModel: ArrayList<FoodTitleModel>

): RecyclerView.Adapter<FoodListAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_food_itemlist,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mFoodItemModel.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.tvItemNumer.text = mFoodItemModel[position].mQuntitie + "x"
        holder.itemView.tvItemName.text = mFoodItemModel[position].mItemNAme


    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)


}