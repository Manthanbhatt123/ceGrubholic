package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class UserRoleModel(
    @SerializedName("vFirstName")
    val vFirstName: String = "",
    @SerializedName("vLastName")
    val vLastName: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("vEmail")
    val vEmail: String = "",
    @SerializedName("vModules")
    val vModules: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = ""
) : Serializable