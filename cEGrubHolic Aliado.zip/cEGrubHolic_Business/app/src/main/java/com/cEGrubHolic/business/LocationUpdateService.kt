package com.egodelivery.business

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.NOTIFICATION_CHANNEL_ID
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils

import com.google.android.gms.location.*
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.egodelivery.business.pushnotificetion.SensorRestarterBroadcastReceiver



class LocationUpdateService : Service() {

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    private val UPDATE_INTERVAL_IN_MILLISECONDS: Long = 20000
    private val FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS = UPDATE_INTERVAL_IN_MILLISECONDS / 2

    private var mFusedLocationClient: FusedLocationProviderClient? = null
    private var mLocationCallback: LocationCallback? = null

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        try {
            startLocationUpdates(applicationContext!!)
        } catch (e: Exception) {
            Log.e("LocationUpdateService", "onStartCommand : ${e.printStackTrace()} ")
        }
        return Service.START_STICKY
    }

    override fun onDestroy() {
        Log.i("EXIT", "ondestroy!")
        val broadcastIntent = Intent(this, SensorRestarterBroadcastReceiver::class.java)
        broadcastIntent.action = Constants.ACTION_RESTART_SERVICE
        sendBroadcast(broadcastIntent)
        stopLocationUpdates()
        super.onDestroy()
    }


    private fun startLocationUpdates(applicationContext: Context) {

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        val mLocationRequest = LocationRequest()
        mLocationRequest.interval = UPDATE_INTERVAL_IN_MILLISECONDS
        mLocationRequest.fastestInterval = FASTEST_UPDATE_INTERVAL_IN_MILLISECONDS
        mLocationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        // mLocationRequest!!.smallestDisplacement = 10f

        mLocationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult?) {
                super.onLocationResult(locationResult)

                if (locationResult != null) {
                    Log.d(
                        "LocationUpdateService",
                        "onLocationResult : ${locationResult.lastLocation} "
                    )

                    updateLatLngToServer(locationResult.lastLocation)
                }
            }
        }

        try {
            mFusedLocationClient?.requestLocationUpdates(
                mLocationRequest,
                mLocationCallback!!,
                Looper.myLooper()
            )
        } catch (e: SecurityException) {
            Log.e("LocationUpdateService", "startLocationUpdates : ${e.printStackTrace()} ")
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelName = "My Background Service"
            val chan = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_NONE
            )
            chan.lightColor = Color.BLUE
            chan.lockscreenVisibility = Notification.VISIBILITY_PRIVATE
            val manager =
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            manager.createNotificationChannel(chan)
        }
        Log.i("LocationUpdateService", "startForegroundNotification : $ ")

        val notification =
            NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
                .setOngoing(true)
                .setAutoCancel(false)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.dontTurnOffGps))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true)
                .setGroup("SERVICE")
                .build()

        notification.flags = Notification.FLAG_FOREGROUND_SERVICE

        startForeground(2, notification)
    }

    private fun stopLocationUpdates() {
        mFusedLocationClient?.removeLocationUpdates(mLocationCallback!!)
        stopForeground(true)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        //Log.i("EXIT", "ondestroy!")
        Log.i("SensorService", "onTaskRemoved: ")
        super.onTaskRemoved(rootIntent)
        val broadcastIntent = Intent(this, SensorRestarterBroadcastReceiver::class.java)
        broadcastIntent.action = Constants.ACTION_RESTART_SERVICE
        sendBroadcast(broadcastIntent)
        //stoptimertask()
    }

    private fun updateLatLngToServer(location: Location) {
        //call update lat lng api

        if (WebServiceRetrofitUtil.webService == null) {
            WebServiceRetrofitUtil.init(this)
        }

        try {


            /*    val latitude = getLocationDecimalFormat().format(location.latitude).toDouble()
                val longitude = getLocationDecimalFormat().format(location.longitude).toDouble()*/

            val latitude = location.latitude
            val longitude = location.longitude

            if (MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).latitude == latitude
                && MyAppPreferenceUtils.getUserCurrentLocation(applicationContext).longitude == longitude
            ) {
                return
            }

            MyAppPreferenceUtils.setUserCurrentLocation(
                applicationContext, latitude, longitude
            )

            val apiCall =
                WebServiceRetrofitUtil.webService!!.updateLocation(latitude, longitude)

            WebServiceResponseHandler.handleApiResponse(
                apiCall,
                object : WebServiceResponseHandler.DataHandler {
                    override fun onSuccess(data: JsonElement, message: String) {

                    }

                    override fun onFailure(message: String) {

                    }

                    override fun noInternetConnection() {

                    }

                    override fun sessionExpired() {

                    }

                })

        } catch (e: java.lang.NumberFormatException) {
            //catch block added because getting error

            /*
             * Fatal Exception: java.lang.NumberFormatException: For input string: "-21,528766"
             * crash reported in Huawai Mate9 & Y7 device
             */


            Log.e("LocationUpdateService", "updateLatLngToServer : ${e.printStackTrace()} ")
        }
    }


}
