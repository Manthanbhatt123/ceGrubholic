package com.cEGrubHolic.business.fragment

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.egodelivery.business.viewmodelprovider.ModifierGroupListVM
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.KeyboardUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_add_and_edit_modifier.*
import okhttp3.MultipartBody


class AddAndEditModifierFragment : BaseFragment() {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(ModifierGroupListVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_and_edit_modifier, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        redioButtonSingal.isChecked = true
        chackIsMandotery.visibility = View.VISIBLE

        if (!userViewModel.addModifierGroupListApi.hasActiveObservers()) {
            userViewModel.addModifierGroupListApi.observe(
                requireActivity(),
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), true)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                btnAddModifier,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                Activity.RESULT_OK
                                requireActivity().finish()
                            }, 1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()

                            showSnackbar(
                                btnAddModifier,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnAddModifier,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })

        }
        if (!userViewModel.upDateModifierGroupListApi.hasActiveObservers()) {
            userViewModel.upDateModifierGroupListApi.observe(
                requireActivity(),
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), true)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                btnAddModifier,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                Activity.RESULT_OK
                                requireActivity().finish()
                            }, 1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()

                            showSnackbar(
                                btnAddModifier,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnAddModifier,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })
        }
        redioButtonSingal.setOnClickListener {
            linMaxSelextNumber.visibility = View.GONE
            chackIsMandotery.visibility = View.VISIBLE
        }
        redioButtonMultipal.setOnClickListener {
            linMaxSelextNumber.visibility = View.VISIBLE
            chackIsMandotery.visibility = View.GONE
        }

        val getDataForCall = requireArguments().getInt(Constants.OPEN_ADD_FRAGMENT)

        when (getDataForCall) {
            4 -> {
                val getAllModifierData =
                    requireArguments().getSerializable(Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL) as ModifierGroupModel
                upDateUi(getAllModifierData)
            }
        }
        btnAddModifier.setOnClickListener {
            when (getDataForCall) {
                3 -> {
                    KeyboardUtils.hideKeyboard(requireActivity(), btnAddModifier)
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vGroupName",
                                edtModifierGroupName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vDisplayName",
                                edtModifierDispayName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtModifierSequence.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nMaxSelectValue",
                                edtMaxMumItemAdd.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nMinSelectValue",
                                edtMiniMumItemAdd.text.toString().trim()
                            )
                        )
                        if (redioButtonSingal.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "nChoiceType",
                                    "1"
                                )
                            )
                        } else if (redioButtonMultipal.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "nChoiceType",
                                    "2"
                                )
                            )
                        }

                        if (swichModifierActives.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }
                        if (chackIsMandotery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isMandatory",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isMandatory",
                                    "0"
                                )
                            )
                        }


                        userViewModel.addModifierGroupList(multipartArray)
                    }

                }
                4 -> {
                    KeyboardUtils.hideKeyboard(activity!!, btnAddModifier)
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nModifierGroupId",
                                arguments!!.getString(Constants.GET_ITEM_ID)!!
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vGroupName",
                                edtModifierGroupName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vDisplayName",
                                edtModifierDispayName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nMaxSelectValue",
                                edtMaxMumItemAdd.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nMinSelectValue",
                                edtMiniMumItemAdd.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtModifierSequence.text.toString().trim()
                            )
                        )
                        if (redioButtonSingal.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "nChoiceType",
                                    "1"
                                )
                            )
                        } else if (redioButtonMultipal.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "nChoiceType",
                                    "2"
                                )
                            )
                        }

                        if (swichModifierActives.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }
                        if (chackIsMandotery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isMandatory",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isMandatory",
                                    "0"
                                )
                            )
                        }
                        userViewModel.upDateModifierGroupList(multipartArray)
                    }
                }
            }
        }
    }

    private fun upDateUi(modifierGroupItem: ModifierGroupModel) {
        edtModifierGroupName.setText(modifierGroupItem.vGroupName)
        edtModifierDispayName.setText(modifierGroupItem.vDisplayName)
        edtModifierSequence.setText(modifierGroupItem.nSequenceNo)
        edtMaxMumItemAdd.setText(modifierGroupItem.nMaxSelectValue)
        edtMiniMumItemAdd.setText(modifierGroupItem.nMinSelectValue)
        if (modifierGroupItem.nChoiceType == "1") {
            redioButtonSingal.isChecked = true
            linMaxSelextNumber.visibility = View.GONE
            chackIsMandotery.visibility = View.VISIBLE
        } else if (modifierGroupItem.nChoiceType == "2") {
            redioButtonMultipal.isChecked = true
            linMaxSelextNumber.visibility = View.VISIBLE
            chackIsMandotery.visibility = View.GONE
        }
        if (modifierGroupItem.isActive == "1") {
            swichModifierActives.isChecked = true
        } else if (modifierGroupItem.isActive == "0") {
            swichModifierActives.isChecked = false
        }

        if (modifierGroupItem.isMandatory == "1") {
            chackIsMandotery.isChecked = true
        } else if (modifierGroupItem.isMandatory == "0") {
            chackIsMandotery.isChecked = false
        }

    }

    private fun isValidForm(): Boolean {


        if (redioButtonMultipal.isChecked) {
            if (edtMiniMumItemAdd.text.isEmpty()){
                showSnackbar(
                    edtMaxMumItemAdd,
                    getString(R.string.min_selection_numbers),
                    SnackbarUtils.SnackbarType.WARNING
                )
                return false
            }else if ( edtMaxMumItemAdd.text.toString() < "1") {
                edtMaxMumItemAdd.requestFocus()
                showSnackbar(
                    edtMaxMumItemAdd,
                    getString(R.string.max_selection_numbers),
                    SnackbarUtils.SnackbarType.WARNING
                )
                return false
            } else if (edtMiniMumItemAdd.text.toString() > edtMaxMumItemAdd.text.toString()) {
                edtMiniMumItemAdd.requestFocus()
                showSnackbar(
                    edtMaxMumItemAdd,
                    getString(R.string.minimumnubmer_less),
                    SnackbarUtils.SnackbarType.WARNING
                )
                return false
            }
        }
        if (!FormValidationUtils.isValidText(edtModifierGroupName.text.toString().trim())) {
            edtModifierGroupName.requestFocus()
            showSnackbar(
                edtModifierGroupName,
                getString(R.string.please_add_group_name),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(edtModifierDispayName.text.toString().trim())) {
            edtModifierDispayName.requestFocus()
            showSnackbar(
                edtModifierDispayName,
                getString(R.string.please_add_display_name),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(edtModifierSequence.text.toString().trim())) {
            edtModifierSequence.requestFocus()
            showSnackbar(
                edtModifierSequence,
                getString(R.string.please_add_suquence_number),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }
    }

}
