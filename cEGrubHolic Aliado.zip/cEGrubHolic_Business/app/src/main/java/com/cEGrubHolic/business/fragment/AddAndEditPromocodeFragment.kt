package com.cEGrubHolic.business.fragment

import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.PromocodeModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.egodelivery.business.viewmodelprovider.PromocodeVM
import com.cEGrubHolic.business.utils.DateTimeUtils
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.utils.PackageInfoUtil
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog
import kotlinx.android.synthetic.main.fragment_add_and_edit_menu_item.*
import kotlinx.android.synthetic.main.fragment_add_and_edit_promocode.*
import kotlinx.android.synthetic.main.fragment_manu_promocode_list.*
import okhttp3.MultipartBody
import java.text.SimpleDateFormat
import java.util.*


class AddAndEditPromocodeFragment : BaseFragment(), View.OnClickListener {
    private var startDateBuilder: DateTimeUtils.MyDate.MyDateBuilder? = null
    private var timeDateForMeter: DateTimeUtils.MyDate? = null
    private var endDateBuilder: DateTimeUtils.MyDate.MyDateBuilder? = null
    private var endDateForMeter: DateTimeUtils.MyDate? = null

    var startDate = ""
    var endDate = ""

    private val userViewModel by lazy {
        ViewModelProvider(this).get(PromocodeVM::class.java)
    }
    var nPromocodeId = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_and_edit_promocode, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        vPromocodeMng()
        redioButtonAmount.isChecked = true
        txtCouponStartDatess.setOnClickListener(this)
        txtCouponEnddatess.setOnClickListener(this)

        startDateBuilder = DateTimeUtils.MyDate.MyDateBuilder()
        endDateBuilder = DateTimeUtils.MyDate.MyDateBuilder()



        checkboxForFreeDelivery.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                viewHideValues.visibility = View.GONE
            } else {
                viewHideValues.visibility = View.VISIBLE
            }
        }
        textValuerInAmount.text = String.format(
            getString(R.string.value),
            Constants.vCurrentCurrencySymbol,
            Locale.ENGLISH
        )

        redioButtonParcentejl.setOnClickListener {
            viewForCapValue.visibility = View.VISIBLE
            textValuerInAmount.text =  getString(R.string.values)
        }
        redioButtonAmount.setOnClickListener {
            viewForCapValue.visibility = View.GONE
            textValuerInAmount.text = String.format(
                getString(R.string.value),
                Constants.vCurrentCurrencySymbol,
                Locale.ENGLISH
            )
        }
        textcategoryCapValue.text = String.format(
            getString(R.string.capvalue),
            Constants.vCurrentCurrencySymbol,
            Locale.ENGLISH
        )

        val getApiCallForPromocode = arguments!!.getInt(Constants.FOR_API_CALLING_PROMOCODE)

        when (getApiCallForPromocode) {
            2 -> {
                val getProcodeData =
                    arguments!!.getSerializable(Constants.GET_PROMOCODE_DATA) as PromocodeModel
                updateUI(getProcodeData)
            }
        }

        relPromocodeSubmit.setOnClickListener {
            when (getApiCallForPromocode) {
                1 -> {
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vTitle",
                                edtPromocodeName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dStartDateTime",
                                startDateBuilder?.build()?.getMyDateInUTC("yyyy-MM-dd HH:mm:ss")

                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dEndDateTime",
                                endDateBuilder?.build()?.getMyDateInUTC("yyyy-MM-dd HH:mm:ss")
                            )
                        )
                        if (!checkboxForFreeDelivery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "dValue",
                                    edtPromocodeValue.text.toString().trim()
                                )
                            )
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "dCapValue",
                                    edtPromocodeCapValue.text.toString().trim()
                                )
                            )
                            if (redioButtonAmount.isChecked) {
                                multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                        "nChoiceType",
                                        "2"
                                    )
                                )
                            } else {
                                multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                        "nChoiceType",
                                        "1"
                                    )
                                )
                            }
                        }

                        if (checkboxForFreeDelivery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isFreeDeliveryCharge",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isFreeDeliveryCharge",
                                    "0"
                                )
                            )
                        }

                        userViewModel.addPromocodeList(multipartArray)
                    }
                }
                2 -> {
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nPromocodeId",
                                nPromocodeId
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vTitle",
                                edtPromocodeName.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dStartDateTime",
                                startDateBuilder?.build()?.getMyDateInUTC("yyyy-MM-dd HH:mm:ss")

                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dEndDateTime",
                                endDateBuilder?.build()?.getMyDateInUTC("yyyy-MM-dd HH:mm:ss")
                            )
                        )
                        if (!checkboxForFreeDelivery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "dValue",
                                    edtPromocodeValue.text.toString().trim()
                                )
                            )
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "dCapValue",
                                    edtPromocodeCapValue.text.toString().trim()
                                )
                            )
                            if (redioButtonAmount.isChecked) {
                                multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                        "nChoiceType",
                                        "2"
                                    )
                                )
                            } else {
                                multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                        "nChoiceType",
                                        "1"
                                    )
                                )
                            }
                        }
                        if (checkboxForFreeDelivery.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isFreeDeliveryCharge",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isFreeDeliveryCharge",
                                    "0"
                                )
                            )
                        }
                        userViewModel.upDatePromocodeList(multipartArray)

                    }
                }
            }
        }
    }


    fun updateUI(vPromocodeData: PromocodeModel) {
        if (vPromocodeData.isFreeDeliveryCharge == "1") {
            checkboxForFreeDelivery.isChecked = true
        }
        if (vPromocodeData.nType == "1") {
            redioButtonParcentejl.isChecked = true
        } else {
            redioButtonAmount.isChecked = true
        }

        nPromocodeId = vPromocodeData.id
        edtPromocodeName.setText(vPromocodeData.vPromoCode)
        edtPromocodeValue.setText(vPromocodeData.dValue)
        edtPromocodeCapValue.setText(vPromocodeData.dCapValue)


        startDateBuilder?.year(
            DateTimeUtils.convertDateFormat(
                vPromocodeData.dStartDate,
                "yyyy-MM-dd HH:mm:ss", "yyyy"
            ).toInt()
        )?.month(
            DateTimeUtils.convertDateFormat(
                vPromocodeData.dStartDate,
                "yyyy-MM-dd HH:mm:ss", "MM"
            ).toInt() - 1
        )?.dayOfMonth(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dStartDate,
                    "yyyy-MM-dd HH:mm:ss", "dd"
                ).toInt()
            )?.hourOfDay(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dStartDate,
                    "yyyy-MM-dd HH:mm:ss", "hh"

                ).toInt()
            )?.minute(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dStartDate,
                    "yyyy-MM-dd HH:mm:ss", "mm"
                ).toInt()
            )?.seconds(0)


        Log.d("Tag", "updateUI: "+startDateBuilder?.build()?.getMyDateInLocal("dd MMM,yyyy hh:mm a"))

        endDateBuilder?.year(
            DateTimeUtils.convertDateFormat(
                vPromocodeData.dEndDate,
                "yyyy-MM-dd HH:mm:ss", "yyyy"
            ).toInt()
        )?.month(
            DateTimeUtils.convertDateFormat(
                vPromocodeData.dEndDate,
                "yyyy-MM-dd HH:mm:ss", "MM"
            ).toInt() -1
        )?.dayOfMonth(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dEndDate,
                    "yyyy-MM-dd HH:mm:ss", "dd"
                ).toInt()
            )?.hourOfDay(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dEndDate,
                    "yyyy-MM-dd HH:mm:ss", "hh"

                ).toInt()
            )?.minute(
                DateTimeUtils.convertDateFormat(
                    vPromocodeData.dEndDate,
                    "yyyy-MM-dd HH:mm:ss", "mm"
                ).toInt()
            )?.seconds( DateTimeUtils.convertDateFormat(
            vPromocodeData.dEndDate,
            "yyyy-MM-dd HH:mm:ss", "ss"
        ).toInt())

        Log.d("Tag", "updateUI: "+endDateBuilder?.build()?.getMyDateInLocal("dd MMM,yyyy hh:mm a"))

        txtCouponStartDatess.text =  DateTimeUtils.convertDateFormat(
            vPromocodeData.dStartDate,
            "yyyy-MM-dd HH:mm:ss", "dd MMM,yyyy hh:mm a"
        )

        txtCouponEnddatess.text =  DateTimeUtils.convertDateFormat(
            vPromocodeData.dEndDate,
            "yyyy-MM-dd HH:mm:ss", "dd MMM,yyyy hh:mm a"
        )



    }

    fun vPromocodeMng() {
        if (!userViewModel.addPromocodeListApi.hasActiveObservers()) {
            userViewModel.addPromocodeListApi.observe(
                activity!!,
                androidx.lifecycle.Observer { it ->
                    when (it.status) {
                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                requireActivity().finish()
                            }, 2000)
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                Constants.NO_INTERNET,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        else -> {
                            hideProgress()
                        }

                    }


                })
        }
        if (!userViewModel.upDatePromocodeListApi.hasActiveObservers()) {
            userViewModel.upDatePromocodeListApi.observe(
                activity!!,
                androidx.lifecycle.Observer { it ->
                    when (it.status) {
                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                requireActivity().finish()
                            }, 2000)
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                txtCouponEnddatess,
                                Constants.NO_INTERNET,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        else -> {
                            hideProgress()
                        }

                    }


                })
        }
    }

    override fun onClick(v: View?) {
        when (v) {
            txtCouponStartDatess -> {


                txtCouponStartDatess.text = ""
                txtCouponEnddatess.text = ""
                val dialog =
                    DatePickerDialog.newInstance(
                        { view, year, monthOfYear, dayOfMonth ->

                            startDateBuilder?.year(year)?.month(monthOfYear)
                                ?.dayOfMonth(dayOfMonth)
                        //    startDateBuilder?.hourOfDay(0)?.minute(0)?.seconds(0)
                            timeDateForMeter = startDateBuilder?.build()
                            TimePickerDialog.newInstance(

                                { view, hourOfDay, minute, second ->


                                    val format = SimpleDateFormat(
                                        DateTimeUtils.displayDateTimeFormat,
                                        Locale.ENGLISH
                                    )

                                    val tempDate = DateTimeUtils.MyDate.MyDateBuilder()
                                    tempDate.hourOfDay(hourOfDay).minute(minute).seconds(0)
                                    tempDate.year(year).month(monthOfYear).dayOfMonth(dayOfMonth)

                                    startDateBuilder?.hourOfDay(hourOfDay)?.minute(minute)
                                        ?.seconds(0)
                                    timeDateForMeter = startDateBuilder?.build()

                                    val startDate =
                                        format.parse(
                                            tempDate.build()
                                                .getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)
                                        )

                                    val endDate =
                                        format.parse(
                                            endDateBuilder?.build()?.getMyDateInLocal(
                                                DateTimeUtils.displayDateTimeFormat
                                            )!!
                                        )


                                    /*    when (endDate!!.compareTo(startDate)) {
                                            0 -> {
                                                showSnackbar(
                                                    txtCouponEnddatess,
                                                    getString(R.string.startDateEndDateNotSame),
                                                    SnackbarUtils.SnackbarType.WARNING
                                                )
                                                return@newInstance
                                            }
                                            -1 -> {
                                                showSnackbar(
                                                    txtCouponEnddatess,
                                                    getString(R.string.EndDateGreaterThanStartDate),
                                                    SnackbarUtils.SnackbarType.WARNING
                                                )
                                                return@newInstance
                                            }

                                            1 -> {

                                                startDateBuilder?.year(year)?.month(monthOfYear)
                                                    ?.dayOfMonth(dayOfMonth)
                                                txtCouponStartDatess.text =
                                                    startDateBuilder?.build()
                                                        ?.getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)

                                            }
                                        }
*/
                                    txtCouponStartDatess.text =
                                        startDateBuilder?.build()
                                            ?.getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)

                                }, 0, 0, 0, true
                            ).showNow(childFragmentManager, "TimePicker")


                        },
                        Calendar.getInstance()
                    )

                dialog.minDate = Calendar.getInstance()
                val maxDate = Calendar.getInstance()
                maxDate.add(Calendar.YEAR, 1)
                dialog.maxDate = maxDate

                dialog.show(childFragmentManager, "")

            }
            txtCouponEnddatess -> {
                txtCouponEnddatess.text = ""
                if (txtCouponStartDatess.text.toString().trim().isEmpty()) {
                    showSnackbar(
                        txtCouponEnddatess,
                        getString(R.string.selectStartDate),
                        SnackbarUtils.SnackbarType.ERROR
                    )

                }
                val dialog =
                    DatePickerDialog.newInstance(
                        { view, year, monthOfYear, dayOfMonth ->


                            endDateBuilder?.year(year)?.month(monthOfYear)
                                ?.dayOfMonth(dayOfMonth)
                    //        endDateBuilder?.hourOfDay(0)?.minute(0)?.seconds(0)
                            endDateForMeter = endDateBuilder?.build()
                            TimePickerDialog.newInstance(

                                { view, hourOfDay, minute, second ->

                                    endDateBuilder?.hourOfDay(hourOfDay)?.minute(minute)?.seconds(0)
                                    endDateForMeter = endDateBuilder?.build()


                                    val format =
                                        SimpleDateFormat(
                                            DateTimeUtils.displayDateTimeFormat,
                                            Locale.ENGLISH
                                        )

                                    val tempDate = DateTimeUtils.MyDate.MyDateBuilder()
                                    tempDate.hourOfDay(hourOfDay).minute(minute).seconds(0)
                                    tempDate.year(year).month(monthOfYear).dayOfMonth(dayOfMonth)



                                    val startDate =
                                        format.parse(
                                            startDateBuilder?.build()?.getMyDateInLocal(
                                                DateTimeUtils.displayDateTimeFormat
                                            )!!
                                        )

                                    val endDate =
                                        format.parse(
                                            tempDate.build()
                                                .getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)
                                        )

                                    when (endDate!!.compareTo(startDate)) {
                                        -1 -> {
                                            showSnackbar(
                                                txtCouponEnddatess,
                                                getString(R.string.EndDateGreaterThanStartDate),
                                                SnackbarUtils.SnackbarType.WARNING
                                            )
                                            return@newInstance

                                        }
                                        0 -> {
                                            showSnackbar(
                                                txtCouponEnddatess,
                                                getString(R.string.startDateEndDateNotSame),
                                                SnackbarUtils.SnackbarType.WARNING
                                            )
                                            return@newInstance
                                        }
                                        1 -> {
                                            endDateBuilder?.year(year)?.month(monthOfYear)
                                                ?.dayOfMonth(dayOfMonth)
                                            txtCouponEnddatess.text =
                                                endDateBuilder?.build()
                                                    ?.getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)
                                        }

                                    }


                                    /*  txtCouponEnddatess.text =
                                          endDateBuilder?.build()
                                              ?.getMyDateInLocal(DateTimeUtils.displayDateTimeFormat)*/

                                }, 0, 0, 0, true
                            ).showNow(childFragmentManager, "TimePicker")


                        },
                        Calendar.getInstance()
                    )

                dialog.minDate = Calendar.getInstance()
                val maxDate = Calendar.getInstance()
                maxDate.add(Calendar.YEAR, 1)
                dialog.maxDate = maxDate

                dialog.show(childFragmentManager, "")
            }
        }


    }

    private fun isValidForm(): Boolean {


        if (!FormValidationUtils.isValidText(edtPromocodeName.text.toString().trim())) {
            edtPromocodeName.requestFocus()
            showSnackbar(
                edtPromocodeName,
                getString(R.string.enter_velid_promocode),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!checkboxForFreeDelivery.isChecked) {
            if (!FormValidationUtils.isValidText(edtPromocodeValue.text.toString().trim())) {
                edtPromocodeValue.requestFocus()
                showSnackbar(
                    edtPromocodeValue,
                    getString(R.string.enter_valid_value),
                    SnackbarUtils.SnackbarType.WARNING
                )
                return false
            } else if (redioButtonParcentejl.isChecked) {
                if (!FormValidationUtils.isValidText(edtPromocodeCapValue.text.toString().trim())) {
                    edtPromocodeCapValue.requestFocus()
                    showSnackbar(
                        edtPromocodeCapValue,
                        getString(R.string.enter_valid_cap_value),
                        SnackbarUtils.SnackbarType.WARNING
                    )
                    return false
                }
            }
        }



        if (!FormValidationUtils.isValidText(txtCouponStartDatess.text.toString().trim())) {
            txtCouponStartDatess.requestFocus()
            showSnackbar(
                txtCouponStartDatess,
                getString(R.string.enter_valid_start_date),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(txtCouponEnddatess.text.toString().trim())) {
            txtCouponEnddatess.requestFocus()
            showSnackbar(
                txtCouponEnddatess,
                getString(R.string.enter_valid_end_date),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }


    }


}