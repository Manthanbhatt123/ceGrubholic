package com.egodelivery.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.ProductListModel
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.egodelivery.business.utils.Constants
import kotlinx.android.synthetic.main.raw_for_product.view.*

import kotlinx.android.synthetic.main.raw_manage_manus.view.ImageDeleteMenu
import kotlinx.android.synthetic.main.raw_manage_manus.view.imageEditMenu


import java.util.ArrayList

class ProductManuListAdepter(val vProductList: ArrayList<ProductListModel>,
                             val itemClickListener: ItemClickListener
): RecyclerView.Adapter<ProductManuListAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_for_product,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return vProductList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.tvProductName.text = vProductList[position].vProductName

        holder.itemView.tvProductDescription.text = vProductList[position].vDesc
        holder.itemView.tvNewPrice.text =  Constants.vCurrentCurrencySymbol + " "+vProductList[position].vProductPrice

        holder.itemView.tvOldPrice.text =   FormValidationUtils.getValueWithCurrencyCode(
            vProductList[position].vProductOldPrice.toDouble(),
            "" ,
            "1"
        )
        Glide.with(holder.itemView.imageOfProduct).load(vProductList[position].vImagePAth)
                .into( holder.itemView.imageOfProduct)

    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(vProductList[layoutPosition])
            }
            itemView.imageEditMenu.setOnClickListener {
                itemClickListener.onEditCategory(vProductList[layoutPosition])
            }
            itemView.ImageDeleteMenu.setOnClickListener {
                itemClickListener.onDeletCategory(vProductList[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: ProductListModel

        )
        fun onEditCategory(
            menuPos: ProductListModel
        )
        fun onDeletCategory(
            menuPos: ProductListModel
        )
    }
}