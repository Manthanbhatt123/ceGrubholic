package com.cEGrubHolic.business.models

import java.io.Serializable

data class SideNavModelClass(val vMenuTitle:Int) : Serializable {
    var isSelected = false
}