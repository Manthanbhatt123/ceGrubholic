package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OrderHistoryModel(
    @SerializedName("nStatus")
    val vOrderStutas: String = "",
    @SerializedName("dGrandTotal")
    val vOrderValue: String= "",
    @SerializedName("vOrderId")
    val vOrderID: String= "",
    @SerializedName("dCreatedDate")
    val vOrderDate: String= "",
    @SerializedName("vAddress")
    val vOrderAddress: String= "",
    @SerializedName("TotalItems")
    val vOrderItemCout: String= "",
    @SerializedName("vNickName")
    val vNickName : String= "",
    @SerializedName("id")
    val id: String= ""
): Serializable