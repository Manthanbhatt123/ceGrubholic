package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.ModifierGroupModel
import kotlinx.android.synthetic.main.raw_add_modifier_for_menu.view.*

import java.util.*

class AddMiddifierMenuListAdepter(
    val mModifaierGroupNames: ArrayList<ModifierGroupModel>,
    val itemClickListener: ItemClickListener
) : RecyclerView.Adapter<AddMiddifierMenuListAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_add_modifier_for_menu,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mModifaierGroupNames.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.txtAddModifier.text = mModifaierGroupNames[position].vDisplayName
        holder.itemView.checkBoxAddModifier.isSelected = mModifaierGroupNames[position].isSelected
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(mModifaierGroupNames[layoutPosition])
            }



        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: ModifierGroupModel
        )




    }
}