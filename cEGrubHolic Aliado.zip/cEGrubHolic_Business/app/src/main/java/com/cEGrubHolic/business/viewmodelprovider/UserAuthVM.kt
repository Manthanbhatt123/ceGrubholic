package com.example.godeliverybusinessapp.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.egodelivery.business.viewmodelprovider.Event
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import okhttp3.MultipartBody
import java.util.*

/**
 * Created by Ashish on 2/4/19.
 */


class UserAuthVM : ViewModel() {

    //registration -signup
    val signUpApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun signUp(fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.signUp(fields)
        signUpApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    signUpApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


    // login
    val loginApiResponseObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getLoggedIn(vEmail: String, vPassword: String, nLoginDeviceType: String,vPushToken: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.login(vEmail, vPassword, nLoginDeviceType,vPushToken)

        loginApiResponseObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    loginApiResponseObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    loginApiResponseObserver.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    loginApiResponseObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    loginApiResponseObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val mContectUsApi: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getContactUs(vName: String, vEmail: String, vMessage: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.mContactUs(vName,vEmail,vMessage )

        mContectUsApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    mContectUsApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    mContectUsApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    mContectUsApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    mContectUsApi.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    // social login
    fun socialLogin(
        vFirstName: String,
        vLastName: String,
        vEmail: String,
        nSignUpType:String,
        vProviderKey: String,
        nLoginDeviceType:String,
        vPushToken: String
    ) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.socialLogin(
                vFirstName,
                vLastName,
                vEmail,
                nSignUpType,
                vProviderKey,
                nLoginDeviceType,
                vPushToken
            )

        loginApiResponseObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    loginApiResponseObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    loginApiResponseObserver.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    loginApiResponseObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    loginApiResponseObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    //update profile - onboard
    val updateProfileApiResponseObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun updateProfile(fields: ArrayList<MultipartBody.Part>) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.editProfile(
                fields
            )
        updateProfileApiResponseObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateProfileApiResponseObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateProfileApiResponseObserver.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    updateProfileApiResponseObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    updateProfileApiResponseObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }
    //update profile - onboard
    val getProfileApiResponseObserver: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getProfile() {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.getProfile()
        getProfileApiResponseObserver.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getProfileApiResponseObserver.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getProfileApiResponseObserver.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getProfileApiResponseObserver.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getProfileApiResponseObserver.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


    //logout
    val logoutApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun logout() {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.logout()
        logoutApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    logoutApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    logoutApiResponseObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    logoutApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    logoutApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    //forgotPassword
    val forgotPasswordApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun forgotPassword(vEmail: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.forgotPassword(vEmail)
        forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    forgotPasswordApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


    //changePassword
    val changePasswordApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun changePassword(vOldPasword: String, vNewPassword: String) {
        val apiCall =
            WebServiceRetrofitUtil.webService!!.changePassword(vOldPasword, vNewPassword)
        changePasswordApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    changePasswordApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    changePasswordApiResponseObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    changePasswordApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    changePasswordApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }




    val privacyPolicyApiResponseObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun getPrivacyPolicy() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getPrivacyPolicy()

        privacyPolicyApiResponseObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    privacyPolicyApiResponseObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    privacyPolicyApiResponseObservable.postValue(
                        Event(ApiResponse().success(data, message))
                    )
                }

                override fun onFailure(message: String) {
                    privacyPolicyApiResponseObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    privacyPolicyApiResponseObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })

    }

    val updateBusinessProfileObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun updateBusinessProfile(fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.manegeBusinessProfile(fields)
        updateBusinessProfileObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateBusinessProfileObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateBusinessProfileObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    updateBusinessProfileObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    updateBusinessProfileObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


    val getBusinessProfileObservable: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getBusinessProfile() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getBusinessProfile()
        getBusinessProfileObservable.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getBusinessProfileObservable.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getBusinessProfileObservable.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getBusinessProfileObservable.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getBusinessProfileObservable.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

}