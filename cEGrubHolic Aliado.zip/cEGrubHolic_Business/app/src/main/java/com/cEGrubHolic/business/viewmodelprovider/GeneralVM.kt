package com.example.godeliverybusinessapp.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.egodelivery.business.viewmodelprovider.Event

import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import java.text.SimpleDateFormat
import java.util.*


/**
 * Created by Ashish on 2/4/19.
 */


class GeneralVM : ViewModel() {

    val appVersionApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getLatestAppVersion() {


        val apiCall =
            WebServiceRetrofitUtil.webService!!.getLatestApkVersion("1")
        appVersionApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    appVersionApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    appVersionApiResponseObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    appVersionApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    appVersionApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

    val aboutUsApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getAboutUs() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getAboutUs()

        aboutUsApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    aboutUsApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    aboutUsApiResponseObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    aboutUsApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    aboutUsApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

    val termsApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getTerms() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getTerms()

        termsApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    termsApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    termsApiResponseObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    termsApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    termsApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

    val privacyPolicyApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getPrivacyPolicy() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getPrivacyPolicy()

        privacyPolicyApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    privacyPolicyApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    privacyPolicyApiResponseObservable.postValue(
                        ApiResponse().success(
                            data,
                            message
                        )
                    )
                }

                override fun onFailure(message: String) {
                    privacyPolicyApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    privacyPolicyApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

    val notificationApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getNotifications() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getNotifications()

        notificationApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    notificationApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    notificationApiResponseObservable.postValue(
                        ApiResponse().success(
                            data,
                            message
                        )
                    )
                }

                override fun onFailure(message: String) {
                    notificationApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    notificationApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

    val getIntialData: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun getIntialDatas() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getIntialData()

        getIntialData.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getIntialData.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getIntialData.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getIntialData.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getIntialData.postValue(Event(ApiResponse().noInternet()))
                }

            }
        )

    }
    val getHistoryList: MutableLiveData<Event<ApiResponse>> = MutableLiveData()
    fun getHistoryListData() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getHistoryList()

        getHistoryList.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getHistoryList.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getHistoryList.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getHistoryList.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getHistoryList.postValue(Event(ApiResponse().noInternet()))
                }

            }
        )

    }


    val getReviewsListApi: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getReviewsList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getReviewsList()

        getReviewsListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getReviewsListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getReviewsListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getReviewsListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getReviewsListApi.postValue(ApiResponse().noInternet())
                }

            }
        )

    }

    val chengeOrderStatusApi: MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun changeOrderStatus(nOrderId:String,nStatus:String,nPreparationTime: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.orderStatusChange(nOrderId,nStatus,nPreparationTime)

        chengeOrderStatusApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    chengeOrderStatusApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    chengeOrderStatusApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    chengeOrderStatusApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    chengeOrderStatusApi.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
    val getEranindDetailsApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getEranindDetails(dFromDate:Date,dToDate:Date) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getEarningData(
                sdf.format(dFromDate),
                sdf.format(dToDate))

        getEranindDetailsApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getEranindDetailsApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getEranindDetailsApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getEranindDetailsApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getEranindDetailsApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val setAppLangugeObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun setAppLanguge(vAppLanguage: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getAppLanguage(vAppLanguage)

        setAppLangugeObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    setAppLangugeObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    setAppLangugeObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    setAppLangugeObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    setAppLangugeObservable.postValue(ApiResponse().noInternet())
                }
            })

    }

  /*  val getCityListObservable: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getCityList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getCityList()

        getCityListObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getCityListObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getCityListObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getCityListObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getCityListObservable.postValue(ApiResponse().noInternet())
                }
            })

    }
    val getFreeCouponsVs: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getFreeCouponList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getFreeCouPonList()

        getFreeCouponsVs.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getFreeCouponsVs.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getFreeCouponsVs.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getFreeCouponsVs.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getFreeCouponsVs.postValue(ApiResponse().noInternet())
                }

            }
        )

    }

    val getBusinessListOnMap: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getBusinessListMapView(nCityId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getBusinessListViewMap(nCityId)

        getBusinessListOnMap.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getBusinessListOnMap.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getBusinessListOnMap.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getBusinessListOnMap.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getBusinessListOnMap.postValue(ApiResponse().noInternet())
                }

            }
        )

    }

    val getDownloadCoupons: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getDownloadCouponList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getDownloadCouponList()

        getDownloadCoupons.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    getDownloadCoupons.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getDownloadCoupons.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getDownloadCoupons.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getDownloadCoupons.postValue(ApiResponse().noInternet())
                }

            }
        )

    }

    val DownloadCoupons: MutableLiveData<ApiResponse> = MutableLiveData()
    fun getDownloadCoupon(nCouponId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getDwonloadCoupon(nCouponId)

        DownloadCoupons.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler{
                override fun sessionExpired() {
                    DownloadCoupons.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    DownloadCoupons.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    DownloadCoupons.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    DownloadCoupons.postValue(ApiResponse().noInternet())
                }

            }
        )

    }*/
  val getRestaurantDetailsApiObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getRestaurantDetails() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getRestaurantDetails()

        getRestaurantDetailsApiObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getRestaurantDetailsApiObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getRestaurantDetailsApiObservable.postValue(
                        ApiResponse().success(
                            data,
                            message
                        )
                    )
                }

                override fun onFailure(message: String) {
                    getRestaurantDetailsApiObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getRestaurantDetailsApiObservable.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getFoodDetailsApiObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getFoodDetails(nFoodId: String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.getFoodDetails(nFoodId = nFoodId)

        getFoodDetailsApiObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getFoodDetailsApiObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getFoodDetailsApiObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getFoodDetailsApiObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getFoodDetailsApiObservable.postValue(ApiResponse().noInternet())
                }
            })
    }

    val reportResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getReports() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getReports()

        reportResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    reportResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    reportResponseObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    reportResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    reportResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }


}