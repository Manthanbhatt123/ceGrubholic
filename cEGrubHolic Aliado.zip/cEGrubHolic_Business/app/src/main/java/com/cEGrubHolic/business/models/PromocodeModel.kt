package com.cEGrubHolic.business.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class PromocodeModel(
    @SerializedName("dValue")
    val dValue: String = "",
    @SerializedName("vTitle")
    val vPromoCode: String = "",
    @SerializedName("vDesc")
    val vDesc: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("dStartDate")
    val dStartDate: String = "",
    @SerializedName("isActive")
    val isActive: String = "",
    @SerializedName("dCapValue")
    val dCapValue: String = "",
    @SerializedName("nChoiceType")
    val nType: String = "",
    @SerializedName("dEndDate")
    val dEndDate: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = "",
    @SerializedName("nCategoryId")
    val nCategoryId: String = "",
    @SerializedName("isFreeDeliveryCharge")
    val isFreeDeliveryCharge: String = "",
    @SerializedName("isFoodSpecific")
    val isFoodSpecific: String = ""

): Serializable


