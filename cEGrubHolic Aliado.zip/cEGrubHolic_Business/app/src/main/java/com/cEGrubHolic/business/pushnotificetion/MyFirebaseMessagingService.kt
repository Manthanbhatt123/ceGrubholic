package com.cEGrubHolic.business.pushnotificetion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.android.volley.BuildConfig
import com.egodelivery.business.R
import com.egodelivery.business.MainActivity


import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_nId
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_nPushType
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_vOther
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_vOther_isSlientRequired
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils
import org.json.JSONObject
import java.util.*


class MyFirebaseMessagingService : FirebaseMessagingService() {
    var sound: Uri =
        Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE )

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.i("MyFirebaseInstanceID", "onTokenRefresh pushToken: $token")
        MyAppPreferenceUtils.savePushToken(applicationContext, token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        //  Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage!!.notification!!.body!!)
        //    Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage.data)

        try {
            Log.d("MyFirebaseMessagingServ", "onMessageReceived : ${remoteMessage.toString()} ")
            Log.i(
                "MyFirebaseMessagingServ",
                "onMessageReceived: " + remoteMessage.notification!!.body!!
            )
            Log.i("FirebaseMessagingSrvice", "onMessageReceived: " + remoteMessage.data)

            sendNotification(remoteMessage)

        } catch (e: Exception) {
            Log.e("MyFirebaseMessagingServ", "onMessageReceived : ${e.printStackTrace()} ")
        }
    }
    private fun sendNotification(remoteMessage: RemoteMessage) {
        val vOtherJson =
            if (remoteMessage.data.containsKey(KEY_NOTIFICATION_vOther) && !remoteMessage.data[KEY_NOTIFICATION_vOther].isNullOrBlank()) {
                JSONObject(remoteMessage.data[KEY_NOTIFICATION_vOther])
            } else {
                null
            }


        val isSilentPush = if (vOtherJson != null) {
            vOtherJson.has(KEY_NOTIFICATION_vOther_isSlientRequired) && vOtherJson[KEY_NOTIFICATION_vOther_isSlientRequired] == 1
        } else {
            false
        }

        val notificationManager =
            getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val notificationChannel: NotificationChannel? = let {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType) &&
                    remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)
                ) {
                    when (remoteMessage.data[KEY_NOTIFICATION_nPushType]) {
                        Constants.nPushType_1_For_Order_recived -> {
                            notificationManager.getNotificationChannel(getString(R.string.notificationChannelOrderRequest))
                        }
                        Constants.nPushType_2_Custemor_cancal_order -> {
                            notificationManager.getNotificationChannel(getString(R.string.orderNotification))
                        }
                        Constants.nPushType_6_Deliveryboy_Delivered_order -> {
                            notificationManager.getNotificationChannel(getString(R.string.orderNotification))
                        }
                        Constants.nPushType_7_Deliveryboy_Accept_order -> {
                            notificationManager.getNotificationChannel(getString(R.string.orderNotification))
                        }
                        Constants.nPushType_8_Deliveryboy_Reject_order -> {
                            notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                        }
                        else -> { //general notifications
                            notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                        }
                    }
                } else { //general notifications
                    notificationManager.getNotificationChannel(getString(R.string.notificationChannelGeneral))
                }
            } else {// not required to create channel
                null
            }
        }


        val intent = Intent(this, MainActivity::class.java)
        val notificationDataBundle = Bundle()



        if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nPushType)) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_nPushType,
                remoteMessage.data[KEY_NOTIFICATION_nPushType]
            )
        }
        if (remoteMessage.data.containsKey(KEY_NOTIFICATION_nId)) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_nId,
                remoteMessage.data[KEY_NOTIFICATION_nId]
            )
        }

        if (vOtherJson != null) {
            notificationDataBundle.putString(
                KEY_NOTIFICATION_vOther,
                vOtherJson.toString()
            )
        }

        intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
        intent.action = Constants.INTENT_ACTION_NOTIFICATION

        val pendingIntent =
            PendingIntent.getActivity(
                this,
                Random(100).nextInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationSoundUri: Uri = Uri.parse(
                ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + BuildConfig.APPLICATION_ID + "/"
                        + resources.getIdentifier(
                    remoteMessage.notification!!.sound,
                    "raw",
                    packageName
                )
            )

            notificationManager.notify(
                getNotificationId(),
                NotificationCompat.Builder(this, notificationChannel!!.id)
                    .setSmallIcon(R.drawable.ic_main_logo)
                    .setColorized(false)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentTitle(remoteMessage.notification?.title)
                    .setContentText(remoteMessage.notification?.body!!)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    .setSound(notificationSoundUri)/*.setCategory(Notification.CATEGORY_EVENT)*/
                    .setColor(ContextCompat.getColor(this, R.color.malachite))
                    .setContentIntent(pendingIntent).build()
            )
        } else {

            val notificationSoundUri: Uri = Uri.parse(
                "android.resource://" + applicationContext
                    .packageName + "/" + resources.getIdentifier(
                    remoteMessage.notification!!.sound,
                    "raw",
                    packageName
                )
            );

            notificationManager.notify(
                getNotificationId(), NotificationCompat.Builder(this, "")
                    .setSmallIcon(R.drawable.ic_main_logo)
                    .setColorized(false)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentTitle(remoteMessage.notification?.title)
                    .setContentText(remoteMessage.notification?.body!!)
                    .setAutoCancel(true)
                    .setOngoing(false)
                    .setSound(notificationSoundUri).setCategory(Notification.CATEGORY_MESSAGE)
                    .setColor(ContextCompat.getColor(this, R.color.malachite))
                    .setContentIntent(pendingIntent).build()
            )
        }
    }


    private fun getNotificationId(): Int {
        return Random().nextInt(9999 - 1000) + 1000
    }

}
