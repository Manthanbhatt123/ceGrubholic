package com.egodelivery.business

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker


open class PermissionActivity : LocationPermissionActivity() {

    // this function will pass permission SUCCESS result to calling Activity
    var callbackFunction: ((Boolean) -> Unit)? = null

    //will show permission result related dialog
    private var alertDialog: AlertDialog? = null

    private val REQUEST_STORAGE_PERMISSION = 1201
    private val STORAGE_PERMISSIONS =
        arrayOf(
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )

    private val REQUEST_CAMERA_PERMISSION = 1202
    private val CAMERA_PERMISSION = Manifest.permission.CAMERA

    //private val REQUEST_LOCATION_PERMISSION = 1203
    /* private val LOCATION_PERMISSION =
         arrayOf(
             Manifest.permission.ACCESS_FINE_LOCATION,
             Manifest.permission.ACCESS_COARSE_LOCATION,
         )*/

    //private val REQUEST_LOCATION_IN_BG_PERMISSION = 1209

    //@RequiresApi(Build.VERSION_CODES.Q)
    //private val LOCATION_IN_BG_PERMISSION = Manifest.permission.ACCESS_BACKGROUND_LOCATION

    private val REQUEST_PHONE_PERMISSION = 1204
    private val PHONE_PERMISSION = Manifest.permission.CALL_PHONE

    private val REQUEST_CALENDER_PERMISSION = 1205
    private val CALENDER_PERMISSION = Manifest.permission.READ_CALENDAR

    private val REQUEST_CONTACTS_PERMISSION = 1206
    private val CONTACTS_PERMISSION = Manifest.permission.READ_CONTACTS

    private val REQUEST_MICROPHONE_PERMISSION = 1207
    private val MICROPHONE_PERMISSION = Manifest.permission.RECORD_AUDIO

    private val REQUEST_SMS_PERMISSION = 1208
    private val SMS_PERMISSION = Manifest.permission.SEND_SMS


    private fun getDialogContent(requestCode: Int): Array<String> {
        val arrayOfContent = arrayOf("Permission", "access data")
        when (requestCode) {
            REQUEST_STORAGE_PERMISSION -> {
                arrayOfContent[0] = "Storage Permission"
                arrayOfContent[1] = "access Gallery and other media files"
            }
            REQUEST_CAMERA_PERMISSION -> {
                arrayOfContent[0] = "Camera Permission"
                arrayOfContent[1] = "capture Photos and Videos"
            }
            /*REQUEST_LOCATION_PERMISSION -> {
                arrayOfContent[0] = "Location Permission"
                arrayOfContent[1] = "access your current location"
            }
            REQUEST_LOCATION_IN_BG_PERMISSION -> {
                arrayOfContent[0] = "Location Permission"
                arrayOfContent[1] = "access your current location in Background"
            }*/
            REQUEST_PHONE_PERMISSION -> {
                arrayOfContent[0] = "Phone Permission"
                arrayOfContent[1] = "make a Phone call"
            }
            REQUEST_CALENDER_PERMISSION -> {
                arrayOfContent[0] = "Calender Permission"
                arrayOfContent[1] = "read calender data"
            }
            REQUEST_CONTACTS_PERMISSION -> {
                arrayOfContent[0] = "Phone Permission"
                arrayOfContent[1] = "make a Phone call"
            }
            REQUEST_MICROPHONE_PERMISSION -> {
                arrayOfContent[0] = "Contact Permission"
                arrayOfContent[1] = "Read contacts"
            }
            REQUEST_SMS_PERMISSION -> {
                arrayOfContent[0] = "SMS Permission"
                arrayOfContent[1] = "send SMS"
            }
        }
        return arrayOfContent
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {

        when (requestCode) {

            REQUEST_STORAGE_PERMISSION,
            REQUEST_CAMERA_PERMISSION,
                //REQUEST_LOCATION_PERMISSION,
            REQUEST_PHONE_PERMISSION,
            REQUEST_CALENDER_PERMISSION,
            REQUEST_CONTACTS_PERMISSION,
            REQUEST_MICROPHONE_PERMISSION,
            REQUEST_SMS_PERMISSION -> {
                //REQUEST_LOCATION_IN_BG_PERMISSION

                val notGrantedPermissions = arrayListOf<String>()

                for (result in grantResults) {
                    if (result != PermissionChecker.PERMISSION_GRANTED) {
                        notGrantedPermissions.add(permissions[grantResults.indexOf(result)])
                    }
                }

                if (notGrantedPermissions.isNotEmpty()) {

                    if (notGrantedPermissions.size == 1) {
                        //if only single permission to be checked
                        showPermissionResultDialog(notGrantedPermissions[0], requestCode)

                    } else {
                        // if multiple permissions were requested then choose first of "notGrantedPermissions" array
                        showPermissionResultDialog(notGrantedPermissions[0], requestCode)

                    }
                } else {
                    //all permission granted
                    /*if (requestCode == REQUEST_LOCATION_PERMISSION) {
                        if (callbackFunction != null) {
                            checkAndAskBackgroundLocationPermission(callbackFunction!!)
                        } else {
                            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
                        }
                    } else*/ if (callbackFunction != null) {
                        callbackFunction!!(true)
                    }
                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        val permission = let {
            when (requestCode) {
                REQUEST_STORAGE_PERMISSION -> {
                    STORAGE_PERMISSIONS[0]
                }
                REQUEST_CAMERA_PERMISSION -> {
                    CAMERA_PERMISSION
                }
                /* REQUEST_LOCATION_PERMISSION -> {
                     LOCATION_PERMISSION[0]
                 }*/
                REQUEST_PHONE_PERMISSION -> {
                    PHONE_PERMISSION
                }
                REQUEST_CALENDER_PERMISSION -> {
                    CALENDER_PERMISSION
                }
                REQUEST_CONTACTS_PERMISSION -> {
                    CONTACTS_PERMISSION
                }
                REQUEST_MICROPHONE_PERMISSION -> {
                    MICROPHONE_PERMISSION
                }
                REQUEST_SMS_PERMISSION -> {
                    SMS_PERMISSION
                }
                /*REQUEST_LOCATION_IN_BG_PERMISSION -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        LOCATION_IN_BG_PERMISSION
                    } else {
                        ""
                    }
                }*/
                else -> {
                    null
                }
            }
        }

        if (permission == null) {
            super.onActivityResult(requestCode, resultCode, data)
        } else {
            checkAndReturnActivityResult(permission, requestCode)
        }

    }


    //private var bgLocationPermissionAlertDialog: AlertDialog? = null

    /*fun checkAndAskLocationPermission(isPermissionGranted: (Boolean) -> Unit) {
        val isGranted = isPermissionGranted(LOCATION_PERMISSION[0])

        if (isGranted) {
            //now check for BG location permission
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.ACCESS_BACKGROUND_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {

                    if (bgLocationPermissionAlertDialog != null && bgLocationPermissionAlertDialog!!.isShowing) {
                        bgLocationPermissionAlertDialog?.dismiss()
                    }

                    //show dialog

                    val backgroundLocationPermissionDialogView =
                        LayoutInflater.from(this@PermissionActivity)
                            .inflate(R.layout.dialog_confirmation, null)

                    bgLocationPermissionAlertDialog =
                        AlertDialogUtil.createCustomAlertDialog(
                            this@PermissionActivity,
                            backgroundLocationPermissionDialogView
                        )


                    backgroundLocationPermissionDialogView.txtDialogTitle.text =
                        getString(R.string.allow_driver)
                    backgroundLocationPermissionDialogView.txtDialogMessage.text =
                        getString(R.string.backgroundPermissionMessage)
                    backgroundLocationPermissionDialogView.btnPositive.text =
                        getString(R.string.continueToPermission)

                    bgLocationPermissionAlertDialog?.setCancelable(false)
                    bgLocationPermissionAlertDialog?.show()
                    bgLocationPermissionAlertDialog?.window?.setBackgroundDrawable(
                        ColorDrawable(
                            Color.TRANSPARENT
                        )
                    )

                    backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

                    backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                        bgLocationPermissionAlertDialog?.dismiss()
                        checkAndAskBackgroundLocationPermission {
                            isPermissionGranted(it)
                        }
                    }
                } else {
                    isPermissionGranted(isGranted)
                }

            } else {
                isPermissionGranted(isGranted)
            }
        } else {


            if (bgLocationPermissionAlertDialog != null && bgLocationPermissionAlertDialog!!.isShowing) {
                bgLocationPermissionAlertDialog?.dismiss()
            }

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@PermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            bgLocationPermissionAlertDialog =
                AlertDialogUtil.createCustomAlertDialog(
                    this@PermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_driver)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositive.text =
                getString(R.string.continueToPermission)

            bgLocationPermissionAlertDialog?.setCancelable(false)
            bgLocationPermissionAlertDialog?.show()
            bgLocationPermissionAlertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                bgLocationPermissionAlertDialog?.dismiss()
                callbackFunction = isPermissionGranted
                requestPermission(LOCATION_PERMISSION, REQUEST_LOCATION_PERMISSION)

            }


        }
    }

    private fun checkAndAskBackgroundLocationPermission(isPermissionGranted: (Boolean) -> Unit) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val isGranted = isPermissionGranted(LOCATION_IN_BG_PERMISSION)

            if (isGranted) {
                isPermissionGranted(isGranted)
            } else {
                callbackFunction = isPermissionGranted
                requestPermission(
                    arrayOf(LOCATION_IN_BG_PERMISSION),
                    REQUEST_LOCATION_IN_BG_PERMISSION
                )
            }
        } else {
            isPermissionGranted(true)
        }
    }*/


    fun checkAndAskStoragePermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(STORAGE_PERMISSIONS[0])

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(STORAGE_PERMISSIONS, REQUEST_STORAGE_PERMISSION)
        }

    }

    fun checkAndAskCameraPermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(CAMERA_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(CAMERA_PERMISSION), REQUEST_CAMERA_PERMISSION)
        }

    }

    fun checkAndAskCallPermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(PHONE_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(PHONE_PERMISSION), REQUEST_PHONE_PERMISSION)
        }


    }

    fun checkAndAskCalenderPermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(CALENDER_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(CALENDER_PERMISSION), REQUEST_CALENDER_PERMISSION)
        }

    }

    fun checkAndAskSMSPermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(SMS_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(SMS_PERMISSION), REQUEST_SMS_PERMISSION)
        }

    }

    fun checkAndAskMicroPhonePermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(MICROPHONE_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(MICROPHONE_PERMISSION), REQUEST_MICROPHONE_PERMISSION)
        }

    }

    fun checkAndAskContactsPermission(isPermissionGranted: (Boolean) -> Unit) {

        val isGranted = isPermissionGranted(CONTACTS_PERMISSION)

        if (isGranted) {
            isPermissionGranted(isGranted)
        } else {
            callbackFunction = isPermissionGranted
            requestPermission(arrayOf(CONTACTS_PERMISSION), REQUEST_CONTACTS_PERMISSION)
        }

    }

    private fun requestPermission(arrayOfPermissions: Array<String>, requestCode: Int) {
        ActivityCompat.requestPermissions(this, arrayOfPermissions, requestCode)
    }

    private fun isPermissionGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun checkAndReturnActivityResult(permission: String, requestCode: Int) {
        if (!isPermissionGranted(permission)) {
            showPermissionResultDialog(permission, requestCode)
        } else {

            /* if (requestCode == REQUEST_LOCATION_PERMISSION) {
                 if (callbackFunction != null) {
                     checkAndAskLocationPermission(callbackFunction!!)
                 } else {
                     callbackFunction!!(true)
                 }
             } else*/ if (callbackFunction != null) {
                callbackFunction!!(true)
            }
        }
    }

    private fun showPermissionResultDialog(permission: String, requestCode: Int) {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            showPermissionRequiredReasonDialog(permission, requestCode)
        } else {
            showPermissionEnableFromSettingDialog(requestCode)
        }

    }

    private fun showPermissionRequiredReasonDialog(
        manifestPermissionName: String,
        requestCode: Int
    ) {

        if (alertDialog != null && alertDialog!!.isShowing) {
            alertDialog?.dismiss()
        }
        val dialogContent = getDialogContent(requestCode)

        val message =
            when (requestCode) {
                REQUEST_STORAGE_PERMISSION -> {
                    getString(R.string.storagePermission)
                }
                REQUEST_CAMERA_PERMISSION -> {
                    getString(R.string.cameraPermission)
                }
                REQUEST_PHONE_PERMISSION -> {
                    getString(R.string.phonePermission)
                }
                /* REQUEST_LOCATION_PERMISSION -> {
                     getString(R.string.locationPermission)
                 }
                 REQUEST_LOCATION_IN_BG_PERMISSION -> {
                     getString(R.string.locationPermission)
                 }*/
                else -> {
                    "${dialogContent[0]} required for ${dialogContent[1]}!"
                }
            }


        /*if (requestCode == REQUEST_LOCATION_PERMISSION || requestCode == REQUEST_LOCATION_IN_BG_PERMISSION) {

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@PermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            alertDialog =
                AlertDialogUtil.createCustomAlertDialog(
                    this@PermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_driver)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositive.text =
                getString(R.string.ok)

            alertDialog?.setCancelable(false)
            alertDialog?.show()
            alertDialog?.window?.setBackgroundDrawable(
                ColorDrawable(
                    Color.TRANSPARENT
                )
            )

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                alertDialog?.dismiss()
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(manifestPermissionName),
                    requestCode
                )
            }
        } else {*/

        // show this dialog if user has denied permission before

        alertDialog = AlertDialog.Builder(this, R.style.DialogTheme)
//            .setTitle(dialogContent[0])
            .setMessage(message)
            .setPositiveButton(getString(R.string.ok)) { dialogInterface, i ->
                //Prompt the user once explanation has been shown
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(manifestPermissionName),
                    requestCode
                )
            }
            .setCancelable(false)
            .create()

        alertDialog!!.show()
        // }
    }


    private fun showPermissionEnableFromSettingDialog(requestCode: Int) {

        if (alertDialog != null && alertDialog!!.isShowing) {
            alertDialog?.dismiss()
        }
        // show this dialog if user has denied permission before
        // and set never ask again checked...
        // result will caught in onActivityResults....

        val dialogContent = getDialogContent(requestCode)

        val message =
            when (requestCode) {
                REQUEST_STORAGE_PERMISSION -> {
                    getString(R.string.storagePermission)
                }
                REQUEST_CAMERA_PERMISSION -> {
                    getString(R.string.cameraPermission)
                }
                REQUEST_PHONE_PERMISSION -> {
                    getString(R.string.phonePermission)
                }
                /* REQUEST_LOCATION_PERMISSION -> {
                     getString(R.string.locationPermission)
                 }
                 REQUEST_LOCATION_IN_BG_PERMISSION -> {
                     getString(R.string.locationPermission)
                 }*/
                else -> {
                    "${dialogContent[0]} required for ${dialogContent[1]}!"
                }
            }

        /*if (requestCode == REQUEST_LOCATION_PERMISSION || requestCode == REQUEST_LOCATION_IN_BG_PERMISSION) {

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@PermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            alertDialog =
                AlertDialogUtil.createCustomAlertDialog(
                    this@PermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_driver)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositive.text =
                getString(R.string.goToSettings)

            alertDialog?.setCancelable(false)
            alertDialog?.show()
            alertDialog?.window?.setBackgroundDrawable(
                ColorDrawable(
                    Color.TRANSPARENT
                )
            )

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                alertDialog?.dismiss()
                val intent = Intent()
                intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivityForResult(intent, requestCode)
            }
        } else {*/
        alertDialog = AlertDialog.Builder(this, R.style.DialogTheme)
//            .setTitle(dialogContent[0])
            .setMessage(message)
            .setPositiveButton(getString(R.string.goToSettings)) { dialogInterface, i ->
                val intent = Intent()
                intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivityForResult(intent, requestCode)
            }.setNegativeButton(getString(R.string.cancel))
            { dialogInterface, i ->
                dialogInterface.dismiss()
            }
            .setCancelable(false)
            .create()


        alertDialog?.show()

        //}
    }


}
