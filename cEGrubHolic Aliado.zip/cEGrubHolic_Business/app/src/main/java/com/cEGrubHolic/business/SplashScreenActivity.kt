package com.egodelivery.business


import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_DATA_BUNDLE
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_nPushType
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils

import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId


class SplashScreenActivity : BaseActivity() {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    private var isAnimationCompleted = false
    private var pendingTaskRunnable: Runnable? = null
    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        if (intent != null && intent.extras != null
            && intent.extras!!.containsKey(KEY_NOTIFICATION_nPushType) && (MyAppPreferenceUtils.isLoggedIn(
                this
            ))
        ) {

            val mainActivityIntent = Intent(this, MainActivity::class.java)
            if (intent != null && intent.extras != null)
                mainActivityIntent.putExtra(KEY_NOTIFICATION_DATA_BUNDLE, intent.extras)

            startActivity(mainActivityIntent)

            finish()

        } else if (!isTaskRoot) {
            finish()
            return
        } else {
            setContentView(R.layout.activity_splash_screen)

            setLightStatusBarWhite()

            FirebaseInstanceId.getInstance().instanceId
                .addOnCompleteListener(OnCompleteListener { task ->
                    if (!task.isSuccessful) {
                        Log.w("Error", "pushToken getInstanceId failed", task.exception)
                        return@OnCompleteListener
                    }
                    // Get new Instance ID token
                    task.result?.token?.let {
                        MyAppPreferenceUtils.savePushToken(this, it)
//                    Log.i("ABCD",""+MyAppPreferenceUtils.getPushToken(this))

                    }
                })


            Handler().postDelayed({
                if (MyAppPreferenceUtils.isLoggedIn(this)) {

                    val mainActivityIntent = Intent(this, MainActivity::class.java)
                    isAnimationCompleted = true
                    if (intent != null && intent.extras != null)
                        mainActivityIntent.putExtra(KEY_NOTIFICATION_DATA_BUNDLE, intent.extras)

                    startActivity(mainActivityIntent)

                    finish()

                } else {

                    startActivity(Intent(this, LogInActivity::class.java))
                    finish()
                }
                /*  startActivity(Intent(this, LogInActivity::class.java))
                  finish()*/

            }, 2000)



        }
    }



}
