package com.egodelivery.business.fragment

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.egodelivery.business.R
import com.egodelivery.business.BaseActivity
import com.cEGrubHolic.business.BaseFragment
import com.cEGrubHolic.business.adapter.AddMiddifierMenuListAdepter
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.cEGrubHolic.business.models.ProductListModel
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.egodelivery.business.utils.Constants

import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.egodelivery.business.viewmodelprovider.ModifierGroupListVM
import com.egodelivery.business.utils.Constants.PROFILE_IMAGE_REQ_CODE
import com.github.dhaval2404.imagepicker.ImagePicker

import kotlinx.android.synthetic.main.fragment_add_and_edit_menu_item.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File


class AddAndEditMenuItemFragment : BaseFragment(), AddMiddifierMenuListAdepter.ItemClickListener {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }
    private val userViewModels by lazy {
        ViewModelProvider(this).get(ModifierGroupListVM::class.java)
    }
    val mModifierList = arrayListOf<ModifierGroupModel>()
/*
    private val listOfCheckBoxView = arrayListOf<MaterialCheckBox>()
*/
private var categoryitemListModel : ProductListModel?=null
private var isForUpdate = false

    val addModifierListAdepter: AddMiddifierMenuListAdepter =
        AddMiddifierMenuListAdepter(mModifierList, this)

    private var selectedProfileFile: File? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_and_edit_menu_item, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerAddModifier.adapter = addModifierListAdepter

        textcategoryold.setText("Old Price"+"("+Constants.vCurrentCurrencySymbol+")")
        textcategorynew.setText("New Price"+"("+Constants.vCurrentCurrencySymbol+")")



        val getFragment =   arguments!!.getInt(Constants.CUSTMISED_FOOD_CART,0)
        isForUpdate = getFragment==1

        if(isForUpdate){
            val dataOFProduct = arguments!!.getSerializable(Constants.KEY_FOOD_MODEL) as ProductListModel

            updateDataOfFood(dataOFProduct)

            imageChangePic.visibility = View.VISIBLE
            imageChangePic.setOnClickListener {
                (activity as BaseActivity).checkAndAskStoragePermission { isStoragePermissionGranted ->
                    if (isStoragePermissionGranted) {
                        (activity as BaseActivity).checkAndAskCameraPermission { isCameraPermissionGranted ->
                            if (isCameraPermissionGranted) {
                                ImagePicker.with(this)
                                    .crop()
                                    .setImageProviderInterceptor { imageProvider -> // Intercept ImageProvider
                                        Log.d("ImagePicker", "Selected ImageProvider: " + imageProvider.name)
                                    }
                                    .setDismissListener {
                                        Log.d("ImagePicker", "Dialog Dismiss")
                                    }
                                    // Image resolution will be less than 512 x 512
                                    //.maxResultSize(200, 200)
                                    .start(Constants.PROFILE_IMAGE_REQ_CODE)


                            /*    CropImage.activity()
                                    .setGuidelines(CropImageView.Guidelines.ON).setFixAspectRatio(true)
                                    .start(context!!, this)*/
                            }
                        }
                    }
                }
            }

        }







        imageFirsts.setOnClickListener {
            (activity as BaseActivity).checkAndAskStoragePermission { isStoragePermissionGranted ->
                if (isStoragePermissionGranted) {
                    (activity as BaseActivity).checkAndAskCameraPermission { isCameraPermissionGranted ->
                        if (isCameraPermissionGranted) {
                            ImagePicker.with(this)
                                .crop()
                                .setImageProviderInterceptor { imageProvider -> // Intercept ImageProvider
                                    Log.d("ImagePicker", "Selected ImageProvider: " + imageProvider.name)
                                }
                                .setDismissListener {
                                    Log.d("ImagePicker", "Dialog Dismiss")
                                }
                                // Image resolution will be less than 512 x 512
                                //.maxResultSize(200, 200)
                                .start(Constants.PROFILE_IMAGE_REQ_CODE)
                        }
                    }
                }
            }
        }



        if (!userViewModel.upDateFoodItemCategoryWiseApi.hasActiveObservers()) {
            userViewModel.upDateFoodItemCategoryWiseApi.observe(
                    activity!!,
                    androidx.lifecycle.Observer {

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                                showProgress(getString(R.string.loding), false)
                            }
                            ApiResponseStatus.SUCCESS -> {
                                hideProgress()

                                showSnackbar(
                                        imageFirsts,
                                        it.message,
                                        SnackbarUtils.SnackbarType.SUCCESS
                                )
                                Handler().postDelayed({
                                    if (activity != null) {
                                        Activity.RESULT_OK
                                        activity!!.finish()
                                    }
                                }, 1500)

                            }
                            ApiResponseStatus.ERROR -> {
                                hideProgress()
                                showSnackbar(
                                        imageFirsts,
                                        it.message,
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                hideProgress()
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                hideProgress()
                                showSnackbar(
                                        imageFirsts,
                                    getString(R.string.no_internet),
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            else -> {

                            }

                        }

                    })
        }
        if (!userViewModel.addFoodItemCategoryWiseApi.hasActiveObservers()) {
            userViewModel.addFoodItemCategoryWiseApi.observe(
                    activity!!,
                    androidx.lifecycle.Observer {

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                                showProgress(getString(R.string.loding), false)
                            }
                            ApiResponseStatus.SUCCESS -> {
                                hideProgress()

                                showSnackbar(
                                        imageFirsts,
                                        it.message,
                                        SnackbarUtils.SnackbarType.SUCCESS
                                )
                                Handler().postDelayed({
                                    if (activity != null) {
                                        Activity.RESULT_OK
                                        activity!!.finish()
                                    }
                                }, 1500)

                            }
                            ApiResponseStatus.ERROR -> {
                                hideProgress()
                                showSnackbar(
                                        imageFirsts,
                                        it.message,
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                hideProgress()
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                hideProgress()
                                showSnackbar(
                                        imageFirsts,
                                    getString(R.string.no_internet),
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            else -> {

                            }

                        }

                    })
        }



        if (!userViewModels.getModifierGroupListApi.hasActiveObservers()) {
            userViewModels.getModifierGroupListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {

                        }
                        ApiResponseStatus.SUCCESS -> {


                            mModifierList.clear()
                            mModifierList.addAll(
                                Gson().fromJson(
                                    it.data,
                                    object : TypeToken<List<ModifierGroupModel>>() {}.type
                                )
                            )
                            addModifierListAdepter.notifyDataSetChanged()


                            if(isForUpdate) {
                                val dataOFProduct = arguments!!.getSerializable(Constants.KEY_FOOD_MODEL) as ProductListModel
                                val ids = dataOFProduct.vModifierIds.split(",")
                                if (ids.isNotEmpty()) {
                                    for (item in mModifierList) {
                                        if (ids.contains(item.id)) {
                                            item.isSelected = true
                                        }
                                    }

                                    addModifierListAdepter.notifyDataSetChanged()
                                }
                            }
                        }
                        ApiResponseStatus.ERROR -> {


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {


                        }
                        else -> {

                        }

                    }

                })
        }





        userViewModels.getModifierGroupList()




        relProductDone.setOnClickListener {
            val getFragment =   arguments!!.getInt(Constants.CUSTMISED_FOOD_CART,0)
            when(getFragment){
                0->{
                    if (isValidForm()){
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "vImagePath", selectedProfileFile!!.name,
                                        RequestBody.create(
                                                MediaType.parse("image/*"),
                                                selectedProfileFile!!
                                        )
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "nCategoryId",
                                        arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "vName",
                                        edtManuItemName.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "dOldPrice",
                                        edtMenuItemOldPrice.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "dNewPrice",
                                        edtMenuNewPrice.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "vDesc",
                                        edtDescription.text.toString().trim()
                                )
                        )
                        if (swichActiveCategoryAddItem.isChecked) {
                            multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                            "isActive",
                                            "1"
                                    )
                            )
                        } else {
                            multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                            "isActive",
                                            "0"
                                    )
                            )
                        }
                        if (mModifierList.isEmpty()) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "vModifierIds",
                                    ""
                                )
                            )
                        } else {
                            val sbString = StringBuilder("")
                            for (item in mModifierList) {

                                if (item.isSelected) {
                                    sbString.append(item.id).append(",")
                                }
                            }
                            if (sbString.isNotEmpty())
                                sbString.deleteCharAt(sbString.lastIndex)
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "vModifierIds",
                                    sbString.toString()
                                )
                            )
                        }

                        userViewModel.addFoodItemCategoryWise(multipartArray)
                    }

                }
                1->{
                    if (isValidForm()){
                        val dataOFProduct = arguments!!.getSerializable(Constants.KEY_FOOD_MODEL) as ProductListModel
                        val multipartArray = arrayListOf<MultipartBody.Part>()

                        if (selectedProfileFile != null)
                            multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                            "vImagePath", selectedProfileFile!!.name,
                                            RequestBody.create(
                                                    MediaType.parse("image/*"),
                                                    selectedProfileFile!!
                                            )
                                    )
                            )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "nCategoryId",
                                        arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "nProductId",
                                        dataOFProduct.id
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "vName",
                                        edtManuItemName.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "dOldPrice",
                                        edtMenuItemOldPrice.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "dNewPrice",
                                        edtMenuNewPrice.text.toString().trim()
                                )
                        )
                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "vDesc",
                                        edtDescription.text.toString().trim()
                                )
                        )
                        if (swichActiveCategoryAddItem.isChecked) {
                            multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                            "isActive",
                                            "1"
                                    )
                            )
                        } else {
                            multipartArray.add(
                                    MultipartBody.Part.createFormData(
                                            "isActive",
                                            "0"
                                    )
                            )
                        }
                        if (mModifierList.isEmpty()) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "vModifierIds",
                                    ""
                                )
                            )
                        } else {
                            val sbString = StringBuilder("")
                            for (item in mModifierList) {

                                if (item.isSelected) {
                                    sbString.append(item.id).append(",")
                                }
                            }
                            if (sbString.isNotEmpty())
                                sbString.deleteCharAt(sbString.lastIndex)
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "vModifierIds",
                                    sbString.toString()
                                )
                            )
                        }

                        userViewModel.upDateFoodItemCategoryWise(multipartArray)
                    }
                }
            }
        }
    }
    private fun updateDataOfFood(mCategoryitemListModel: ProductListModel) {
        edtManuItemName.setText(mCategoryitemListModel.vProductName)
        edtMenuItemOldPrice.setText(mCategoryitemListModel.vProductOldPrice)
        edtMenuNewPrice.setText(mCategoryitemListModel.vProductPrice)
        Glide.with(this).load(mCategoryitemListModel.vImagePAth)
            .into(imageFirsts)
        edtDescription.setText(mCategoryitemListModel.vDesc)
        swichActiveCategoryAddItem.isChecked = mCategoryitemListModel.isActive == "1"



     /*   if (mCategoryitemListModel.isCrossSelling == "1") {
            swichFoodItemseliing.isChecked = true
        } else if (mCategoryitemListModel.isCrossSelling == "0") {
            swichFoodItemseliing.isChecked = false
        }*/




        val ids = mCategoryitemListModel.vModifierIds.split(",")
        if (ids.isNotEmpty()) {
            for (item in mModifierList) {
                if (ids.contains(item.id)) {
                    item.isSelected = true
                }
            }
            addModifierListAdepter.notifyDataSetChanged()
        }


    }

    fun setLocalImage(uri: Uri) {
        selectedProfileFile = File(uri.path!!)

        Glide.with(this).load(uri.path.toString()).into(imageFirsts)


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                PROFILE_IMAGE_REQ_CODE ->{
                    val uri: Uri = data?.data!!
                    setLocalImage(uri)
                }
               /* CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE -> {
                    val cropResult = CropImage.getActivityResult(data)
                    if (resultCode == Activity.RESULT_OK) {


                        selectedProfileFile = File(cropResult.uri.path)
                        Glide.with(this).load(cropResult.uri).into(imageFirsts)


                    } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                        val error = cropResult.error

                        try {
                            showSnackbar(
                                relProductDone,
                                error.message!!,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        } catch (e: Exception) {
                            Log.e("ProfileFragment", "onActivityResult : ${e.message} ")
                        }
                    }
                }*/


            }
        }
    }

    private fun isValidForm(): Boolean {


        val getUpdateData = arguments!!.getInt(Constants.CUSTMISED_FOOD_CART)
        when (getUpdateData) {
            0 -> {
                if (selectedProfileFile == null) {
                    imageFirsts.requestFocus()
                    showSnackbar(
                        imageFirsts,
                        getString(R.string.select_food_image),
                        SnackbarUtils.SnackbarType.WARNING
                    )
                    return false
                }
            }
        }

        if (!FormValidationUtils.isValidText(edtManuItemName.text.toString().trim())) {
            edtManuItemName.requestFocus()
            showSnackbar(
                edtManuItemName,
               getString(R.string.enter_titlel_product),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }else if (!FormValidationUtils.isValidText(edtDescription.text.toString().trim())) {
            edtDescription.requestFocus()
            showSnackbar(
                edtDescription,
                getString(R.string.plase_add_item_decs),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else  if (!FormValidationUtils.isValidText(edtMenuItemOldPrice.text.toString().trim())) {
            edtMenuItemOldPrice.requestFocus()
            showSnackbar(
                edtMenuItemOldPrice,
               getString(R.string.enter_product_old),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }else  if (!FormValidationUtils.isValidText(edtMenuNewPrice.text.toString().trim())) {
            edtMenuNewPrice.requestFocus()
            showSnackbar(
                edtMenuNewPrice,
               getString(R.string.enter_product),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else{
            return true
        }
    }

    override fun onItemClicked(menuPos: ModifierGroupModel) {
        for (item in mModifierList) {
            if (item.id == menuPos.id) {
                item.isSelected = !item.isSelected
            }
        }
        addModifierListAdepter.notifyDataSetChanged()

    }



}