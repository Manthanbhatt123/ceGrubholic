package com.cEGrubHolic.business

import android.app.Activity
import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.util.Log
import com.egodelivery.business.*

/**
 * Created by Ashish on 26/7/19.
 */


class BaseApplication : Application() {




    var latestVersionOfApp = 0.0f

    val activityLifecycleCallbacks = object : ActivityLifecycleCallbacks {
        override fun onActivityResumed(activity: Activity) {

            Log.i("BaseApplication", "onActivityResumed : $activity ")

            if (activity !is SplashScreenActivity &&
                activity !is LogInActivity &&
                activity !is ForgotPasswordActivity
            ) {
                if (activity is BaseActivity) {
                    activity.checkAppVersion()
                }

            }
        }

        override fun onActivityPaused(activity: Activity) {

        }

        override fun onActivityStarted(activity: Activity) {

        }

        override fun onActivityDestroyed(activity: Activity) {

        }

        override fun onActivityStopped(activity: Activity) {

        }

        override fun onActivitySaveInstanceState(p0: Activity, p1: Bundle) {


        }

        override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {

        }
    }

    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(activityLifecycleCallbacks)



        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val notificationChannelGeneral = NotificationChannel(
                getString(R.string.notificationChannelGeneral),
                getString(R.string.notificationChannelGeneral),
                NotificationManager.IMPORTANCE_DEFAULT
                )
            val orderRicvedNotification = NotificationChannel(
                getString(R.string.notificationChannelOrderRequest),
                getString(R.string.notificationChannelOrderRequest),
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val orderNotificationChannel = NotificationChannel(
                getString(R.string.orderNotification),
                getString(R.string.orderNotification),
                NotificationManager.IMPORTANCE_DEFAULT
            )


            notificationChannelGeneral.enableVibration(true)
            notificationManager.createNotificationChannel(notificationChannelGeneral)
            notificationManager.createNotificationChannel(orderRicvedNotification)
            notificationManager.createNotificationChannel(orderNotificationChannel)

        }
    }

    override fun onTerminate() {
        super.onTerminate()
        unregisterActivityLifecycleCallbacks(activityLifecycleCallbacks)
    }


}