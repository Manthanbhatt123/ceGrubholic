package com.cEGrubHolic.business.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.ManageManuesActivity
import com.egodelivery.business.R
import com.cEGrubHolic.business.adapter.PromocodeListAdepter
import com.cEGrubHolic.business.models.PromocodeModel
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.viewmodelprovider.PromocodeVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_manu_promocode_list.*
import kotlinx.android.synthetic.main.view_no_data.*

class ManuPromocodeListFragment : BaseFragment(), PromocodeListAdepter.ItemClickListener {

    val listOfPromocode = arrayListOf<PromocodeModel>()
    var promocodeAdepter: PromocodeListAdepter = PromocodeListAdepter(listOfPromocode, this)

    private val userViewModel by lazy {
        ViewModelProvider(this).get(PromocodeVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_manu_promocode_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerForPromocode.visibility = View.GONE
        viewModeObserver()

        refreshPromocodeList.setOnRefreshListener {
            userViewModel.getPromocodeList()
        }
    }

    fun viewModeObserver() {
        if (!userViewModel.getPromocodeListApi.hasActiveObservers()) {
            userViewModel.getPromocodeListApi.observe(
                activity!!,
                androidx.lifecycle.Observer { it ->
                    when (it.status) {
                        ApiResponseStatus.LOADING -> {
                            refreshPromocodeList.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            refreshPromocodeList.isRefreshing = false

                            listOfPromocode.clear()
                            listOfPromocode.addAll(
                                Gson().fromJson(
                                    it.data!!,
                                    object : TypeToken<List<PromocodeModel>>() {}.type
                                )
                            )


                            recyclerForPromocode.adapter = promocodeAdepter
                            promocodeAdepter.notifyDataSetChanged()
                            showDetailView(true, it.message)

                        }
                        ApiResponseStatus.ERROR -> {

                            refreshPromocodeList.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            refreshPromocodeList.isRefreshing = false
                            showDetailView(false, getString(R.string.no_internet))

                        }
                        else -> {
                            refreshPromocodeList.isRefreshing = false
                        }

                    }


                })
        }
        if (!userViewModel.removePromocodeListApi.hasActiveObservers()) {
            userViewModel.removePromocodeListApi.observe(
                activity!!,
                androidx.lifecycle.Observer { it ->
                    when (it.status) {
                        ApiResponseStatus.LOADING -> {
                            refreshPromocodeList.isRefreshing = true
                        }
                        ApiResponseStatus.SUCCESS -> {
                            refreshPromocodeList.isRefreshing = false

                            userViewModel.getPromocodeList()
                            promocodeAdepter.notifyDataSetChanged()
                            showDetailView(true, it.message)

                        }
                        ApiResponseStatus.ERROR -> {

                            refreshPromocodeList.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            refreshPromocodeList.isRefreshing = false
                            showDetailView(false, getString(R.string.no_internet))

                        }
                        else -> {
                            refreshPromocodeList.isRefreshing = false
                        }

                    }


                })
        }
    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recyclerForPromocode.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recyclerForPromocode.visibility = View.GONE

        }
    }

    override fun onResume() {
        userViewModel.getPromocodeList()
        super.onResume()

    }



    override fun onItemClicked(menuPos: PromocodeModel) {


    }

    override fun editPromocode(vEditPromocode: PromocodeModel) {
        startActivityForResult(
            Intent(requireContext(), ManageManuesActivity::class.java)
                .putExtra(Constants.OPEN_ADD_FRAGMENT, 7)
                .putExtra(Constants.FOR_API_CALLING_PROMOCODE,2)
                .putExtra(Constants.GET_PROMOCODE_DATA, vEditPromocode),
            Constants.RC_ADD_AND_UPDATE_CATEGORY
        )
    }

    override fun deletePromocode(vDeletePromocode: PromocodeModel) {
        userViewModel.removePromocodeList(vDeletePromocode.id)
    }


}