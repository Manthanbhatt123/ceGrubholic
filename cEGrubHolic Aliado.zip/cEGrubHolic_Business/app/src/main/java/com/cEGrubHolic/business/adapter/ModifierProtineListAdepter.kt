package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import kotlinx.android.synthetic.main.row_modifier_protine.view.*

import java.util.ArrayList

class ModifierProtineListAdepter(val modifierProtinList: ArrayList<ModifierGroupModel>,
                                 val itemClickListener: ItemClickListener
): RecyclerView.Adapter<ModifierProtineListAdepter.MyViewHolder>() {
    var vSymbol = "Bs "
    var dConversionRate = "1"

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_modifier_protine,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return modifierProtinList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.txtProtineDesplayName.text = modifierProtinList[position].vName
        holder.itemView.txtProtineItemCost.text = FormValidationUtils.getValueWithCurrencyCode(
            modifierProtinList[position].dCost.toDouble(),
            Constants.vCurrentCurrencySymbol ,
          dConversionRate
        )


        holder.itemView.txtProtineSequenceNumber.text = modifierProtinList[position].nSequenceNo
      /*  if (Constants.isModificationEnable == 0){
            holder.itemView.imageProtineEditModifier.visibility = View.GONE
            holder.itemView.imageProtineDeletModifier.visibility = View.GONE
        }*/

    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(modifierProtinList[layoutPosition])
            }
            itemView.imageProtineEditModifier.setOnClickListener {
                itemClickListener.onEditClicked(modifierProtinList[layoutPosition])
            }
            itemView.imageProtineDeletModifier.setOnClickListener {
                itemClickListener.onDeletedClicked(modifierProtinList[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: ModifierGroupModel

        )
        fun onEditClicked(
            menuPos: ModifierGroupModel
        )
        fun onDeletedClicked(
            menuPos: ModifierGroupModel
        )

    }
}