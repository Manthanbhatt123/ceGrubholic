package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName

data class MonthlyOrderModel(
    @SerializedName("months")
    val monthOfOrders: String = "",
    @SerializedName("totalOrder")
    val vTotalOrders: Int = 0
)
