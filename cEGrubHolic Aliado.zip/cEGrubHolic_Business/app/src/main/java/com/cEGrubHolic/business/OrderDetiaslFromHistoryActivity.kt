package com.egodelivery.business

import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.adapter.FoodListForOrderDetailsAdepter
import com.egodelivery.business.models.OrderDetailsmodel
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.cEGrubHolic.business.models.FoodTitleModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.activity_order_details.*
import kotlinx.android.synthetic.main.activity_order_detiasl_from_history.*
import kotlinx.android.synthetic.main.app_main_toolbar.*

class OrderDetiaslFromHistoryActivity : BaseActivity() {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }

    var currency = ""
    val conversionRate = "1"

    val vFoodlistModel = arrayListOf<FoodTitleModel>()
    val foodListAdepter: FoodListForOrderDetailsAdepter = FoodListForOrderDetailsAdepter(vFoodlistModel)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_detiasl_from_history)
        currency = Constants.vCurrentCurrencySymbol
        btnLeft.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.ic_back))
        btnLeft.setOnClickListener {
            finish()
        }
        tvTitle.text = getString(R.string.order_details)
        val orderStatus = intent.getStringExtra(Constants.KEY_USER_NAME)
        if (orderStatus == "3"){
            tvOrderStatusof.text =   getString(R.string.completed)
            tvOrderStatusof.setTextColor(Color.GREEN)
        }else{
            tvOrderStatusof.text =   getString(R.string.rejected)
            tvOrderStatusof.setTextColor(Color.RED)
        }



        if (!userViewModel.getOrderDetaislApi.hasActiveObservers())
            userViewModel.getOrderDetaislApi.observe(
                this,
                Observer {

                    it.getContentIfNotHandled()?.let { apiResponse ->
                        when (apiResponse.status) {

                            ApiResponseStatus.LOADING -> {
                                orderDetalisForHistoryRefresh.isRefreshing = true

                            }
                            ApiResponseStatus.SUCCESS -> {
                                orderDetalisForHistoryRefresh.isRefreshing = false

                                upDateUiOrderDetails(
                                    Gson().fromJson(
                                        apiResponse.data,
                                        object : TypeToken<OrderDetailsmodel>() {}.type
                                    )
                                )

                                recycerlOrderItemsHi.adapter = foodListAdepter
                                vFoodlistModel.clear()
                                vFoodlistModel.addAll(
                                    Gson().fromJson(
                                        apiResponse.data!!.asJsonObject["FoodData"],
                                        object : TypeToken<List<FoodTitleModel>>() {}.type
                                    )
                                )


                                foodListAdepter.notifyDataSetChanged()
                                //      showDetailView(apiResponse.message, true)
                            }

                            ApiResponseStatus.ERROR -> {
                                orderDetalisForHistoryRefresh.isRefreshing = false
                                //     hideProgress()
                                //     showDetailView(apiResponse.message, false)

                            }

                            ApiResponseStatus.NO_INTERNET -> {
                                orderDetalisForHistoryRefresh.isRefreshing = false
                                showSnackbar(
                                    orderDetalisForHistoryRefresh,
                                    getString(R.string.no_internet),
                                    SnackbarUtils.SnackbarType.ERROR
                                )
                                //    showDetailView(apiResponse.message, false)

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                orderDetailsRifreshh.isRefreshing = false

                                destroyLoginSession(true)
                            }
                        }
                    }
                })

        orderDetalisForHistoryRefresh.setOnRefreshListener {
            userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)
        }
        userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)
    }
    private fun upDateUiOrderDetails(mOrderDetailsmodel: OrderDetailsmodel) {
        tvItemDetailsNoteOrderHI.text = mOrderDetailsmodel.vRecommendationNote
        tvOrderDitailsReceiptNameHI.text = mOrderDetailsmodel.vReciptName
        tvOrderDetailsNitHI.text = mOrderDetailsmodel.vNITno

        tvOrderBillNoHi.text ="#"+ mOrderDetailsmodel.vOrderId
        tvOrderDateTimeHi.text = mOrderDetailsmodel.dCreatedDate

        if (mOrderDetailsmodel.vNickName.isEmpty()){
            tvOrdeHomelocHI.visibility = View.GONE
        }else{
            tvOrdeHomelocHI.text = mOrderDetailsmodel.vNickName
        }

        tvOrdeAddrssLocationHi.text = mOrderDetailsmodel.vAddress

        tvSubTotalsHi.text =  FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dSubTotal, currency, conversionRate
        )
        tvTaxAmountsHi.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dTaxAmount, currency, conversionRate
        )

        tvDeliveryChargesHi.text =  FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dDeliveryCharge, currency, conversionRate
        )
        tvDiscountsHi.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dDiscount, currency, conversionRate
        )

        tvPackagingChargeHi.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dPackagingCharge, currency, conversionRate
        )
        tvTotalOrderAmountsHi.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dGrandTotal, currency, conversionRate
        )

        if (mOrderDetailsmodel.nPaymentType=="1"){
            txtPyamentTypeHi.text = getString(R.string.cod)
        }

        val mCustomerData = mOrderDetailsmodel.vCustomerData
       tvOrderDitelasUserNameHi.text = mCustomerData[0].vName
        tvOrderDetailsUserContectHi.text = mCustomerData[0].vMobileNo

        if (mOrderDetailsmodel.nStatus == "0") {
            tvOrdarStatus.text = getString(R.string.order_received) + " " + getString(R.string.on)
        } else if (mOrderDetailsmodel.nStatus == "1") {
            tvOrdarStatus.text = getString(R.string.orderaccepted)+ " " + getString(R.string.on)
        } else if (mOrderDetailsmodel.nStatus == "2") {
            tvOrdarStatus.text = getString(R.string.orderdispatched)+ " " + getString(R.string.on)
        }else if (mOrderDetailsmodel.nStatus == "3") {
            tvOrdarStatus.text = getString(R.string.order_delivered)+ " " + getString(R.string.on)
        }else if (mOrderDetailsmodel.nStatus == "4") {
            tvOrdarStatus.text = getString(R.string.order_cencel)+ " " + getString(R.string.on)
        }
    }
}