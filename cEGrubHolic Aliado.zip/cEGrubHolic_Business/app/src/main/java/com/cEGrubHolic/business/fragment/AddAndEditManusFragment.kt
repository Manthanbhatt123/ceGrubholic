package com.cEGrubHolic.business.fragment

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment
import com.cEGrubHolic.business.models.CategoryListModel

import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_add_and_edit_manus.*
import okhttp3.MultipartBody


class AddAndEditManusFragment : BaseFragment() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_and_edit_manus, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!userViewModel.upDateFoodCategoryApi.hasActiveObservers()) {
            userViewModel.upDateFoodCategoryApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            showSnackbar(
                                relCategoryName,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                if (activity != null) {
                                    Activity.RESULT_OK
                                    activity!!.finish()
                                }
                            }, 1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                relCategoryName,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                relCategoryName,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })
        }



        if (!userViewModel.addCategoryApi.hasActiveObservers()) {
            userViewModel.addCategoryApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            showSnackbar(
                                relCategoryName,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                if (activity != null){
                                    Activity.RESULT_OK
                                    activity!!.finish()
                                }
                            }, 1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                relCategoryName,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                relCategoryName,
                              getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })
        }
        val getUpdateData = arguments!!.getInt(Constants.OPEN_ADD_FRAGMENT)
        when(getUpdateData){
            1->{
                val getEditebalData = arguments!!.getSerializable(Constants.SEND_CATEGORY_DATA) as CategoryListModel
                edtFoodCategory.setText(getEditebalData.vName)
                edtSqunsno.setText(getEditebalData.nSequenceNo)
                swichActiveCategoryAdd.isChecked = getEditebalData.isActive == "1"

            }
        }




        relCategoryName.setOnClickListener {
            val getUpdateData = arguments!!.getInt(Constants.OPEN_ADD_FRAGMENT)
            when(getUpdateData){
                0->{
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vName",
                                edtFoodCategory.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtSqunsno.text.toString().trim()
                            )
                        )

                        if (swichActiveCategoryAdd.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }

                        userViewModel.addCategoryList(multipartArray)
                    }

                }
                1->{
                    val getEditebalData = arguments!!.getSerializable(Constants.SEND_CATEGORY_DATA) as CategoryListModel
                    if (isValidForm()) {
                        val multipartArray = arrayListOf<MultipartBody.Part>()

                        multipartArray.add(
                                MultipartBody.Part.createFormData(
                                        "nCategoryId",
                                        getEditebalData.id
                                )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vName",
                                edtFoodCategory.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtSqunsno.text.toString().trim()
                            )
                        )

                        if (swichActiveCategoryAdd.isChecked) {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        } else {
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }
                        userViewModel.upDateFoodCategory(multipartArray)
                    }
                }
            }

        }


    }


    private fun isValidForm(): Boolean {


        if (!FormValidationUtils.isValidText(edtFoodCategory.text.toString().trim())) {
            edtFoodCategory.requestFocus()
            showSnackbar(
                edtFoodCategory,
                getString(R.string.plase_add_catergy_name),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }  else  if (!FormValidationUtils.isValidText(edtSqunsno.text.toString().trim())) {
            edtSqunsno.requestFocus()
            showSnackbar(
                edtSqunsno,
                getString(R.string.plase_add_sequns_no),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }else{
            return true
        }
    }


}