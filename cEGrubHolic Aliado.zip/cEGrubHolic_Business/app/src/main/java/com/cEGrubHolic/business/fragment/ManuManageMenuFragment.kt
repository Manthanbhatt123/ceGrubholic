package com.cEGrubHolic.business.fragment


import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.ManageManuesActivity
import com.cEGrubHolic.business.adapter.ManageManusListAdepter
import com.cEGrubHolic.business.models.CategoryListModel
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.cEGrubHolic.business.utils.AlertDialogUtil
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.RC_ADD_AND_UPDATE_CATEGORY
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.dialog_confirmation_for_delete.view.*
import kotlinx.android.synthetic.main.fragment_menu_manage_menu.*
import kotlinx.android.synthetic.main.view_no_data.*


class ManuManageMenuFragment : BaseFragment(), ManageManusListAdepter.ItemClickListener {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }


    val vListOfManus = arrayListOf<CategoryListModel>()
    val mManageManusAdepter: ManageManusListAdepter = ManageManusListAdepter(vListOfManus,this)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment



        return inflater.inflate(R.layout.fragment_menu_manage_menu, container, false)

    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        recyclerViewMAnegeManu.adapter = mManageManusAdepter

        if (!userViewModel.getMenuCategoryListApi.hasActiveObservers()) {
            userViewModel.getMenuCategoryListApi.observe(
                    requireActivity(),
                    androidx.lifecycle.Observer {
                        when (it?.status) {
                            ApiResponseStatus.LOADING -> {
                                if (swipetoRefreshMenuCategory != null){
                                    swipetoRefreshMenuCategory.isRefreshing = true
                                }
                            }
                            ApiResponseStatus.SUCCESS -> {
                                if (swipetoRefreshMenuCategory != null) {
                                    swipetoRefreshMenuCategory.isRefreshing = false
                                    vListOfManus.clear()
                                    vListOfManus.addAll(
                                            Gson().fromJson(
                                                    it.data,
                                                    object : TypeToken<List<CategoryListModel>>() {}.type
                                            )
                                    )
                                    mManageManusAdepter.notifyDataSetChanged()
                                }
                                showDetailView(true, it.message)
                            }
                            ApiResponseStatus.ERROR -> {
                                if (swipetoRefreshMenuCategory != null) {

                                    swipetoRefreshMenuCategory.isRefreshing = false
                                    showDetailView(false, it.message)
                                }
                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                swipetoRefreshMenuCategory.isRefreshing = false

                               showDetailView(false, getString(R.string.no_internet))
                            }
                            else -> {
                                swipetoRefreshMenuCategory.isRefreshing = false
                               showDetailView(false, Constants.INTERNAL_SERVER_ERROR)
                            }

                        }

                    })
        }


        if (!userViewModel.removeCategoryApi.hasActiveObservers()) {
            userViewModel.removeCategoryApi.observe(
                    requireActivity(),
                    androidx.lifecycle.Observer {

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                                swipetoRefreshMenuCategory.isRefreshing = true
                            }
                            ApiResponseStatus.SUCCESS -> {
                                userViewModel.getMenuCategoryList()
                                mManageManusAdepter.notifyDataSetChanged()
                                showSnackbar(
                                        swipetoRefreshMenuCategory,
                                        it.message,
                                        SnackbarUtils.SnackbarType.SUCCESS
                                )
                                swipetoRefreshMenuCategory.isRefreshing = false
                            }
                            ApiResponseStatus.ERROR -> {
                                swipetoRefreshMenuCategory.isRefreshing = false

                                showSnackbar(
                                        swipetoRefreshMenuCategory,
                                        it.message,
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                swipetoRefreshMenuCategory.isRefreshing = false
                                showSnackbar(
                                        swipetoRefreshMenuCategory,
                                    getString(R.string.no_internet),
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            else -> {

                            }

                        }

                    })
        }
        swipetoRefreshMenuCategory.setOnRefreshListener {
            userViewModel.getMenuCategoryList()
        }
        userViewModel.getMenuCategoryList()




    }



    override fun onItemClicked(menuPos: CategoryListModel) {

        startActivityForResult(
            Intent(requireContext(), ManageManuesActivity::class.java)
                .putExtra(Constants.OPEN_ADD_FRAGMENT,2)
                .putExtra(Constants.GET_TITLE_OF_FRAGMENT,menuPos.vName)
                    .putExtra(Constants.SEND_ID_OF_CATEGORY, menuPos.id)
            ,RC_ADD_AND_UPDATE_CATEGORY
        )

    }

    override fun onEditCategory(menuPos: CategoryListModel) {
        startActivityForResult(
                Intent(requireContext(), ManageManuesActivity::class.java)
                        .putExtra(Constants.OPEN_ADD_FRAGMENT,1)
                         .putExtra(Constants.SEND_CATEGORY_DATA,menuPos)
                        ,RC_ADD_AND_UPDATE_CATEGORY
        )
    }



    override fun onDeletCategory(menuPos: CategoryListModel) {

        val deleteAdView = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_confirmation_for_delete, null)

        val deleteAlert = AlertDialogUtil.createCustomAlertDialog(requireActivity(), deleteAdView)
        deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        deleteAlert.setCancelable(false)
        deleteAlert.show()
        deleteAdView.btnPositiveDelete.setOnClickListener {
            userViewModel.removeCategory(menuPos.id)
            deleteAlert.dismiss()
        }
        deleteAdView.btnNegativeDelelte.setOnClickListener {

            deleteAlert.dismiss()
        }

    }

    override fun onResume() {
        userViewModel.getMenuCategoryList()
        mManageManusAdepter.notifyDataSetChanged()
        super.onResume()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            Constants.RC_ADD_AND_UPDATE_CATEGORY -> {
                userViewModel.getMenuCategoryList()
                mManageManusAdepter.notifyDataSetChanged()
            }
        }
    }
    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recyclerViewMAnegeManu.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recyclerViewMAnegeManu.visibility = View.GONE

        }
    }



}