package com.example.godeliverybusinessapp.utils;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

public class SqureLinearLayout extends LinearLayout {

    public SqureLinearLayout(Context context) {
        super(context);
    }

    public SqureLinearLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SqureLinearLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
//        super.onMeasure(widthMeasureSpec, (widthMeasureSpec/2));
 //       int size = MeasureSpec.getSize(widthMeasureSpec);
        setMeasuredDimension(widthMeasureSpec, widthMeasureSpec);
    }

}
