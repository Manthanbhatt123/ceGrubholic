package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.ModifierGroupModel
import kotlinx.android.synthetic.main.row_modifier_groups.view.*

import java.util.ArrayList

class ModifierGroupListAdepter(val mModifaierGroupNames: ArrayList<ModifierGroupModel>,
                               val itemClickListener: ItemClickListener
): RecyclerView.Adapter<ModifierGroupListAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_modifier_groups,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mModifaierGroupNames.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.txtDesplayName.text = mModifaierGroupNames[position].vDisplayName
        holder.itemView.txtGroupName.text = mModifaierGroupNames[position].vGroupName
       // holder.itemView.txtChoiceType.text = mModifaierGroupNames[position].nChoiceType
        holder.itemView.txtSequenceNumber.text = mModifaierGroupNames[position].nSequenceNo

        if (mModifaierGroupNames[position].nChoiceType == "1"){
            holder.itemView.txtChoiceType.setText(R.string.single)
        }else if (mModifaierGroupNames[position].nChoiceType == "2"){
            holder.itemView.txtChoiceType.setText(R.string.multiple)
        }

       /* if (Constants.isModificationEnable == 0){
            holder.itemView.imageEditModifier.visibility = View.GONE
            holder.itemView.imageDeletModifier.visibility = View.GONE
        }*/


    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(mModifaierGroupNames[layoutPosition])
            }
            itemView.imageEditModifier.setOnClickListener {
                itemClickListener.onEditClicked(mModifaierGroupNames[layoutPosition])
            }
            itemView.imageDeletModifier.setOnClickListener {
                itemClickListener.onDeletedClicked(mModifaierGroupNames[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: ModifierGroupModel

        )
        fun onEditClicked(
            menuPos: ModifierGroupModel
        )
        fun onDeletedClicked(
            menuPos: ModifierGroupModel
        )

    }
}