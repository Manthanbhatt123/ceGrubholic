package com.cEGrubHolic.business.network

/**
 * Created by Ashish on 4/12/18.
 */
enum class ApiResponseStatus {
    LOADING,
    SUCCESS,
    ERROR,
    SESSION_EXPIRED,
    NO_INTERNET
}