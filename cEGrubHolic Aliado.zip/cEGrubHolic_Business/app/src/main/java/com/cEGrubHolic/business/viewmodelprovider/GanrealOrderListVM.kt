package com.egodelivery.business.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.google.android.gms.maps.model.LatLng
import com.google.gson.JsonElement
import okhttp3.MultipartBody
import java.util.ArrayList

/**
 * Created by Ashish on 2/4/19.
 */


class GanrealOrderListVM : ViewModel() {

    val getOrdetRequestListApi:MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getOrdetRequestList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getOrderRequestlist()

        getOrdetRequestListApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrdetRequestListApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrdetRequestListApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getOrdetRequestListApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getOrdetRequestListApi.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    val getOrderReuesteStastusApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getOrderRequrestStastus(nOrderId:String,nRequestStatus:String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.mChangeOrderRequestStatus(nOrderId,nRequestStatus)

        getOrderReuesteStastusApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrderReuesteStastusApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrderReuesteStastusApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getOrderReuesteStastusApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getOrderReuesteStastusApi.postValue(ApiResponse().noInternet())
                }
            })
    }


    val assignDeliveryBoyApi: MutableLiveData<Event<ApiResponse>>  = MutableLiveData()

    fun assignDeliveryBoy(nOrderId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.assigbDeliveryBoy(nOrderId)

        assignDeliveryBoyApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    assignDeliveryBoyApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    assignDeliveryBoyApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    assignDeliveryBoyApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    assignDeliveryBoyApi.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }

    val getOrderDetaislApi:MutableLiveData<Event<ApiResponse>> = MutableLiveData()

    fun getOrderdetails(nOrderId:String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.getOrderDetails(nOrderId)

        getOrderDetaislApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrderDetaislApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrderDetaislApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getOrderDetaislApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getOrderDetaislApi.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }


    val getOrderStastusApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getOrderStastus(nOrderId:String,nOrderStatus:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.mChangeOrderStatus(nOrderId,nOrderStatus)

        getOrderStastusApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrderStastusApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrderStastusApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getOrderStastusApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getOrderStastusApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getOrderHistriyListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getOrderhistorylist() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getOrderhistorylist()

        getOrderHistriyListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOrderHistriyListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOrderHistriyListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getOrderHistriyListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getOrderHistriyListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val upcomingTripObserver: MutableLiveData<ApiResponse> = MutableLiveData()

    fun tripRequestList(latLng: LatLng) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.updateLocation(
                latLng.latitude,
                latLng.longitude
            )

        upcomingTripObserver.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    upcomingTripObserver.postValue(ApiResponse().sessionExpired())
                }
                override fun onSuccess(data: JsonElement, message: String) {
                    upcomingTripObserver.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    upcomingTripObserver.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    upcomingTripObserver.postValue(ApiResponse().noInternet())
                }
            })
    }


    val getMenuCategoryListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getMenuCategoryList() {

        val apiCall = WebServiceRetrofitUtil.webService!!.getFavCategoryList()

        getMenuCategoryListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getMenuCategoryListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getMenuCategoryListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getMenuCategoryListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getMenuCategoryListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val addCategoryApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addCategoryList(fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.addCategory(fields)

        addCategoryApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addCategoryApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addCategoryApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addCategoryApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addCategoryApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val updateBusinessHourssApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun updateBusinessHours(fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.updateBusinessHoursList(fields)

        updateBusinessHourssApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateBusinessHourssApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateBusinessHourssApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    updateBusinessHourssApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    updateBusinessHourssApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getBusinessHoursApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getBusinessHours() {

        val apiCall = WebServiceRetrofitUtil.webService!!.getBusinessHoiur()

        getBusinessHoursApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getBusinessHoursApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getBusinessHoursApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getBusinessHoursApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getBusinessHoursApi.postValue(ApiResponse().noInternet())
                }
            })
    }



    val removeCategoryApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeCategory(nCategoryId:String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.removeCategory(nCategoryId)

        removeCategoryApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeCategoryApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeCategoryApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeCategoryApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeCategoryApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getFoodItemCategoryWiseApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getFoodItemCategoryWise(nCategoryId:String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.getFoodItemCategoryWise(nCategoryId)

        getFoodItemCategoryWiseApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getFoodItemCategoryWiseApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getFoodItemCategoryWiseApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getFoodItemCategoryWiseApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getFoodItemCategoryWiseApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getOngoingOrderListApi: MutableLiveData <Event<ApiResponse>> = MutableLiveData()

    fun getOngoingOrderList() {

        val apiCall = WebServiceRetrofitUtil.webService!!.getOngoingOrderList()

        getOngoingOrderListApi.postValue(Event(ApiResponse().loading()))

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getOngoingOrderListApi.postValue(Event(ApiResponse().sessionExpired()))
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getOngoingOrderListApi.postValue(Event(ApiResponse().success(data, message)))
                }

                override fun onFailure(message: String) {
                    getOngoingOrderListApi.postValue(Event(ApiResponse().error(message)))
                }

                override fun noInternetConnection() {
                    getOngoingOrderListApi.postValue(Event(ApiResponse().noInternet()))
                }
            })
    }





    val addFoodItemCategoryWiseApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addFoodItemCategoryWise(fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.addFoodItem(fields)

        addFoodItemCategoryWiseApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addFoodItemCategoryWiseApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addFoodItemCategoryWiseApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addFoodItemCategoryWiseApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addFoodItemCategoryWiseApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val upDateFoodItemCategoryWiseApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun upDateFoodItemCategoryWise(fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.upDateFoodItem(fields)

        upDateFoodItemCategoryWiseApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    upDateFoodItemCategoryWiseApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    upDateFoodItemCategoryWiseApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    upDateFoodItemCategoryWiseApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    upDateFoodItemCategoryWiseApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val upDateFoodCategoryApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun upDateFoodCategory(fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.upDateFoodCategory(fields)

        upDateFoodCategoryApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    upDateFoodCategoryApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    upDateFoodCategoryApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    upDateFoodCategoryApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    upDateFoodCategoryApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val removeFoodItemApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeFoodItem(nProductId: String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.removeFoodItem(nProductId)

        removeFoodItemApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeFoodItemApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeFoodItemApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeFoodItemApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeFoodItemApi.postValue(ApiResponse().noInternet())
                }
            })
    }

}