package com.egodelivery.business.fragment

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment
import com.cEGrubHolic.business.ManageItemOfManuActivity
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM

import com.egodelivery.business.adapter.ProductManuListAdepter
import com.cEGrubHolic.business.models.ProductListModel
import com.cEGrubHolic.business.utils.AlertDialogUtil
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.RC_ADD_FOODITEM
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.dialog_confirmation_for_delete.view.*
import kotlinx.android.synthetic.main.fragment_maneg_item_of_manues.*
import kotlinx.android.synthetic.main.view_no_data.*


class  ManegItemOfManuesFragment : BaseFragment(), ProductManuListAdepter.ItemClickListener {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }

 val vProductList = arrayListOf<ProductListModel>()
    val mProductAdepter: ProductManuListAdepter = ProductManuListAdepter(vProductList,this)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_maneg_item_of_manues, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerMAnageItem.adapter = mProductAdepter


        if (!userViewModel.removeFoodItemApi.hasActiveObservers()) {
            userViewModel.removeFoodItemApi.observe(
                    activity!!,
                    androidx.lifecycle.Observer {

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                                reccyclerFoodItemCategory.isRefreshing = true
                            }
                            ApiResponseStatus.SUCCESS -> {
                                reccyclerFoodItemCategory.isRefreshing = false
                                userViewModel.getFoodItemCategoryWise(arguments!!.getString(
                                    Constants.SEND_ID_OF_CATEGORY)!!)
                                mProductAdepter.notifyDataSetChanged()
                                showSnackbar(
                                        recyclerMAnageItem,
                                        it.message,
                                        SnackbarUtils.SnackbarType.SUCCESS
                                )
                            }
                            ApiResponseStatus.ERROR -> {
                                reccyclerFoodItemCategory.isRefreshing = false

                                showSnackbar(
                                        recyclerMAnageItem,
                                        it.message,
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                reccyclerFoodItemCategory.isRefreshing = false
                                showSnackbar(
                                        recyclerMAnageItem,
                                    getString(R.string.no_internet),
                                        SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            else -> {

                            }

                        }

                    })
        }




        if (!userViewModel.getFoodItemCategoryWiseApi.hasActiveObservers()) {
            userViewModel.getFoodItemCategoryWiseApi.observe(
                    activity!!,
                    androidx.lifecycle.Observer {

                        when (it?.status) {

                            ApiResponseStatus.LOADING -> {
                                if (reccyclerFoodItemCategory != null){
                                    reccyclerFoodItemCategory.isRefreshing = true
                                }

                            }
                            ApiResponseStatus.SUCCESS -> {
                                if (reccyclerFoodItemCategory != null) {
                                    reccyclerFoodItemCategory.isRefreshing = false
                                    vProductList.clear()
                                    vProductList.addAll(
                                        Gson().fromJson(
                                            it.data,
                                            object : TypeToken<List<ProductListModel>>() {}.type
                                        )
                                    )
                                    mProductAdepter.notifyDataSetChanged()
                                    showDetailView(true, it.message)
                                }
                            }
                            ApiResponseStatus.ERROR -> {
                                if (reccyclerFoodItemCategory != null) {
                                    reccyclerFoodItemCategory.isRefreshing = false
                                    showDetailView(false, it.message)
                                }
                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                reccyclerFoodItemCategory.isRefreshing = false
                                showDetailView(false, it.message)

                            }
                            else -> {
                                reccyclerFoodItemCategory.isRefreshing = false
                            }

                        }

                    })
        }
        reccyclerFoodItemCategory.setOnRefreshListener {
            userViewModel.getFoodItemCategoryWise(arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!)
        }
        userViewModel.getFoodItemCategoryWise(arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!)



    }


    override fun onResume() {
        userViewModel.getFoodItemCategoryWise(arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!)
        super.onResume()
    }

    override fun onItemClicked(menuPos: ProductListModel) {

    }

    override fun onEditCategory(menuPos: ProductListModel) {
        startActivityForResult(
                Intent(context, ManageItemOfManuActivity::class.java)
                        .putExtra(Constants.SEND_ID_OF_CATEGORY,arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!)
                        .putExtra(Constants.KEY_FOOD_MODEL,menuPos)
                        .putExtra(Constants.CUSTMISED_FOOD_CART,1), Constants.RC_ADD_FOODITEM
        )


    }

    override fun onDeletCategory(menuPos: ProductListModel) {
        val deleteAdView = LayoutInflater.from(activity)
                .inflate(R.layout.dialog_confirmation_for_delete, null)

        val deleteAlert =
                AlertDialogUtil.createCustomAlertDialog(activity!!, deleteAdView)


        deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        deleteAlert.setCancelable(false)
        deleteAlert.show()
        deleteAdView.btnPositiveDelete.setOnClickListener {
            userViewModel.removeFoodItem(menuPos.id)
            deleteAlert.dismiss()
        }
        deleteAdView.btnNegativeDelelte.setOnClickListener {

            deleteAlert.dismiss()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            RC_ADD_FOODITEM->{
                userViewModel.getFoodItemCategoryWise(arguments!!.getString(Constants.SEND_ID_OF_CATEGORY)!!)
            }
        }
    }
    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recyclerMAnageItem.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recyclerMAnageItem.visibility = View.GONE

        }
    }


}