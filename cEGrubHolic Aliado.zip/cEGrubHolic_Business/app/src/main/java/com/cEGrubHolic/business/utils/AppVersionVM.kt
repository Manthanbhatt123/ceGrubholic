package com.example.godeliverybusinessapp.utils

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil

import com.google.gson.JsonElement

/**
 * Created by Ashish on 2/4/19.
 */


class AppVersionVM : ViewModel() {

    val appVersionApiResponseObservable: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getLatestAppVersion() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getLatestApkVersion()

        appVersionApiResponseObservable.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    appVersionApiResponseObservable.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    appVersionApiResponseObservable.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    appVersionApiResponseObservable.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    appVersionApiResponseObservable.postValue(ApiResponse().noInternet())
                }
            })

    }
}
