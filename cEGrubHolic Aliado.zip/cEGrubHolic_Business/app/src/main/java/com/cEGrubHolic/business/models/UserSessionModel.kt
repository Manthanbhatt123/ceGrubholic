package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class UserSessionModel(
    @SerializedName("vFirstName")
    val vFirstName: String = "",
    @SerializedName("vLastName")
    val vLastName: String = "",
    @SerializedName("vCountryISOCode")
    val vCountryISOCode: String = "",
    @SerializedName("vApiToken")
    val vApiToken: String = "",
    @SerializedName("vPushToken")
    val vPushToken: String = "",
    @SerializedName("nMobileNo")
    val nMobileNo: String = "",
    @SerializedName("nSignUpType")
    val nSignUpType: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("vCountryCode")
    val vCountryCode: String = "",
    @SerializedName("isOnDelivery")
    val isOnDelivery: String = "",
    @SerializedName("vEmail")
    val vEmail: String = "",
    @SerializedName("nLoginDeviceType")
    val nLoginDeviceType: String = "",
    @SerializedName("isNotify")
    val isNotify: String = "",
    @SerializedName("vLanguage")
    val vAppLanguage: String = "",
    @SerializedName("vVehicleNumber")
    val vVehicleNumber: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("vModules")
    val vModules: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = "",
    @SerializedName("dLat")
    val dLat: String = "",
    @SerializedName("dLng")
    val dLng: String = "",
    @SerializedName("vAddress")
    val vAddress: String = "",
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("dWallet")
    val dWallet: String = ""
): Serializable


