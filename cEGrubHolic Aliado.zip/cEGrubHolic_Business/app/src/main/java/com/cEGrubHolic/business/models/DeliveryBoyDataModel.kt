package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class DeliveryBoyDataModel (
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("vMobileNo")
    val vContect: String = ""
): Serializable