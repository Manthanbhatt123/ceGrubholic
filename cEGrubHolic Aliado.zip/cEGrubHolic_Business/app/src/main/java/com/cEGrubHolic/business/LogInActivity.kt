package com.egodelivery.business

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.ForgotPasswordActivity
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.example.godeliverybusinessapp.utils.*
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils.setAppLanguage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.models.UserSessionModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.KeyboardUtils
import com.cEGrubHolic.business.utils.LayoutUtils

import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.iid.FirebaseInstanceId
import kotlinx.android.synthetic.main.activity_log_in.*
import java.util.*

class LogInActivity : BaseActivity() {


    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)
        setLightStatusBarWhite()
        tvLoginForgotPassword.setOnClickListener {
            val intentForForgotPassword = Intent(this, ForgotPasswordActivity::class.java)
            startActivity(intentForForgotPassword)
        }


        relLogin.setOnClickListener {
            KeyboardUtils.hideKeyboard(this, relLogin)
            if (isValidForm()) {
                userViewModel.getLoggedIn(
                    tvLoginEmail.text.toString().trim(),
                    tvLoginPassword.text.toString().trim(),
                    "1"
                    ,    pushToken

                )
            }
        }
        FirebaseInstanceId.getInstance().instanceId
            .addOnCompleteListener(OnCompleteListener { task ->
                if (!task.isSuccessful) {
                    Log.w("Error", "pushToken getInstanceId failed", task.exception)
                    return@OnCompleteListener
                }
                // Get new Instance ID token
                task.result?.token?.let {
                    MyAppPreferenceUtils.savePushToken(this, it)
                }
            })

        if (!userViewModel.loginApiResponseObserver.hasActiveObservers()) {
            userViewModel.loginApiResponseObserver.observe(this, Observer {it->
                it.getContentIfNotHandled()?.let { it ->

                    when (it.status) {

                        ApiResponseStatus.LOADING -> {
                            LayoutUtils.disableUI(this)
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            showSnackbar(
                                tvLoginForgotPassword,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                            val mUserSessionmodel: UserSessionModel = Gson().fromJson(
                                it.data,
                                object : TypeToken<UserSessionModel>() {}.type
                            )
                            MyAppPreferenceUtils.saveToken(
                                this@LogInActivity,
                                mUserSessionmodel.vApiToken
                            )
                            MyAppPreferenceUtils.saveUserSession(this, mUserSessionmodel)
                            setAppLanguage(this, mUserSessionmodel.vAppLanguage)
                            WebServiceRetrofitUtil.destroyInstance() //for replacing old token with new one
                            WebServiceRetrofitUtil.init(this)
                            MyAppPreferenceUtils.setLoggedIn(this@LogInActivity, true)

                            Handler().postDelayed({

                                startActivity(Intent(this, MainActivity::class.java))
                                finish()

                            }, 1500)


                            // MyAppPreferenceUtils.getUserSession(this@LogInActivity)

                            // LocaleManager.setNewLocale(this, MyAppPreferenceUtils.getUserSession(this@LogInActivity).vAppLanguage)


                        }
                        ApiResponseStatus.ERROR -> {
                            // LoginManager.getInstance().logOut()
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            showSnackbar(
                                tvLoginForgotPassword,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            //  LoginManager.getInstance().logOut()
                            LayoutUtils.enableUI(this)
                            hideProgress()
                            destroyLoginSession(true)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            //LoginManager.getInstance().logOut()
                            LayoutUtils.enableUI(this)

                            showSnackbar(
                                tvLoginForgotPassword,
                                Constants.NO_INTERNET,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }

                        else -> {
                            hideProgress()
                        }
                    }
                }
            })
        }
    }



   private fun isValidForm(): Boolean {

        if (!FormValidationUtils.isValidEmail(tvLoginEmail.text.toString().trim())) {
            tvLoginEmail.requestFocus()
            showSnackbar(
                tvLoginEmail,
                getString(R.string.enter_velid_email),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(tvLoginPassword.text.toString().trim())) {
            tvLoginPassword.requestFocus()
            showSnackbar(
                tvLoginPassword,
                getString(R.string.enter_velid_password),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else {
            return true
        }
    }
}
