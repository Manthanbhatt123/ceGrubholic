package com.cEGrubHolic.business.fragment


import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Filter
import android.widget.Filterable
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.egodelivery.business.BaseActivity
import com.cEGrubHolic.business.BaseFragment

import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.GeoCoderUtils
import com.cEGrubHolic.business.utils.SnackbarUtils



import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.reflect.TypeToken

import com.cEGrubHolic.business.models.AddressLookUpResponseModel
import com.cEGrubHolic.business.models.AddressSearchResponseModel
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.network.WebServiceResponseHandler

import com.pickapp.foods.viewmodelprovider.LocationViewModel
import kotlinx.android.synthetic.main.fragment_select_address.*
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.uiThread
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import java.util.concurrent.Future


/**
 * A simple [Fragment] subclass.
 */
class SelectAddressFragment : BaseFragment(), OnMapReadyCallback {
    val autocompleteAdapter by lazy{ AutocompleteAddressAdapter(
        context!!,
        android.R.layout.simple_spinner_dropdown_item
    )}

    var getcurrentLocation :LatLng? = null

    private val locationViewModel: LocationViewModel by lazy {
        ViewModelProvider(this).get(LocationViewModel::class.java)
    }
    private val listOfPlaces = arrayListOf<AddressSearchResponseModel.Predictions>()
    private var googleMap: GoogleMap? = null
    private var mMapFragment: SupportMapFragment? = null

    var currentLocation: LatLng? = null
    private var zoomLevel: Float = 18.0f
      private var latitude: Double = 0.00
      private var longitude: Double = 0.00
    private var isIdleForFirstTime = true

    private val searchResultRadius = 30000



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_select_address, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mMapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mMapFragment?.getMapAsync(this)

        /* (activity as BusinessProfileDetaisActivity).btnRight.setOnClickListener {

            if (currentLocation == null
                || edtTxtLocation.text.toString().trim().isEmpty()
            ) {
                showSnackbar(
                    imgDone,
                    getString(R.string.selectLocation),
                    SnackbarUtils.SnackbarType.ERROR
                )
                return@setOnClickListener
            } else {
                val resultIntent = Intent()
                resultIntent.putExtra("latitude", currentLocation!!.latitude)
                resultIntent.putExtra("longitude", currentLocation!!.longitude)
                resultIntent.putExtra("address", edtTxtLocation.text.toString().trim())
                (activity as BusinessProfileDetaisActivity).setBusinessAddress(resultIntent)
            }
        }
*/
        (activity as BaseActivity).startInAppLocationUpdates {

            getcurrentLocation = LatLng(
                it.latitude,
                it.longitude
            )



        }


        if (!locationViewModel.addressLookupObserver.hasActiveObservers())
            locationViewModel.addressLookupObserver.observe(
                viewLifecycleOwner,
                androidx.lifecycle.Observer { apiResponse ->

                    when (apiResponse?.status) {
                        ApiResponseStatus.SUCCESS -> {

                            val addressLookUpResponse: AddressLookUpResponseModel = Gson().fromJson(
                                apiResponse.data,
                                object : TypeToken<AddressLookUpResponseModel>() {}.type
                            )

                            if (addressLookUpResponse.status == "OK" && addressLookUpResponse.results.isNotEmpty()) {

                                edtTxtLocation.setAdapter(null)

                                edtTxtLocation.setText(
                                    addressLookUpResponse.results[0].formattedAddress
                                )

                                edtTxtLocation.setAdapter(autocompleteAdapter)

                                val symbols = DecimalFormatSymbols(Locale.ENGLISH)
                                val decimalFormat = DecimalFormat("#.########", symbols)
                                decimalFormat.roundingMode = RoundingMode.HALF_UP

                                val latitude =
                                    decimalFormat.format(addressLookUpResponse.results[0].geometry.location.lat)
                                        .toDouble()
                                val longitude =
                                    decimalFormat.format(addressLookUpResponse.results[0].geometry.location.lng)
                                        .toDouble()
                                currentLocation = LatLng(
                                    latitude,
                                    longitude
                                )

                            }

                        }
                        ApiResponseStatus.LOADING -> {
                        }
                        ApiResponseStatus.ERROR -> {
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                    edtTxtLocation,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {

                        }

                    }
                })

        if (Constants.googleApiKey.isNotEmpty()) {
            Places.initialize(context!!, Constants.googleApiKey)

            if (Places.isInitialized()) {
                val placeClient = Places.createClient(context!!)
                   edtTxtLocation.setAdapter(autocompleteAdapter)
                edtTxtLocation.threshold = 1
                edtTxtLocation.setAutoCompleteDelay(500)
                edtTxtLocation.onItemClickListener =
                    AdapterView.OnItemClickListener { parent, view, position, id ->

                        placeClient.fetchPlace(
                            FetchPlaceRequest.newInstance(
                                autocompleteAdapter.getItem(position).placeId,
                                listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)
                            )
                        ).addOnSuccessListener {

                            googleMap?.setOnCameraIdleListener(null)

                            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
                            val decimalFormat = DecimalFormat("#.########", symbols)
                            decimalFormat.roundingMode = RoundingMode.HALF_UP

                            val latitude =
                                decimalFormat.format(it.place.latLng!!.latitude)
                                    .toDouble()
                            val longitude =
                                decimalFormat.format(it.place.latLng!!.longitude)
                                    .toDouble()

                            currentLocation = LatLng(
                                latitude,
                                longitude
                            )

                            googleMap?.animateCamera(
                                CameraUpdateFactory.newLatLngZoom(
                                    currentLocation,
                                    zoomLevel
                                )
                            )

                            Handler().postDelayed({
                                googleMap?.setOnCameraIdleListener(cameraIdleListener)
                            }, 1500)

                        }
                            .addOnFailureListener {
                                showSnackbar(
                                    edtTxtLocation,
                                    it.message.toString(),
                                    SnackbarUtils.SnackbarType.ERROR
                                )
                            }


                        edtTxtLocation.setText(
                            autocompleteAdapter.getItem(position).description
                        )

                    }
            }

        }


      /*  imgBtnClearSearch.setOnClickListener {
            edtTxtLocation.setText("")
            currentLocation = null
        }*/
        imgBtnSearch.setOnClickListener {


            (activity as BaseActivity).startInAppLocationUpdates {

                currentLocation = LatLng(
                    it.latitude,
                 it.longitude
                )
                googleMap?.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(
                        LatLng(
                          it.latitude,
                           it.longitude
                        ), zoomLevel
                    )
                )
                (activity as BaseActivity).stopInAppLocationUpdates()


            }


        }
    }

    private val cameraIdleListener = GoogleMap.OnCameraIdleListener {
        currentLocation = LatLng(
            googleMap?.cameraPosition!!.target.latitude,
            googleMap?.cameraPosition!!.target.longitude
        )
        if (isIdleForFirstTime) {
            isIdleForFirstTime = false
        } else {
            getAddressFromLatLng(
                googleMap?.cameraPosition!!.target.latitude,
                googleMap?.cameraPosition!!.target.longitude
            )


        }
    }


    override fun onMapReady(map: GoogleMap) {

        this.googleMap = map

        googleMap?.uiSettings!!.isMapToolbarEnabled = false


        (activity as BaseActivity).startInAppLocationUpdates {


            googleMap?.animateCamera(
                CameraUpdateFactory.newLatLngZoom(
                    LatLng(
                        it.latitude,
                        it.longitude
                    ), zoomLevel
                )
            )
            (activity as BaseActivity).stopInAppLocationUpdates()
            googleMap?.setOnCameraIdleListener(cameraIdleListener)


        }





    }

    private fun getAddressFromLatLng(latitude: Double, longitude: Double) {

     /*   val reverseGeoCodingAddressLookUpUrl =
            "https://maps.googleapis.com/maps/api/geocode/json?latlng=$latitude,$longitude&key=${getString(
                R.string.ApiKey
            )}"
        locationViewModel.getAddressFromLatLng(reverseGeoCodingAddressLookUpUrl)*/


        GeoCoderUtils.getAddressFromLocation(
            context!!,
            latitude, longitude
        ) { apiResponseStatus, address, errorMsg ->

            when (apiResponseStatus) {
                ApiResponseStatus.SUCCESS -> {

                    //display address wherever you want

                    edtTxtLocation.setAdapter(null)

                    edtTxtLocation.setText(
                        address
                    )

                    edtTxtLocation.setAdapter(autocompleteAdapter)

                    currentLocation = LatLng(
                        latitude,
                        longitude
                    )

                }
                ApiResponseStatus.ERROR -> {

                }
                ApiResponseStatus.NO_INTERNET -> {
                    showSnackbar(
                        edtTxtLocation,
                        getString(R.string.no_internet),
                        SnackbarUtils.SnackbarType.ERROR
                    )
                }
                ApiResponseStatus.LOADING,
                ApiResponseStatus.SESSION_EXPIRED -> {
                }

            }

        }

    }

    private fun getPlacesByQuery(
        query: String,
        passResult: (ArrayList<AddressSearchResponseModel.Predictions>) -> Unit
    ): Future<Unit> {


        return doAsync {
        val url = "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
                "?input=$query" +
                "&sensor=false" +
                "&location=${getcurrentLocation!!.latitude}," +
                "${getcurrentLocation!!.longitude}" +
                "&radius=${searchResultRadius}" +
                "&strictbounds" +
                "&key=${Constants.googleApiKey}"

          /*  val url = if (currentLocation == null) {
                "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
                        "?input=$query" +
                        "&sensor=false" +
                        "&radius=${searchResultRadius}" +
                        "&strictbounds" +
                        "&key=${Constants.googleApiKey}"

            } else {
                "https://maps.googleapis.com/maps/api/place/autocomplete/json" +
                        "?input=$query" +
                        "&sensor=false" +
                        "&location=${currentLocation!!.latitude}," +
                        "${currentLocation!!.longitude}" +
                        "&radius=${searchResultRadius}" +
                        "&strictbounds" +
                        "&key=${Constants.googleApiKey}"

            }*/


            val apiCall =
                WebServiceRetrofitUtil.webService!!.getAddressFromLatLng(url)

            WebServiceResponseHandler.handleApiResponseWithJsonElement(
                apiCall,
                object : WebServiceResponseHandler.DataHandlerWithHeaders {
                    override fun sessionExpired() {

                    }

                    override fun onSuccess(data: JsonElement, message: String) {
                        uiThread {
                            try {
                                val addressLookUpResponse: AddressSearchResponseModel =
                                    Gson().fromJson(
                                        data,
                                        object : TypeToken<AddressSearchResponseModel>() {}.type
                                    )

                                if (addressLookUpResponse.status == "OK" && addressLookUpResponse.predictions.isNotEmpty()) {
                                    listOfPlaces.clear()
                                    listOfPlaces.addAll(addressLookUpResponse.predictions)
                                    passResult(listOfPlaces)
                                }
                            } catch (e: Exception) {
                                Log.e(
                                    "SelectLocationActivity",
                                    "onSuccess : ${e.printStackTrace()} "
                                )
                            }
                        }

                    }

                    override fun onFailure(message: String) {

                    }

                    override fun noInternetConnection() {

                    }
                })
        }
    }

   inner class AutocompleteAddressAdapter(context: Context, resource: Int) :
        ArrayAdapter<AddressSearchResponseModel.Predictions>(context, resource), Filterable {

        private val listOfPlaces = arrayListOf<AddressSearchResponseModel.Predictions>()

        override fun getCount(): Int {
            return listOfPlaces.size
        }

        override fun getItem(position: Int): AddressSearchResponseModel.Predictions {
            return listOfPlaces[position]
        }

        override fun getFilter(): Filter {

            return object : Filter() {
                override fun performFiltering(constraint: CharSequence?): FilterResults {

                    val filterResult = FilterResults()

                    if (constraint != null && constraint.isNotEmpty()) {
                        getPlacesByQuery(constraint.toString().trim()) {

                            filterResult.values = it
                            filterResult.count = it.size

                            listOfPlaces.clear()
                            listOfPlaces.addAll(it)

                            publishResults(constraint, filterResult)

                        }
                    }
                    return filterResult

                }

                override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                    notifyDataSetChanged()
                }
            }
        }


    }


}
