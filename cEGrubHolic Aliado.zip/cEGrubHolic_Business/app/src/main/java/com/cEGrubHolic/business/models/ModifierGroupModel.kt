package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ModifierGroupModel(
    @SerializedName("vGroupName")
    val vGroupName: String = "",
    @SerializedName("vDisplayName")
    val vDisplayName: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nChoiceType")
    val nChoiceType: String = "",
    @SerializedName("nSequenceNo")
    val nSequenceNo: String = "",
    @SerializedName("isActive")
    val isActive: String = "",
    @SerializedName("nModifierGroupId")
    val nModifierGroupId: String = "",
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("dCost")
    val dCost: String = "",
    @SerializedName("vModifierGroup")
    val vModifierGroup: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = "",
    @SerializedName("nCategoryId")
    val nCategoryId: String = "",
    @SerializedName("vTitle")
    val vTitle: String = "",
    @SerializedName("vDesc")
    val vDesc: String = "",
    @SerializedName("isCrossSelling")
    val isCrossSelling: String = "",
    @SerializedName("vModifierIds")
    val vModifierIds: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("nMaxSelectValue")
    val nMaxSelectValue: String = "",
    @SerializedName("nMinSelectValue")
    val nMinSelectValue: String = "",
    @SerializedName("isMandatory")
    val isMandatory : String = ""

): Serializable{
    var isSelected = false
}