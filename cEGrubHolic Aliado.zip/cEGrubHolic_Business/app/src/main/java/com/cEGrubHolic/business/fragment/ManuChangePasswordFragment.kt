package com.cEGrubHolic.business.fragment

import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment

import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import kotlinx.android.synthetic.main.fragment_menu_change_password.*


class ManuChangePasswordFragment : BaseFragment() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_change_password, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        relSavePassword.setOnClickListener {
            if (isValidData()){
                userViewModel.changePassword(
                    tvOldPassword.text.toString(),
                    tvNewPassword.text.toString()
                )
            }
            if (isValidData()==true) {
                tvOldPassword.setText("")
                tvNewPassword.setText("")
                tvReTypePassword.setText("")
            }
        }
        if (!userViewModel.changePasswordApiResponseObservable.hasActiveObservers()) {
            userViewModel.changePasswordApiResponseObservable.observe(activity!!, Observer { it->
                it.getContentIfNotHandled()?.let { it ->

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            showSnackbar(
                                tvReTypePassword,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                               activity!!.recreate()
                            },500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                tvReTypePassword,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            showSnackbar(
                                tvReTypePassword,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                            destroyLoginSession(true)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                tvReTypePassword,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        else -> {
                            hideProgress()
                        }
                    }
                }
            })

        }
    }

    private fun isValidData(): Boolean {

        if (!FormValidationUtils.isValidPassword(tvOldPassword.text.toString())) {
            tvOldPassword.requestFocus()
            showSnackbar(
                tvOldPassword,
                getString(R.string.enteroldpassword),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(tvNewPassword.text.toString())) {
            tvNewPassword.requestFocus()
            showSnackbar(
                tvNewPassword,
                getString(R.string.entervalidnewpassword),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidPassword(tvReTypePassword.text.toString())) {
            tvReTypePassword.requestFocus()
            showSnackbar(
                tvReTypePassword,
                getString(R.string.entervalidnewpassword),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidRePassword(
                tvNewPassword.text.toString().trim(),
                tvReTypePassword.text.toString().trim()
            )
        ) {
            showSnackbar(tvReTypePassword, getString(R.string.passwordnotmatch), SnackbarUtils.SnackbarType.WARNING)
            return false
        } else {
            return true
        }
    }


}