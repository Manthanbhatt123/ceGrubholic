package com.egodelivery.business

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PointF
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions.bitmapTransform
import com.cEGrubHolic.business.utils.AlertDialogUtil
import com.egodelivery.business.fragment.*
import com.cEGrubHolic.business.models.CategoryListModel
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.cEGrubHolic.business.adapter.MenuHomeAdepter
import com.cEGrubHolic.business.fragment.*
import com.cEGrubHolic.business.models.SideNavModelClass
import com.cEGrubHolic.business.models.UserSessionModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.example.godeliverybusinessapp.utils.*
import com.egodelivery.business.utils.Constants.KEY_NOTIFICATION_DATA_BUNDLE
import com.egodelivery.business.utils.Constants.RC_ADD_AND_UPDATE_CATEGORY
import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.utils.FragmentUtils
import com.cEGrubHolic.business.utils.PackageInfoUtil
import jp.wasabeef.glide.transformations.gpu.VignetteFilterTransformation
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.app_main_toolbar.*
import kotlinx.android.synthetic.main.dialog_confirmation.view.*
import org.json.JSONObject
import java.util.*

class MainActivity : BaseActivity(), MenuHomeAdepter.ItemClickListener {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    private var receiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {

            Log.i("MainActivity", "onReceive : handleNotification ")

            handleNotification(intent)

        }
    }

    private fun registerNotificationReceiver() {
        try {
            val filter = IntentFilter(Constants.INTENT_ACTION_NOTIFICATION)

//            unregisterNotificationReceiver()

            registerReceiver(receiver, filter)
        } catch (e: Exception) {
            Log.e("MenuCoachingFragment", "onActivityCreated : ${e.printStackTrace()} ")
        }
    }

    fun unregisterNotificationReceiver() {
        try {
            unregisterReceiver(receiver)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        unregisterNotificationReceiver()
        super.onDestroy()
    }




    val vSideNavList = arrayListOf<SideNavModelClass>()
    var doubleBackToExitPressedOnce: Boolean = false

    private val userViewModels by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }



    val vListOfManus = arrayListOf<CategoryListModel>()


    val listOfDataSideNav = arrayListOf(
        SideNavModelClass(R.string.home),
        SideNavModelClass(R.string.ongoing_orders),
        SideNavModelClass(R.string.history),
        SideNavModelClass(R.string.manage_menu),
        SideNavModelClass(R.string.manage_modifiers),
        SideNavModelClass(R.string.promocode),
        SideNavModelClass(R.string.reports),
        SideNavModelClass(R.string.profile),
        SideNavModelClass(R.string.business_hours),
        SideNavModelClass(R.string.change_password)
        )
    var sideNavAdepter: MenuHomeAdepter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        appVerson.text = String.format(
            getString(R.string.version),
            PackageInfoUtil.getAppVersionName(this),
            Locale.ENGLISH
        )


        if (intent != null && intent.hasExtra(KEY_NOTIFICATION_DATA_BUNDLE)) {
            //redirect to notification related screen
            handleNotification(intent)

        }else{
            FragmentUtils.replaceFragment(
                this@MainActivity,
                ManuHomeFragment(),
                R.id.mainContener,
                true
            )
        }


        setLightStatusBar()

        backStackManager()

        btnLeft.setOnClickListener {
            toggleDrawerMenu()
        }




        if (!userViewModel.logoutApiResponseObservable.hasActiveObservers()) {
            userViewModel.logoutApiResponseObservable.observe(this, Observer { it ->
                it.getContentIfNotHandled()?.let { it ->

                    when (it.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            destroyLoginSession(true)
                            val intent = Intent(this, LogInActivity::class.java)
                            startActivity(intent)
                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {

                            hideProgress()
                            destroyLoginSession(true)
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            showSnackbar(
                                relLogout,
                                Constants.NO_INTERNET,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }
                }
            })
        }




        relLogout.setOnClickListener {
            val deleteAdView = LayoutInflater.from(this)
                .inflate(R.layout.dialog_confirmation, null)

            val deleteAlert =
                AlertDialogUtil.createCustomAlertDialog(this, deleteAdView)


            deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            deleteAlert.setCancelable(false)
            deleteAlert.show()
            deleteAdView.btnPositive.setOnClickListener {

                userViewModel.logout()
                deleteAlert.dismiss()

            }
            deleteAdView.btnNegative.setOnClickListener {

                deleteAlert.dismiss()

            }
        }
        updateUserSession(MyAppPreferenceUtils.getUserSession(this))

        sideNavAdepter = MenuHomeAdepter(listOfDataSideNav, object : MenuHomeAdepter.ItemClickListener {

                override fun onItemClicked(menuPos: SideNavModelClass) {

                    if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                        drawerLayout.closeDrawer(GravityCompat.START, true)
                    }

                    /* for (item in listOfDataSideNav) {
                        item.isSelected = menuPos.sideNavTitle == item.sideNavTitle
                    }*/

                    sideNavAdepter?.notifyDataSetChanged()

                    when (menuPos.vMenuTitle) {

                        R.string.home -> {
                            tvTitle.text = getString(R.string.home)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuHomeFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.ongoing_orders -> {
                            tvTitle.text = getString(R.string.ongoing_orders)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuOngoingOrdersFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.history -> {

                            tvTitle.text = getString(R.string.history)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuHistoryFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.manage_menu -> {
                            tvTitle.text = getString(R.string.manage_menu)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuManageMenuFragment(),
                                R.id.mainContener,
                                true
                            )

                            btnRight.setImageDrawable(
                                ContextCompat.getDrawable(
                                    this@MainActivity,
                                    R.drawable.ic_plus
                                )
                            )
                            btnRight.setOnClickListener {
                                startActivityForResult(
                                    Intent(this@MainActivity, ManageManuesActivity::class.java)
                                        .putExtra(Constants.OPEN_ADD_FRAGMENT, 0),
                                    RC_ADD_AND_UPDATE_CATEGORY
                                )
                            }
                            btnRight.visibility = View.VISIBLE
                        }
                        R.string.manage_modifiers->{
                            tvTitle.text = getString(R.string.manage_modifiers)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuModifierGroupFragment(),
                                R.id.mainContener,
                                true
                            )

                            btnRight.setImageDrawable(
                                ContextCompat.getDrawable(
                                    this@MainActivity,
                                    R.drawable.ic_plus
                                )
                            )
                            btnRight.setOnClickListener {
                                startActivityForResult(
                                    Intent(this@MainActivity, ManageManuesActivity::class.java)
                                        .putExtra(Constants.OPEN_ADD_FRAGMENT, 3),
                                    RC_ADD_AND_UPDATE_CATEGORY
                                )
                            }
                            btnRight.visibility = View.VISIBLE
                        }
                        R.string.promocode->{
                            tvTitle.text = getString(R.string.promocode)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuPromocodeListFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.setImageDrawable(
                                ContextCompat.getDrawable(
                                    this@MainActivity,
                                    R.drawable.ic_plus
                                )
                            )
                            btnRight.setOnClickListener {
                                startActivityForResult(
                                    Intent(this@MainActivity, ManageManuesActivity::class.java)
                                        .putExtra(Constants.OPEN_ADD_FRAGMENT, 6)
                                        .putExtra(Constants.FOR_API_CALLING_PROMOCODE,1)
                                    ,
                                    707
                                )
                            }
                            btnRight.visibility = View.VISIBLE
                        }
                        R.string.reports->{
                            tvTitle.text = getString(R.string.reports)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuReportFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.profile -> {
                            tvTitle.text = getString(R.string.profile)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuProfileFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.business_hours -> {
                            tvTitle.text = getString(R.string.business_hours)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuBusinessHoursFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }
                        R.string.change_password -> {
                            tvTitle.text = getString(R.string.change_password)
                            FragmentUtils.replaceFragment(
                                this@MainActivity,
                                ManuChangePasswordFragment(),
                                R.id.mainContener,
                                true
                            )
                            btnRight.visibility = View.GONE
                        }


                    }

                }

            })
        recyacalersideNavegetionView.adapter = sideNavAdepter
        sideNavAdepter?.itemClickListener?.onItemClicked(listOfDataSideNav[0])

    }



    private fun updateUserSession(vUserShessionMode: UserSessionModel){
        Glide.with(this)
            .load(vUserShessionMode.vImagePath)
            .apply(
                bitmapTransform(
                    VignetteFilterTransformation(
                        PointF(0.5f, 0.5f),
                        floatArrayOf(0.0f, 0.0f, 0.0f), 0f, 0.75f
                    )
                ).dontAnimate()
            )
            .into(imageRestorant)
        tvRestorantName.text = vUserShessionMode.vName
        tvRestorantAddress.text = vUserShessionMode.vAddress

    }

    fun handleNotification(intent: Intent) {


        val notificationDataBundle = intent.getBundleExtra(KEY_NOTIFICATION_DATA_BUNDLE)!!

        val nId = if (notificationDataBundle.containsKey(Constants.KEY_NOTIFICATION_nId)) {
            notificationDataBundle.getString(Constants.KEY_NOTIFICATION_nId, "")!!
        } else {
            null
        }

        val vOtherJson = if (notificationDataBundle.containsKey(Constants.KEY_NOTIFICATION_vOther)) {
                JSONObject(
                    notificationDataBundle.getString(
                        Constants.KEY_NOTIFICATION_vOther,
                        ""
                    )!!
                )
            } else {
                null
            }
        when (notificationDataBundle.getString(Constants.KEY_NOTIFICATION_nPushType, "")!!) {
            Constants.nPushType_1_For_Order_recived -> {
                // new order request - refresh page

                val currentFragment =
                    supportFragmentManager.findFragmentById(R.id.mainContener)

                if (currentFragment != null && currentFragment is ManuHomeFragment) {
                    currentFragment.refreshPage()

                } else {

                    supportFragmentManager.popBackStackImmediate(
                        null,
                        FragmentManager.POP_BACK_STACK_INCLUSIVE
                    )
                    FragmentUtils.replaceFragment(
                        this@MainActivity,
                        ManuHomeFragment(),
                        R.id.mainContener,
                        true
                    )
                }
            }

            Constants.nPushType_2_Custemor_cancal_order -> {

                val currentFragment =
                    supportFragmentManager.findFragmentById(R.id.mainContener)

                if (currentFragment != null && currentFragment is ManuHomeFragment) {
                    currentFragment.refreshPage()

                } else {
                    supportFragmentManager.popBackStackImmediate(
                        null,
                        FragmentManager.POP_BACK_STACK_INCLUSIVE
                    )
                    FragmentUtils.replaceFragment(
                        this@MainActivity,
                        ManuHomeFragment(),
                        R.id.mainContener,
                        true
                    )
                }
            }


            Constants.nPushType_6_Deliveryboy_Delivered_order -> {
                val intent = Intent(this, OrderDetailsActivity::class.java)
                intent.putExtra(Constants.KEY_FOR_ORDER_DETIASL, nId)
                startActivity(intent)
            }
            Constants.nPushType_7_Deliveryboy_Accept_order -> {
                val intent = Intent(this, OrderDetailsActivity::class.java)
                intent.putExtra(Constants.KEY_FOR_ORDER_DETIASL, nId)
                startActivity(intent)
            }
            Constants.nPushType_8_Deliveryboy_Reject_order -> {
                val intent = Intent(this, OrderDetailsActivity::class.java)
                intent.putExtra(Constants.KEY_FOR_ORDER_DETIASL, nId)
                startActivity(intent)
            }
            Constants.nPushType_10_Master_admin_cancel_order ->{
                val intent = Intent(this, OrderDetailsActivity::class.java)
                intent.putExtra(Constants.KEY_FOR_ORDER_DETIASL, nId)
                startActivity(intent)
            }else -> {
                FragmentUtils.replaceFragment(
                    this@MainActivity,
                    ManuHomeFragment(),
                    R.id.mainContener,
                    true
                )
            }
        }
    }
    override fun onNewIntent(intent: Intent?) {

        if (intent != null && intent.hasExtra(KEY_NOTIFICATION_DATA_BUNDLE)) {
            Log.i("MainActivity", "onNewIntent : handleNotification ")
            //redirect to notification related screen
            handleNotification(intent)
        }

        super.onNewIntent(intent)
    }

    override fun onResume() {

        super.onResume()
        registerNotificationReceiver()

    }

    @SuppressLint("WrongConstant")
    fun toggleDrawerMenu() {
        updateUserSession(MyAppPreferenceUtils.getUserSession(this))
        if (drawerLayout.isDrawerOpen(Gravity.START)) {
            drawerLayout.closeDrawer(Gravity.START, true)
        } else {
            drawerLayout.openDrawer(Gravity.START, true)
            navigetionViewMain.bringToFront()
            drawerLayout.requestLayout()
        }


    }

    private fun switchSelectedMenu(menuName: Int) {
      /*  for (item in listOfDataSideNav) {
            item.isSelected = (menuName == item.sideNavTitle)
        }*/
        when (menuName) {
            R.string.home -> {
                tvTitle.text = getString(R.string.home)
                btnRight.visibility = View.GONE
                /* for (item in listOfDataSideNav) {
                    item.isSelected = item.sideNavTitle == R.string.deshbord
                }*/
            }
            R.string.ongoing_orders -> {
                tvTitle.text = getString(R.string.ongoing_orders)
                btnRight.visibility = View.GONE
                /* for (item in listOfDataSideNav) {
                    item.isSelected = item.sideNavTitle == R.string.readthemeter
                }*/
            }
            R.string.history -> {
                tvTitle.text = getString(R.string.history)
                btnRight.visibility = View.GONE
                /*for (item in listOfDataSideNav) {
                    item.isSelected = item.sideNavTitle == R.string.previouspayments
                }*/
            }
            R.string.manage_menu -> {
                tvTitle.text = getString(R.string.manage_menu)
                btnRight.visibility = View.VISIBLE

                /* for (item in listOfDataSideNav) {
                    item.isSelected = item.sideNavTitle == R.string.previousmeterreadingforHome
                }*/
            }
            R.string.manage_modifiers->{
                tvTitle.text = getString(R.string.manage_modifiers)
                btnRight.visibility = View.VISIBLE
            }
            R.string.promocode ->{
                tvTitle.text = getString(R.string.promocode)
                btnRight.visibility = View.VISIBLE
            }
            R.string.reports->{
                tvTitle.text = getString(R.string.reports)
                btnRight.visibility = View.GONE
            }
            R.string.profile -> {
                tvTitle.text = getString(R.string.profile)
                btnRight.visibility = View.GONE
            }
            R.string.business_hours -> {
                btnRight.visibility = View.GONE
                tvTitle.text = getString(R.string.business_hours)
            }
            R.string.change_password -> {
                tvTitle.text = getString(R.string.change_password)
                btnRight.visibility = View.GONE
                /* for (item in listOfDataSideNav) {
                    item.isSelected = item.sideNavTitle == R.string.meterstatisticsforhome
                }*/
            }



        }
        sideNavAdepter?.notifyDataSetChanged()

    }
    private fun backStackManager() {
        /*for (item in listOfDataSideNav) {
            item.isSelected = (menuName == item.sideNavTitle)
        }*/

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START, true)
        }

        supportFragmentManager.addOnBackStackChangedListener {
            updateUserSession(MyAppPreferenceUtils.getUserSession(this))
            when (supportFragmentManager.findFragmentById(R.id.mainContener)) {

                is ManuHomeFragment -> {
                    switchSelectedMenu(R.string.home)
                }
                is ManuOngoingOrdersFragment -> {
                    switchSelectedMenu(R.string.ongoing_orders)
                }
                is ManuHistoryFragment -> {
                    switchSelectedMenu(R.string.history)
                }
                is ManuManageMenuFragment -> {
                    switchSelectedMenu(R.string.manage_menu)
                }
                is ManuModifierGroupFragment ->{
                    switchSelectedMenu(R.string.manage_modifiers)
                }
                is ManuPromocodeListFragment ->{
                    switchSelectedMenu(R.string.promocode)
                }
                is ManuReportFragment ->{
                    switchSelectedMenu(R.string.reports)
                }
                is ManuProfileFragment -> {
                    switchSelectedMenu(R.string.profile)
                }
                is ManuBusinessHoursFragment -> {
                    switchSelectedMenu(R.string.business_hours)
                }
                is ManuChangePasswordFragment -> {
                    switchSelectedMenu(R.string.change_password)
                }



            }
            sideNavAdepter?.notifyDataSetChanged()
        }

    }



    override fun onItemClicked(menuPos: SideNavModelClass) {


    }


    override fun onBackPressed() {
        Log.e(
            "MainActivity",
            "onBackPressed: \n count : " + supportFragmentManager.backStackEntryCount +
                    "  & frgmnt : " + supportFragmentManager.findFragmentById(R.id.mainContener)
        )
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START, true)
        }
        if (supportFragmentManager.findFragmentById(R.id.mainContener) is ManuHomeFragment ||
            supportFragmentManager.findFragmentById(R.id.mainContener) == null
        ) {
            if (doubleBackToExitPressedOnce) {
                finish()
                super.onBackPressed()
                return
            }
            this.doubleBackToExitPressedOnce = true
            Toast.makeText(this, "Please press BACK again to exit", Toast.LENGTH_SHORT).show()
            Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)

        } else if (supportFragmentManager.backStackEntryCount > 0) {
            supportFragmentManager.popBackStack()
        } else if (supportFragmentManager.backStackEntryCount == 0
            && supportFragmentManager.findFragmentById(R.id.mainContener) !is ManuHomeFragment
        ) {
            FragmentUtils.replaceMenuFragment(
                this@MainActivity,
                ManuHomeFragment(), R.id.mainContener
            )
            switchSelectedMenu(R.string.home)
        } else {
            super.onBackPressed()
        }

    }

}