package com.pickapp.foods.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil

/**
 * Created by Ashish on 4/11/19.
 */


class LocationViewModel : ViewModel() {


    val addressLookupObserver: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getAddressFromLatLng(addressLookUpUrl: String) {
        addressLookupObserver.postValue(ApiResponse().loading())

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getAddressFromLatLng(addressLookUpUrl)

        WebServiceResponseHandler.handleApiResponseWithJsonElement(
            apiCall,
            object : WebServiceResponseHandler.DataHandlerWithHeaders {
                override fun sessionExpired() {
                    addressLookupObserver.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addressLookupObserver.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addressLookupObserver.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addressLookupObserver.postValue(ApiResponse().noInternet())
                }
            })
    }






}