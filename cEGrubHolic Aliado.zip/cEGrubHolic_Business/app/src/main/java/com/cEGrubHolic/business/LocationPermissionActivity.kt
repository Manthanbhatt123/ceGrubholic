package com.egodelivery.business

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker

import com.cEGrubHolic.business.utils.AlertDialogUtil
import kotlinx.android.synthetic.main.dialog_confirmation.view.*


open class LocationPermissionActivity : AppCompatActivity() {

    // this function will pass permission SUCCESS result to calling Activity
    var callbackFunction_: ((Boolean) -> Unit)? = null

    //will show permission result related dialog
    private var alertDialog_: AlertDialog? = null


    private val REQUEST_LOCATION_PERMISSION = 1203
    private val LOCATION_PERMISSION =
        arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

    private val REQUEST_LOCATION_IN_BG_PERMISSION = 1209

    @RequiresApi(Build.VERSION_CODES.Q)
    private val LOCATION_IN_BG_PERMISSION = Manifest.permission.ACCESS_BACKGROUND_LOCATION


    private fun getDialogContent(requestCode: Int): Array<String> {
        val arrayOfContent = arrayOf("Permission", "access data")
        when (requestCode) {
            REQUEST_LOCATION_PERMISSION -> {
                arrayOfContent[0] = "Location Permission"
                arrayOfContent[1] = "access your current location"
            }
            REQUEST_LOCATION_IN_BG_PERMISSION -> {
                arrayOfContent[0] = "Location Permission"
                arrayOfContent[1] = "access your current location in Background"
            }
        }
        return arrayOfContent
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {

        when (requestCode) {
            REQUEST_LOCATION_PERMISSION,
            REQUEST_LOCATION_IN_BG_PERMISSION -> {

                val notGrantedPermissions = arrayListOf<String>()

                for (result in grantResults) {
                    if (result != PermissionChecker.PERMISSION_GRANTED) {
                        notGrantedPermissions.add(permissions[grantResults.indexOf(result)])
                    }
                }

                if (notGrantedPermissions.isNotEmpty()) {

                    if (notGrantedPermissions.size == 1) {
                        //if only single permission to be checked
                        showPermissionResultDialog(notGrantedPermissions[0], requestCode)
                       /* if(requestCode==REQUEST_LOCATION_IN_BG_PERMISSION){
                            //callbackFunction_ = isPermissionGranted
                            requestPermission(
                                arrayOf(LOCATION_IN_BG_PERMISSION),
                                REQUEST_LOCATION_IN_BG_PERMISSION
                            )
                        }
                        else{
                            showPermissionResultDialog(notGrantedPermissions[0], requestCode)
                        }*/
                    } else {
                        // if multiple permissions were requested then choose first of "notGrantedPermissions" array
                        showPermissionResultDialog(notGrantedPermissions[0], requestCode)

                    }
                } else {
                    //all permission granted
                    if (requestCode == REQUEST_LOCATION_PERMISSION) {
                        if (callbackFunction_ != null) {
                            callbackFunction_!!(true)
                          //  checkAndAskBackgroundLocationPermission(callbackFunction_!!)
                        } else {
                            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
                        }
                    } else if (callbackFunction_ != null) {
                        callbackFunction_!!(true)
                    }
                }
            }
            else -> {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults)
            }
        }

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        val permission = let {
            when (requestCode) {
                REQUEST_LOCATION_PERMISSION -> {
                    LOCATION_PERMISSION[0]
                }
                REQUEST_LOCATION_IN_BG_PERMISSION -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        LOCATION_IN_BG_PERMISSION
                    } else {
                        ""
                    }
                }
                else -> {
                    null
                }
            }
        }

        if (permission == null) {
            super.onActivityResult(requestCode, resultCode, data)
        } else {
            checkAndReturnActivityResult(permission, requestCode)
        }

    }


    private var bgLocationPermissionAlertDialog: AlertDialog? = null

    fun checkAndAskLocationPermissionNew(isPermissionGranted: (Boolean) -> Unit) {
        val isGranted = isPermissionGranted(LOCATION_PERMISSION[0])

        if (isGranted) {
            //now check for BG location permission
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                isPermissionGranted(isGranted)
            }
        } else {


            if (bgLocationPermissionAlertDialog != null && bgLocationPermissionAlertDialog!!.isShowing) {
                bgLocationPermissionAlertDialog?.dismiss()
            }

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@LocationPermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            bgLocationPermissionAlertDialog =
                AlertDialogUtil.createCustomAlertDialog(
                    this@LocationPermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_soy_dinki)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositivess.text =
                getString(R.string.continueToPermission)

            bgLocationPermissionAlertDialog?.setCancelable(false)
            bgLocationPermissionAlertDialog?.show()
            bgLocationPermissionAlertDialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                bgLocationPermissionAlertDialog?.dismiss()
                callbackFunction_ = isPermissionGranted
                requestPermission(LOCATION_PERMISSION, REQUEST_LOCATION_PERMISSION)

            }


        }
    }

  /*  private fun checkAndAskBackgroundLocationPermission(isPermissionGranted: (Boolean) -> Unit) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val isGranted = isPermissionGranted(LOCATION_IN_BG_PERMISSION)

            if (isGranted) {
                isPermissionGranted(isGranted)
            } else {
                callbackFunction_ = isPermissionGranted
                requestPermission(
                    arrayOf(LOCATION_IN_BG_PERMISSION),
                    REQUEST_LOCATION_IN_BG_PERMISSION
                )
            }
        } else {
            isPermissionGranted(true)
        }
    }*/


    private fun requestPermission(arrayOfPermissions: Array<String>, requestCode: Int) {
        ActivityCompat.requestPermissions(this, arrayOfPermissions, requestCode)
    }

    private fun isPermissionGranted(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            permission
        ) == PackageManager.PERMISSION_GRANTED
    }

    private fun checkAndReturnActivityResult(permission: String, requestCode: Int) {
        if (!isPermissionGranted(permission)) {
            showPermissionResultDialog(permission, requestCode)
        } else {

            if (requestCode == REQUEST_LOCATION_PERMISSION) {
                if (callbackFunction_ != null) {
                    checkAndAskLocationPermissionNew(callbackFunction_!!)
                } else {
                    callbackFunction_!!(true)
                }
            } else if (callbackFunction_ != null) {
                callbackFunction_!!(true)
            }
        }
    }

    private fun showPermissionResultDialog(permission: String, requestCode: Int) {

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
            showPermissionRequiredReasonDialog(permission, requestCode)
        } else {
            showPermissionEnableFromSettingDialog(requestCode)
        }

    }

    private fun showPermissionRequiredReasonDialog(
        manifestPermissionName: String,
        requestCode: Int
    ) {

        if (alertDialog_ != null && alertDialog_!!.isShowing) {
            alertDialog_?.dismiss()
        }
        val dialogContent = getDialogContent(requestCode)

        val message =
            when (requestCode) {
                REQUEST_LOCATION_PERMISSION -> {
                    getString(R.string.locationPermission)
                }
                REQUEST_LOCATION_IN_BG_PERMISSION -> {
                    getString(R.string.locationPermission)
                }
                else -> {
                    "${dialogContent[0]} required for ${dialogContent[1]}!"
                }
            }




        if (requestCode == REQUEST_LOCATION_PERMISSION || requestCode == REQUEST_LOCATION_IN_BG_PERMISSION) {

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@LocationPermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            alertDialog_ =
                AlertDialogUtil.createCustomAlertDialog(
                    this@LocationPermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_soy_dinki)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositivess.text =
                getString(R.string.ok)

            alertDialog_?.setCancelable(false)
            alertDialog_?.show()
            alertDialog_?.window?.setBackgroundDrawable(
                ColorDrawable(
                    Color.TRANSPARENT
                )
            )

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                alertDialog_?.dismiss()
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(manifestPermissionName),
                    requestCode
                )
            }
        } else {

            // show this dialog if user has denied permission before

            alertDialog_ = AlertDialog.Builder(this, R.style.DialogTheme)
//            .setTitle(dialogContent[0])
                .setMessage(message)
                .setPositiveButton(getString(R.string.ok)) { dialogInterface, i ->
                    //Prompt the user once explanation has been shown
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(manifestPermissionName),
                        requestCode
                    )
                }
                .setCancelable(false)
                .create()

            alertDialog_!!.show()
        }
    }


    private fun showPermissionEnableFromSettingDialog(requestCode: Int) {

        if (alertDialog_ != null && alertDialog_!!.isShowing) {
            alertDialog_?.dismiss()
        }
        // show this dialog if user has denied permission before
        // and set never ask again checked...
        // result will caught in onActivityResults....

        val dialogContent = getDialogContent(requestCode)

        val message =
            when (requestCode) {
                REQUEST_LOCATION_PERMISSION -> {
                    getString(R.string.locationPermission)
                }
                REQUEST_LOCATION_IN_BG_PERMISSION -> {
                    getString(R.string.locationPermission)
                }
                else -> {
                    "${dialogContent[0]} required for ${dialogContent[1]}!"
                }
            }

        if (requestCode == REQUEST_LOCATION_PERMISSION || requestCode == REQUEST_LOCATION_IN_BG_PERMISSION) {

            //show dialog

            val backgroundLocationPermissionDialogView =
                LayoutInflater.from(this@LocationPermissionActivity)
                    .inflate(R.layout.dialog_confirmation, null)

            alertDialog_ =
                AlertDialogUtil.createCustomAlertDialog(
                    this@LocationPermissionActivity,
                    backgroundLocationPermissionDialogView
                )


            backgroundLocationPermissionDialogView.txtDialogTitle.text =
                getString(R.string.allow_soy_dinki)
            backgroundLocationPermissionDialogView.txtDialogMessage.text =
                getString(R.string.backgroundPermissionMessage)
            backgroundLocationPermissionDialogView.btnPositivess.text =
                getString(R.string.goToSettings)

            alertDialog_?.setCancelable(false)
            alertDialog_?.show()
            alertDialog_?.window?.setBackgroundDrawable(
                ColorDrawable(
                    Color.TRANSPARENT
                )
            )

            backgroundLocationPermissionDialogView.btnNegative.visibility = View.GONE

            backgroundLocationPermissionDialogView.btnPositive.setOnClickListener {
                alertDialog_?.dismiss()
                val intent = Intent()
                intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                val uri = Uri.fromParts("package", packageName, null)
                intent.data = uri
                startActivityForResult(intent, requestCode)
            }
        } else {
            alertDialog_ = AlertDialog.Builder(this, R.style.DialogTheme)
//            .setTitle(dialogContent[0])
                .setMessage(message)
                .setPositiveButton(getString(R.string.goToSettings)) { dialogInterface, i ->
                    val intent = Intent()
                    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                    val uri = Uri.fromParts("package", packageName, null)
                    intent.data = uri
                    startActivityForResult(intent, requestCode)
                }.setNegativeButton(getString(R.string.cancel))
                { dialogInterface, i ->
                    dialogInterface.dismiss()
                }
                .setCancelable(false)
                .create()


            alertDialog_?.show()

        }
    }


}
