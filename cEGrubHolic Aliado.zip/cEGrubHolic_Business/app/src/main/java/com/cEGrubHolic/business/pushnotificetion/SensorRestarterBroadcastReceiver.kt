package com.egodelivery.business.pushnotificetion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.egodelivery.business.LocationUpdateService

import com.egodelivery.business.utils.Constants.ACTION_RESTART_SERVICE
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils


class SensorRestarterBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        Log.i(
            SensorRestarterBroadcastReceiver::class.java.simpleName,
            "Service Stops! Oooooooooooooppppssssss!!!!"
        )

        if (context != null
            && MyAppPreferenceUtils.getServiceRunningStatus(context)
            && intent != null
            && intent.action == ACTION_RESTART_SERVICE) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(Intent(context, LocationUpdateService::class.java))
            } else {
                context.startService(Intent(context, LocationUpdateService::class.java))
            }


            MyAppPreferenceUtils.setServiceRunningStatus(context, true)

        }
    }
}
