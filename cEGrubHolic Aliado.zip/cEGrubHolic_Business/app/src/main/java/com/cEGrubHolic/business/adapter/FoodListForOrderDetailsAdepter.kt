package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.FoodTitleModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import kotlinx.android.synthetic.main.row_food_itemlist_for_order_details.view.*


import java.util.ArrayList

class FoodListForOrderDetailsAdepter(val mFoodItemModel: ArrayList<FoodTitleModel>

): RecyclerView.Adapter<FoodListForOrderDetailsAdepter.MyViewHolder>() {

    var vSymbol = ""
    val dConversionRate = "1"

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_food_itemlist_for_order_details,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mFoodItemModel.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        vSymbol = Constants.vCurrentCurrencySymbol
   //     holder.itemView.tvOrderAmount.visibility = View.VISIBLE
        holder.itemView.tvItemNumer.text = mFoodItemModel[position].mQuntitie + "x"
        holder.itemView.tvItemName.text = mFoodItemModel[position].mItemNAme



        val amountCount = (mFoodItemModel[position].dProductPrice.toDouble()+ mFoodItemModel[position].dModifierAmount.toDouble()) * mFoodItemModel[position].mQuntitie.toDouble()
        holder.itemView.tvOrderAmount.text = FormValidationUtils.getValueWithCurrencyCode(
            amountCount,
            vSymbol,
           dConversionRate
        )


        holder.itemView.tvItemExtra.text = mFoodItemModel[position].vModifier

        if (mFoodItemModel[position].RecommendationNote.isEmpty()){
            holder.itemView.relRecommendtionView.visibility = View.GONE
        }else{
            holder.itemView.relRecommendtionView.visibility = View.VISIBLE
        }

        holder.itemView.tvItemDetailsNote.text = mFoodItemModel[position].RecommendationNote
    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){

    }


}