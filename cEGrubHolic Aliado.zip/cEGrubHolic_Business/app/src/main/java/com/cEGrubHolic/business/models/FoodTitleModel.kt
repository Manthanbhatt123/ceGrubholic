package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class FoodTitleModel(
    @SerializedName("nQty")
    val mQuntitie: String,
    @SerializedName("vProductName")
    val mItemNAme: String,
    @SerializedName("nProductId")
    val nProductId: String,
    @SerializedName("vDesc")
    val vDesc: String,
    @SerializedName("vModifier")
    val vModifier: String,
    @SerializedName("dProductPrice")
    val dProductPrice: String,
    @SerializedName("RecommendationNote")
    val RecommendationNote: String,
    @SerializedName("dModifierAmount")
    val dModifierAmount: String = ""
): Serializable