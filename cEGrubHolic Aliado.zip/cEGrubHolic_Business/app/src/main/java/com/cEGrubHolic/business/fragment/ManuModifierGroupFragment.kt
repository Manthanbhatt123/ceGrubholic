package com.egodelivery.business.fragment

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.ManageManuesActivity
import com.egodelivery.business.R
import com.cEGrubHolic.business.adapter.ModifierGroupListAdepter
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.cEGrubHolic.business.utils.AlertDialogUtil
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.RC_ADD_UPDATE_MODIFIER
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.egodelivery.business.viewmodelprovider.ModifierGroupListVM
import kotlinx.android.synthetic.main.dialog_confirmation_for_delete.view.*
import kotlinx.android.synthetic.main.fragment_manu_modifier_group.*
import kotlinx.android.synthetic.main.view_no_data.*


class ManuModifierGroupFragment : BaseFragment(), ModifierGroupListAdepter.ItemClickListener {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(ModifierGroupListVM::class.java)
    }
    val mModifierList = arrayListOf<ModifierGroupModel>()
    private val mModifierGroupListAdepter: ModifierGroupListAdepter =
        ModifierGroupListAdepter(mModifierList, this)


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_manu_modifier_group, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerModifierGruop.adapter = mModifierGroupListAdepter


        if (!userViewModel.removeModifierGroupListApi.hasActiveObservers()) {
            userViewModel.removeModifierGroupListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {

                        }
                        ApiResponseStatus.SUCCESS -> {
                            userViewModel.getModifierGroupList()
                            mModifierGroupListAdepter.notifyDataSetChanged()
                            showSnackbar(
                                recyclerModifierGruop,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                        }
                        ApiResponseStatus.ERROR -> {


                            showSnackbar(
                                recyclerModifierGruop,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {

                            showSnackbar(
                                recyclerModifierGruop,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })
        }



        if (!userViewModel.getModifierGroupListApi.hasActiveObservers()) {
            userViewModel.getModifierGroupListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            if (swiptoreFreshModifierGroup != null) {
                                swiptoreFreshModifierGroup.isRefreshing = true
                            }
                        }
                        ApiResponseStatus.SUCCESS -> {
                            if (swiptoreFreshModifierGroup != null) {
                                swiptoreFreshModifierGroup.isRefreshing = false
                                mModifierList.clear()
                                mModifierList.addAll(
                                    Gson().fromJson(
                                        it.data,
                                        object : TypeToken<List<ModifierGroupModel>>() {}.type
                                    )
                                )
                                mModifierGroupListAdepter.notifyDataSetChanged()
                                showDetailView(true, it.message)
                            }
                        }
                        ApiResponseStatus.ERROR -> {
                            if (swiptoreFreshModifierGroup !=null){
                                swiptoreFreshModifierGroup.isRefreshing = false
                                showDetailView(false, it.message)
                            }


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            swiptoreFreshModifierGroup.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        else -> {
                            swiptoreFreshModifierGroup.isRefreshing = false
                        }

                    }

                })
        }


        swiptoreFreshModifierGroup.setOnRefreshListener {
            userViewModel.getModifierGroupList()
        }
        userViewModel.getModifierGroupList()


    }

    override fun onResume() {
        userViewModel.getModifierGroupList()
        super.onResume()
    }

    override fun onItemClicked(menuPos: ModifierGroupModel) {
        val intent = Intent(activity!!, ManageManuesActivity::class.java)
        intent.putExtra(Constants.OPEN_ADD_FRAGMENT, 5)
        intent.putExtra(Constants.GET_MODIFIER_CETEGORYWISE_LIST, menuPos.id)
        intent.putExtra(Constants.ACTION_RESTART_SERVICE,menuPos.vDisplayName)
        activity!!.startActivity(intent)

    }

    override fun onEditClicked(menuPos: ModifierGroupModel) {
        startActivityForResult(
            Intent(activity!!, ManageManuesActivity::class.java)
                .putExtra(Constants.OPEN_ADD_FRAGMENT, 4)
                .putExtra(Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL,menuPos)
                .putExtra(Constants.GET_ITEM_ID,menuPos.id),RC_ADD_UPDATE_MODIFIER
        )
    }

    override fun onDeletedClicked(menuPos: ModifierGroupModel) {
        val deleteAdView = LayoutInflater.from(activity)
            .inflate(R.layout.dialog_confirmation_for_delete, null)

        val deleteAlert =
            AlertDialogUtil.createCustomAlertDialog(activity!!, deleteAdView)


        deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        deleteAlert.setCancelable(false)
        deleteAlert.show()
        deleteAdView.btnPositiveDelete.setOnClickListener {
            userViewModel.removeModifierGroupList(menuPos.id)
            deleteAlert.dismiss()
        }
        deleteAdView.btnNegativeDelelte.setOnClickListener {

            deleteAlert.dismiss()
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            Constants.RC_ADD_UPDATE_MODIFIER->{
                userViewModel.getModifierGroupList()
            }
        }
    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recyclerModifierGruop.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recyclerModifierGruop.visibility = View.GONE

        }

    }


}