package com.egodelivery.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.egodelivery.business.models.OngoingOrderModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.adapter.FoodListAdepter
import com.cEGrubHolic.business.utils.DateTimeUtils
import com.cEGrubHolic.business.utils.FormValidationUtils
import kotlinx.android.synthetic.main.raw_order_ongoing.view.*

import java.util.*

class OrderListAdepter(
    val mOrderListModel: ArrayList<OngoingOrderModel>,
    val itemClickListener: ItemClickListener
) : RecyclerView.Adapter<OrderListAdepter.MyViewHolder>() {
    var vSymbol = ""
    val dConversionRate = "1"
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_order_ongoing,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return mOrderListModel.size
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        vSymbol = Constants.vCurrentCurrencySymbol
        val foodListAdepter: FoodListAdepter = FoodListAdepter(mOrderListModel[position].foodItemModel!!)
        holder.itemView.recyclerOrderItemList.adapter = foodListAdepter
        holder.itemView.tvOrderBillNo.text = mOrderListModel[position].vOrderID
       holder.itemView.tvTimeAgo.text =      DateTimeUtils.getTimeAgoString(
           mOrderListModel[position].vOrderDate,
           DateTimeUtils.apiResponseDataTimeFormat,
           true
       )

        holder.itemView.tvOrderAmount.text = FormValidationUtils.getValueWithCurrencyCode(
            mOrderListModel[position].vOrderAmount.toDouble(),
            vSymbol,
            dConversionRate
        )


        holder.itemView.tvOrderUserName.text = mOrderListModel[position].vOrderUsen


                holder.itemView.tvOrderTimeDate.text = DateTimeUtils.convertDateFormat(
                    mOrderListModel[position].vOrderDate    ,
                    "yyyy-MM-dd HH:mm:ss","dd MMM,yyyy  HH:mm a"
                )

            holder.itemView.viewExtraTime.visibility = View.GONE
    }

                    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
                init {
                    itemView.setOnClickListener {
                        itemClickListener.onItemClicked(mOrderListModel[layoutPosition])
                    }
                }
            }

            interface ItemClickListener {
            fun onItemClicked(
                menuPos: OngoingOrderModel

            )

        }



    }