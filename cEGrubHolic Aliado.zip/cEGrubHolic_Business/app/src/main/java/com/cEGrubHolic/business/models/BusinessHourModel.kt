package com.cEGrubHolic.business.models

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

/**
 * Created by Ashish on 18/2/20.
 */


data class BusinessHourModel(
    @SerializedName("nDay")
    val dayNumber: Int = 7,
    @Expose
    var dayName: String = ""
) : Serializable {

    @SerializedName("nEveningEndTime")
    var nEveningCloseHours: String = "12:00 am"

    @SerializedName("nMorningEndTime")
    var nMorningCloseHours: String = "12:00 am"

    @SerializedName("isOpen")
    var isOpen: String = ""

    @SerializedName("nMorningStartTime")
    var nMorningStartHours: String = "12:00 am"

    @SerializedName("nEveningStartTime")
    var nEveningStartHours: String = "12:00 am"

    @SerializedName("id")
    val id: String = ""

    @SerializedName("isActive")
    var isActive: String = ""

    @SerializedName("vSymbol")
    val vSymbol: String = ""

    @SerializedName("dConversionRate")
    val dConversionRate: String = ""

}