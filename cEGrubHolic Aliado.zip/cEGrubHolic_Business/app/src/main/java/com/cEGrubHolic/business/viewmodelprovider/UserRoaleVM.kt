package com.pickapp.foods.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil

class UserRoaleVM: ViewModel()  {

    val addUserAndRoalApiApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addUserAndRoalApiList (vFirstName:String,vLastName:String,vEmail:String,vModules:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.addUserRoal(vFirstName,vLastName,vEmail,vModules)
        addUserAndRoalApiApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addUserAndRoalApiApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addUserAndRoalApiApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addUserAndRoalApiApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addUserAndRoalApiApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val updateUserAndRoalApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun updateUserAndRoalList (nUserId:String,vFirstName:String,vLastName:String,vEmail:String,vModules:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.updateUserRoal(nUserId,vFirstName,vLastName,vEmail,vModules)
        updateUserAndRoalApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateUserAndRoalApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateUserAndRoalApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    updateUserAndRoalApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    updateUserAndRoalApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getUserRoalListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getUserRoalListList () {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getUserRoalList()
        getUserRoalListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getUserRoalListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getUserRoalListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getUserRoalListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getUserRoalListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val removeUserRoalListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeUserRoalListList (nUserId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.removeUser(nUserId)
        removeUserRoalListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeUserRoalListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeUserRoalListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeUserRoalListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeUserRoalListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
}