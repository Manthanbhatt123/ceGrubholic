package com.egodelivery.business.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.OrderDetiaslFromHistoryActivity
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.OrderHistoryModel
import com.cEGrubHolic.business.adapter.OrderHistoryAdepter
import com.egodelivery.business.utils.Constants
import com.example.godeliverybusinessapp.viewmodelprovider.GeneralVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_menu_history.*
import kotlinx.android.synthetic.main.view_no_data.*


class ManuHistoryFragment : BaseFragment(), OrderHistoryAdepter.ItemClickListener {

    private val generalVM by lazy {
        ViewModelProvider(this).get(GeneralVM::class.java)
    }

    val vHistoryOrderList = arrayListOf<OrderHistoryModel>()
    val mOrderHistoAdepter: OrderHistoryAdepter = OrderHistoryAdepter(vHistoryOrderList, this)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        if (!generalVM.getHistoryList.hasActiveObservers()) {
            generalVM.getHistoryList.observe(viewLifecycleOwner, androidx.lifecycle.Observer { it ->
                it.getContentIfNotHandled()?.let { it ->

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            swiptoRefreshHistoryList.isRefreshing = true

                        }
                        ApiResponseStatus.SUCCESS -> {

                            swiptoRefreshHistoryList.isRefreshing = false
                            vHistoryOrderList.clear()
                            vHistoryOrderList.addAll(
                                Gson().fromJson(
                                    it.data,
                                    object : TypeToken<List<OrderHistoryModel>>() {}.type
                                )
                            )
                            recycclerViewHistoryList.adapter = mOrderHistoAdepter
                            mOrderHistoAdepter.notifyDataSetChanged()


                            showDetailView(true, it.message)
                        }
                        ApiResponseStatus.ERROR -> {

                            swiptoRefreshHistoryList.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {

                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {

                            swiptoRefreshHistoryList.isRefreshing = false
                            showDetailView(false, getString(R.string.no_internet))

                        }
                        else -> {
                            swiptoRefreshHistoryList.isRefreshing = false
                            showDetailView(false, Constants.INTERNAL_SERVER_ERROR)

                        }

                    }
                }
            })
        }
        swiptoRefreshHistoryList.setOnRefreshListener {
            generalVM.getHistoryListData()
        }

        generalVM.getHistoryListData()


    }


    override fun onItemClicked(menuPos: OrderHistoryModel) {
        val intentForOrderDetails = Intent(requireContext(), OrderDetiaslFromHistoryActivity::class.java)
        intentForOrderDetails.putExtra(Constants.KEY_USER_NAME, menuPos.vOrderStutas)
        intentForOrderDetails.putExtra(Constants.KEY_FOR_ORDER_DETIASL, menuPos.id)
        startActivity(intentForOrderDetails)

    }

    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recycclerViewHistoryList.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recycclerViewHistoryList.visibility = View.GONE

        }
    }


}