package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class AppVersionModel(
    @SerializedName("dVersionName")
    val vVersionName: String = "",
    @SerializedName("vStoreURL")
    val vStoreURL: String = "",
    @SerializedName("isForceUpdate")
    val isForceUpdate: String = "",
    @SerializedName("isMaintenanceMode")
    val isMaintenanceMode: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = ""
):Serializable