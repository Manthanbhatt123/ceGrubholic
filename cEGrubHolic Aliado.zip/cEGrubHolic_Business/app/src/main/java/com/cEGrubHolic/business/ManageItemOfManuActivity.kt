package com.cEGrubHolic.business

import android.os.Bundle
import androidx.core.content.ContextCompat
import com.egodelivery.business.BaseActivity
import com.egodelivery.business.R
import com.egodelivery.business.fragment.AddAndEditMenuItemFragment
import com.egodelivery.business.fragment.AddAndEditModifierItemFragment
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FragmentUtils
import kotlinx.android.synthetic.main.app_main_toolbar.*

class ManageItemOfManuActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_item_of_manu)
        setLightStatusBar()

        btnLeft.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_back))
        btnLeft.setOnClickListener {
            finish()
        }
        val getFragment = intent.getIntExtra(Constants.CUSTMISED_FOOD_CART,0)
        when(getFragment){
            0->{
                val vAddAndEditMenuItemFragment = AddAndEditMenuItemFragment()
                val bundal =  Bundle()
                bundal.putInt(Constants.CUSTMISED_FOOD_CART,intent.getIntExtra(Constants.CUSTMISED_FOOD_CART,0))
                bundal.putString(Constants.SEND_ID_OF_CATEGORY,intent.getStringExtra(Constants.SEND_ID_OF_CATEGORY))
                vAddAndEditMenuItemFragment.arguments = bundal
                FragmentUtils.replaceFragment(
                    this,
                        vAddAndEditMenuItemFragment,
                    R.id.manegeManusItemContenar,
                    true
                )
                tvTitle.text = getString(R.string.add_product)
            }
            1->{
                val vAddAndEditMenuItemFragment = AddAndEditMenuItemFragment()
                val bundal =  Bundle()
                bundal.putInt(Constants.CUSTMISED_FOOD_CART,intent.getIntExtra(Constants.CUSTMISED_FOOD_CART,1))
                bundal.putSerializable(
                    Constants.KEY_FOOD_MODEL,intent.getSerializableExtra(
                        Constants.KEY_FOOD_MODEL))
                bundal.putString(Constants.SEND_ID_OF_CATEGORY,intent.getStringExtra(Constants.SEND_ID_OF_CATEGORY))
                vAddAndEditMenuItemFragment.arguments = bundal

                FragmentUtils.replaceFragment(
                    this,
                        vAddAndEditMenuItemFragment,
                    R.id.manegeManusItemContenar,
                    true
                )
                tvTitle.text = getString(R.string.details)
            }
            2->{
                val vAddAndEditMenuItemFragment = AddAndEditModifierItemFragment()
                val bundal =  Bundle()
                bundal.putInt(Constants.KEY_BOOKING_ID,intent.getIntExtra(Constants.KEY_BOOKING_ID,2))
                bundal.putString(
                    Constants.GET_MODIFIER_CETEGORYWISE_LIST,intent.getStringExtra(
                        Constants.GET_MODIFIER_CETEGORYWISE_LIST))
                vAddAndEditMenuItemFragment.arguments = bundal

                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditMenuItemFragment,
                    R.id.manegeManusItemContenar,
                    true
                )
                tvTitle.text = getString(R.string.add_item)
            }
            3->{
                val vAddAndEditMenuItemFragment = AddAndEditModifierItemFragment()
                val bundal =  Bundle()
                bundal.putInt(Constants.KEY_BOOKING_ID,intent.getIntExtra(Constants.KEY_BOOKING_ID,3))
                bundal.putSerializable(
                    Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL,intent.getSerializableExtra(
                        Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL))
                bundal.putString(
                    Constants.GET_MODIFIER_CETEGORYWISE_LIST,intent.getStringExtra(
                        Constants.GET_MODIFIER_CETEGORYWISE_LIST))
                bundal.putString(Constants.GET_ITEM_ID,intent.getStringExtra(Constants.GET_ITEM_ID))
                vAddAndEditMenuItemFragment.arguments = bundal

                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditMenuItemFragment,
                    R.id.manegeManusItemContenar,
                    true
                )
                tvTitle.text = getString(R.string.edit_item)
            }
        }
    }




    override fun onBackPressed() {
        finish()
        super.onBackPressed()
    }
}