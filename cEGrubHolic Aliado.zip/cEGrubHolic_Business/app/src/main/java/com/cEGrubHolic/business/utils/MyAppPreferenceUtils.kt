package com.example.godeliverybusinessapp.utils

import android.content.Context
import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import com.cEGrubHolic.business.models.UserSessionModel
import com.cEGrubHolic.business.utils.PackageInfoUtil
import com.cEGrubHolic.business.utils.PreferenceUtils
import com.egodelivery.business.utils.Constants


import com.google.android.gms.maps.model.LatLng
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.utils.PreferenceUtils.sharedPreferences
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


/**
 * Created by codexalters on 12/3/18.
 */
object MyAppPreferenceUtils {

    fun getToken(context: Context): String {
        return PreferenceUtils.getString(context, Constants.AUTH_TOKEN, "")!!
    }

    fun saveToken(context: Context, token: String) {
        PreferenceUtils.setString(context, Constants.AUTH_TOKEN, "Bearer $token")
    }

    fun getPushToken(context: Context): String {
        return PreferenceUtils.getString(context, Constants.PUSH_TOKEN, "")!!
    }

    fun savePushToken(context: Context, pushToken: String) {
        PreferenceUtils.setString(context, Constants.PUSH_TOKEN, pushToken)
    }

    fun isLoggedIn(context: Context): Boolean {
        return PreferenceUtils.getBoolean(context, Constants.IS_LOGGED_IN, false)
    }

    fun setLoggedIn(context: Context, isLoggedIn: Boolean) {
        PreferenceUtils.setBoolean(context, Constants.IS_LOGGED_IN, isLoggedIn)
    }
    fun saveUserSession(context: Context, userModel: UserSessionModel) {
        PreferenceUtils.setString(context, Constants.USER_SESSION, Gson().toJson(userModel))
    }

    fun getUserSession(context: Context): UserSessionModel {

        return if (PreferenceUtils.getString(context, Constants.USER_SESSION, "")!!.isNotEmpty()) {
            Gson().fromJson(
                PreferenceUtils.getString(context, Constants.USER_SESSION, ""),
               object : TypeToken<UserSessionModel>() {}.type
            )
        } else {
            UserSessionModel()
        }

    }

    /*fun getUserId(context: Context): String {

        return if (PreferenceUtils.getString(context, Constants.USER_SESSION, "").isNotEmpty()) {
            ((Gson().fromJson(
                PreferenceUtils.getString(context, Constants.USER_SESSION, ""),
                object : TypeToken<UserModel>() {}.type

            )) as UserModel).id
        } else {
            ""
        }

    }*/


    fun clearLoginSession(context: Context) {
        PreferenceUtils.setClear(context)
    }

    fun setLatestAppVersion(context: Context, versionCode: String) {
        PreferenceUtils.setString(context, Constants.APK_VERSION_CODE, versionCode)

    }

    fun isAppUpdateRequire(context: Context): Boolean {

        val latestVersionCode =
            sharedPreferences!!.getString(
                Constants.APK_VERSION_CODE,
                PackageInfoUtil.getAppVersionName(context)
            )
        return !PackageInfoUtil.getAppVersionName(context).equals(latestVersionCode)

    }

    fun isAppForcefullyUpdateRequired(context: Context): Boolean {
        return sharedPreferences!!.getBoolean(Constants.APK_FORCEFULLY_UPDATE_REQUIRED, false)
    }

    fun setForceUpdateRequired(context: Context, b: Boolean) {
        PreferenceUtils.setBoolean(context, Constants.APK_FORCEFULLY_UPDATE_REQUIRED, b)
    }

    fun printHashKey(pContext: Context) {
        try {
            val info = pContext.getPackageManager().getPackageInfo(
                pContext.packageName,
                PackageManager.GET_SIGNATURES
            )
            for (signature in info.signatures) {
                val md = MessageDigest.getInstance("SHA")
                md.update(signature.toByteArray())
                Log.i(
                    "MyAppPreferenceUtils",
                    "printHashKey : ${Base64.encodeToString(md.digest(), Base64.DEFAULT)}"
                )
            }
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }
    fun setUserCurrentLocation(requireContext: Context, latitude: Double, longitude: Double) {
        PreferenceUtils.setString(
            requireContext,
            Constants.LATITUDE,
            latitude.toString()
        )
        PreferenceUtils.setString(
            requireContext,
            Constants.LONGITUDE,
            longitude.toString()
        )
    }

    fun getServiceRunningStatus(context: Context): Boolean {
        return sharedPreferences!!.getBoolean(Constants.IS_LOCATION_SERVICE_RUNNING, false)
    }

    fun setServiceRunningStatus(context: Context, b: Boolean) {
        PreferenceUtils.setBoolean(context, Constants.IS_LOCATION_SERVICE_RUNNING, b)
    }
    fun setAppLanguage(context: Context, languageCode: String) {
        PreferenceUtils.setString(context, Constants.APK_LANGUAGE_CODE, languageCode)
    }
    fun getUserCurrentLocation(context: Context): LatLng {

        return LatLng(
            PreferenceUtils.getString(context, Constants.LATITUDE, "0.00")!!.toDouble(),
            PreferenceUtils.getString(context, Constants.LONGITUDE, "0.00")!!.toDouble()
        )
    }
    fun getAppLanguage(context: Context): String {
        return PreferenceUtils.getString(
            context,
            Constants.APK_LANGUAGE_CODE,
            Constants.AppLanguages[1].languageCode
        )!!
    }
    fun isModuleAccessible(context: Context, moduleId: Int): Boolean {
        val modules = getUserSession(context).vModules.split(",")
        return (modules.contains(moduleId.toString()))

    }

}