package com.cEGrubHolic.business.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.OrderHistoryModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.DateTimeUtils
import com.cEGrubHolic.business.utils.FormValidationUtils
import kotlinx.android.synthetic.main.raw_order_history.view.*


class OrderHistoryAdepter(val dataList: ArrayList<OrderHistoryModel>,
                          val itemClickListener: ItemClickListener
)  : RecyclerView.Adapter<OrderHistoryAdepter.MyViewHolder>() {

    var vSymbol = ""
    val dConversionRate = "1"

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_order_history,
                null
            )
        )
    }

    override fun getItemCount(): Int {
        return   dataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        vSymbol = Constants.vCurrentCurrencySymbol
        holder.itemView.tvOrderAmounts.text =  FormValidationUtils.getValueWithCurrencyCode(
            dataList[position].vOrderValue.toDouble(),
            vSymbol,
            dConversionRate
        )
        holder.itemView.tvOrderBillNos.text =  dataList[position].vOrderID
        holder.itemView.tvOrderTimeDates.text =  DateTimeUtils.convertDateFormat(
            dataList[position].vOrderDate   ,
            "yyyy-MM-dd HH:mm:ss","dd MMM,yyyy  HH:mm a"
        )

        holder.itemView.tvOrdeAddrssLocation.text = dataList[position].vOrderAddress



        holder.itemView.tvItemCount.text = dataList[position].vOrderItemCout +" "+ holder.itemView.context.getString(R.string.items)
        if(dataList[position].vNickName.isBlank()){
            holder.itemView.tvOrdeHomeloc.visibility = View.GONE
        }else{
            holder.itemView.tvOrdeHomeloc.visibility = View.VISIBLE
            holder.itemView.tvOrdeHomeloc.text = dataList[position].vNickName
        }
        if (dataList[position].vOrderStutas=="3"){
            holder.itemView.tvOrderStatus.text =   holder.itemView.context.getString(R.string.completed)
            holder.itemView.tvOrderStatus.setTextColor(Color.GREEN)
        }else if (dataList[position].vOrderStutas=="4"){
            holder.itemView.tvOrderStatus.text =   holder.itemView.context.getString(R.string.rejected)
            holder.itemView.tvOrderStatus.setTextColor(Color.RED)
        }
    }
    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener{
                itemClickListener.onItemClicked(dataList[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: OrderHistoryModel
        )
    }
}