package com.cEGrubHolic.business.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable


data class AddressSearchResponseModel(
    @SerializedName("predictions")
    val predictions: ArrayList<Predictions> = arrayListOf(),
    @SerializedName("status")
    val status: String = ""
) : Serializable {

    data class Predictions(
        @SerializedName("description") val description: String,
        @SerializedName("place_id") val placeId: String
    ) : Serializable{

        override fun toString(): String {
            return description
        }
    }
}
