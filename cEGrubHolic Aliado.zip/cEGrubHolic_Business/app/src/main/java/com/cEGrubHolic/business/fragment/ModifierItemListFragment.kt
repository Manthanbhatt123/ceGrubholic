package com.egodelivery.business.fragment

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.cEGrubHolic.business.ManageItemOfManuActivity
import com.egodelivery.business.R
import com.cEGrubHolic.business.adapter.ModifierProtineListAdepter
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.cEGrubHolic.business.utils.AlertDialogUtil
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.RC_PROTIN_ITEM_ADD
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.egodelivery.business.viewmodelprovider.ModifierGroupListVM
import kotlinx.android.synthetic.main.dialog_confirmation_for_delete.view.*
import kotlinx.android.synthetic.main.fragment_modifier_item_list.*
import kotlinx.android.synthetic.main.view_no_data.*


class ModifierItemListFragment : BaseFragment(), ModifierProtineListAdepter.ItemClickListener {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(ModifierGroupListVM::class.java)
    }

    val mProtineModifierList = arrayListOf<ModifierGroupModel>()
    private val mModifierProtineAdapter: ModifierProtineListAdepter =
        ModifierProtineListAdepter(mProtineModifierList, this)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_modifier_item_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recylcerModiferItem.visibility = View.GONE

        recylcerModiferItem.adapter = mModifierProtineAdapter

        if (!userViewModel.removeModifierItemListApi.hasActiveObservers()) {
            userViewModel.removeModifierItemListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {

                        }
                        ApiResponseStatus.SUCCESS -> {
                            userViewModel.getModifierItemList(arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!)
                            mModifierProtineAdapter.notifyDataSetChanged()
                            showSnackbar(
                                recylcerModiferItem,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                        }
                        ApiResponseStatus.ERROR -> {
                            showSnackbar(
                                recylcerModiferItem,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {

                            showSnackbar(
                                recylcerModiferItem,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {

                        }

                    }

                })
        }



        if (!userViewModel.getModifierItemListApi.hasActiveObservers()) {
            userViewModel.getModifierItemListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            if (modifierSwipTorefresh != null){
                                modifierSwipTorefresh.isRefreshing = true
                            }
                        }
                        ApiResponseStatus.SUCCESS -> {
                            if (modifierSwipTorefresh != null) {
                                modifierSwipTorefresh.isRefreshing = false
                                mProtineModifierList.clear()
                                mProtineModifierList.addAll(
                                    Gson().fromJson(
                                        it.data,
                                        object : TypeToken<List<ModifierGroupModel>>() {}.type
                                    )
                                )
                                mModifierProtineAdapter.notifyDataSetChanged()
                                showDetailView(true, it.message)
                            }
                        }
                        ApiResponseStatus.ERROR -> {
                            if (modifierSwipTorefresh != null) {
                                modifierSwipTorefresh.isRefreshing = false
                                showDetailView(false, it.message)
                            }

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            modifierSwipTorefresh.isRefreshing = false
                            showDetailView(false, it.message)

                        }
                        else -> {
                            modifierSwipTorefresh.isRefreshing = false
                        }

                    }

                })
        }
        modifierSwipTorefresh.setOnRefreshListener {
            userViewModel.getModifierItemList(arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!)
        }
        userViewModel.getModifierItemList(arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!)


    }

    override fun onResume() {
        userViewModel.getModifierItemList(arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!)
        super.onResume()
    }

    override fun onItemClicked(menuPos: ModifierGroupModel) {

    }

    override fun onEditClicked(menuPos: ModifierGroupModel) {
        startActivityForResult(
            Intent(activity!!, ManageItemOfManuActivity::class.java)
                .putExtra(Constants.CUSTMISED_FOOD_CART, 3)
                .putExtra(Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL,menuPos)
                .putExtra(
                    Constants.GET_MODIFIER_CETEGORYWISE_LIST,
                    arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)
                )
                .putExtra(Constants.GET_ITEM_ID,menuPos.id)
            ,RC_PROTIN_ITEM_ADD

        )
    }

    override fun onDeletedClicked(menuPos: ModifierGroupModel) {
        val deleteAdView = LayoutInflater.from(activity)
            .inflate(R.layout.dialog_confirmation_for_delete, null)

        val deleteAlert =
            AlertDialogUtil.createCustomAlertDialog(activity!!, deleteAdView)


        deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        deleteAlert.setCancelable(false)
        deleteAlert.show()
        deleteAdView.btnPositiveDelete.setOnClickListener {
            userViewModel.removeModifierItemList(menuPos.id)
            deleteAlert.dismiss()
        }
        deleteAdView.btnNegativeDelelte.setOnClickListener {

            deleteAlert.dismiss()
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            RC_PROTIN_ITEM_ADD->{
                userViewModel.getModifierItemList(arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!)
            }
        }
    }


    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recylcerModiferItem.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recylcerModiferItem.visibility = View.GONE

        }

    }


}