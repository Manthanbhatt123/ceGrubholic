package com.cEGrubHolic.business.pushnotificetion

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.egodelivery.business.utils.Constants


import org.json.JSONObject
import java.util.*

/**
 * Created by Ashish on 13/12/19.
 */
class GcmBroadcastReceiver : BroadcastReceiver() {

    private val TAG = "GcmBroadcastReceiver"

    override fun onReceive(context: Context, intentData: Intent) {

        try {

            Log.d(TAG, "onReceive: "
                        + intentData.component!!.packageName + "\n" + intentData.extras)

            val comp = intentData.component!!.packageName

            if (comp == context.packageName
                && intentData.extras != null
            ) {
                val intent = Intent()

                //extra payload for silently update App UI without sending notification

                val notificationDataBundle = Bundle()

                if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_nPushType)) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_nPushType,
                        intentData.extras!!.getString(Constants.KEY_NOTIFICATION_nPushType)
                    )

                }

                if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_nId)) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_nId,
                        intentData.extras!!.getString(Constants.KEY_NOTIFICATION_nId)
                    )
                }

                val vOtherJson =
                    if (intentData.extras!!.containsKey(Constants.KEY_NOTIFICATION_vOther)
                        && !intentData.extras!!.getString(Constants.KEY_NOTIFICATION_vOther).isNullOrBlank()
                    ) {
                        JSONObject(intentData.extras!!.getString(Constants.KEY_NOTIFICATION_vOther)!!)
                    } else {
                        null
                    }


                if (vOtherJson != null) {
                    notificationDataBundle.putString(
                        Constants.KEY_NOTIFICATION_vOther,
                        vOtherJson.toString()
                    )
                }

                intent.putExtra(Constants.KEY_NOTIFICATION_DATA_BUNDLE, notificationDataBundle)
                intent.action = Constants.INTENT_ACTION_NOTIFICATION

                val isSilentPush = if (vOtherJson != null) {
                    vOtherJson.has(Constants.KEY_NOTIFICATION_vOther_isSlientRequired)
                            && vOtherJson[Constants.KEY_NOTIFICATION_vOther_isSlientRequired] == 1
                } else {
                    false
                }

                if (isSilentPush) {
                    context.sendBroadcast(intent)
                }

            }
        } catch (e: Exception) {
            Log.e(TAG, "onReceive : ${e.printStackTrace()} ")
        }
    }


    private fun getNotificationId(): Int {
        return Random().nextInt(9999 - 1000) + 1000
    }

}