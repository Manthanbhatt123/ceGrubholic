package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName

data class MontholyIncomeModel(
    @SerializedName("months")
    val monthsOfIncome: String = "",
    @SerializedName("totalincome")
    val vTotalIncome: Int = 0
)
