package com.cEGrubHolic.business.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class ReviewsViewModel(
    @SerializedName("nSpeedRate")
    val nSpeedRate: String = "",
    @SerializedName("nAvgRate")
    val nAvgRate: Double = 0.0,
    @SerializedName("dCreatedDate")
    val dCreatedDate: String = "",
    @SerializedName("vFirstName")
    val vFirstName: String = "",
    @SerializedName("vLastName")
    val vLastName: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("nServiceRate")
    val nServiceRate: String = "",
    @SerializedName("vNote")
    val vNote: String = "",
    @SerializedName("nQualityRate")
    val nQualityRate: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = ""

): Serializable





