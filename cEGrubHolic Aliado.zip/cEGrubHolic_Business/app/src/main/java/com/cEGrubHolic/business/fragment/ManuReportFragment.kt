package com.cEGrubHolic.business.fragment

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.MyValueFormatter

import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.MonthlyOrderModel
import com.cEGrubHolic.business.models.MontholyIncomeModel
import com.egodelivery.business.models.RepoetsModel
import com.cEGrubHolic.business.utils.DateTimeUtils
import com.example.godeliverybusinessapp.viewmodelprovider.GeneralVM
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.MarkerView
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.github.mikephil.charting.utils.MPPointF
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_manu_report.*
import java.util.ArrayList


class ManuReportFragment : BaseFragment(), OnChartValueSelectedListener {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GeneralVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_manu_report, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!userViewModel.reportResponseObservable.hasActiveObservers()) {
            userViewModel.reportResponseObservable.observe(
                activity!!,
                androidx.lifecycle.Observer { it->
                    when (it.status) {
                            ApiResponseStatus.LOADING -> {
                                swipeToRefreshReport.isRefreshing = true
                            }
                            ApiResponseStatus.SUCCESS -> {
                                swipeToRefreshReport.isRefreshing = false


                                 val getReportModel:RepoetsModel =   Gson().fromJson(
                                        it.data!!,
                                        object : TypeToken<RepoetsModel>() {}.type
                                    )
                               setDataForMonthlyOrder(getReportModel.monthlyOrder)
                                setDataForMonthlyIcome(getReportModel.monthlyIncome)

                          //      showDetailView(true, it.message)

                            }
                            ApiResponseStatus.ERROR -> {

                                swipeToRefreshReport.isRefreshing = false
                              //  showDetailView(false, it.message)

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                swipeToRefreshReport.isRefreshing = false
                            //    showDetailView(false, getString(R.string.no_internet))

                            }
                            else -> {
                                swipeToRefreshReport.isRefreshing = false
                            }

                        }


                })
        }
        swipeToRefreshReport.setOnRefreshListener {
            userViewModel.getReports()
        }
        userViewModel.getReports()
    }



    private fun setDataForMonthlyOrder(vMonthlyOrderList: ArrayList<MonthlyOrderModel>) {
        val labels = arrayListOf<String>()


        val valuesForCurrentYear: ArrayList<BarEntry> = ArrayList()

        for ((Index,item) in vMonthlyOrderList.withIndex()) {
            valuesForCurrentYear.add(BarEntry(Index.toFloat(), item.vTotalOrders.toFloat()))
            labels.add( DateTimeUtils.convertDateFormat(
                item.monthOfOrders,
                "yyyy-MM-dd HH:mm:ss","MMM,yyyy"
            ))
        }

        simpleChartForMonthlyOrder.setBackgroundColor(Color.WHITE)
        simpleChartForMonthlyOrder.description.isEnabled = false
        simpleChartForMonthlyOrder.setTouchEnabled(false)
        simpleChartForMonthlyOrder.setDrawGridBackground(false)
        simpleChartForMonthlyOrder.isDragEnabled = false
        simpleChartForMonthlyOrder.setScaleEnabled(false)
        simpleChartForMonthlyOrder.setPinchZoom(false)
        simpleChartForMonthlyOrder.setOnChartValueSelectedListener(this)
        simpleChartForMonthlyOrder.pivotX = 0f
        simpleChartForMonthlyOrder.pivotY = 0f
        simpleChartForMonthlyOrder.setNoDataText("")
        simpleChartForMonthlyOrder.setNoDataTextColor(Color.WHITE)
        simpleChartForMonthlyOrder.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        simpleChartForMonthlyOrder.setFitBars(true)
        simpleChartForMonthlyOrder.setTouchEnabled(true)
        simpleChartForMonthlyOrder.setPinchZoom(false)
        simpleChartForMonthlyOrder.isDoubleTapToZoomEnabled = false
        val custom: ValueFormatter =
            MyValueFormatter("")

        val xAxis: XAxis = simpleChartForMonthlyOrder.xAxis
        xAxis.disableGridDashedLine()
        xAxis.disableAxisLineDashedLine()
        xAxis.setDrawAxisLine(true)
        xAxis.setDrawGridLinesBehindData(false)
        xAxis.setDrawGridLines(false)
        xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        xAxis.labelCount = labels.size
        xAxis.setAvoidFirstLastClipping(false)
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.setCenterAxisLabels(false);
        xAxis.axisMinimum = -0.5f


        val yAxis: YAxis = simpleChartForMonthlyOrder.axisLeft
        simpleChartForMonthlyOrder.axisRight.isEnabled = false
        yAxis.disableGridDashedLine()
        yAxis.disableAxisLineDashedLine()
        yAxis.setDrawAxisLine(true)
        yAxis.valueFormatter = custom;
        yAxis.mAxisMaximum = 0f
        yAxis.granularity = 1f
        yAxis.setDrawZeroLine(true)

        val mv = XYMarkerViewMonthlyOrder(context)
        mv.chartView = simpleChartForMonthlyOrder // For bounds control
        simpleChartForMonthlyOrder.marker = mv // Set the marker to the chart


        simpleChartForMonthlyOrder.clear()
        simpleChartForMonthlyOrder.notifyDataSetChanged()



        val earningSet = BarDataSet(valuesForCurrentYear, "")
        earningSet.color = ContextCompat.getColor(context!!, R.color.go_image_tint)
        earningSet.setDrawValues(false)
        val dataSets: ArrayList<IBarDataSet> = ArrayList()
        dataSets.add(earningSet)

        val data = BarData(dataSets)
        //    data.setValueTextSize(10f)
        data.barWidth = 0.5f


        simpleChartForMonthlyOrder.data = data
        simpleChartForMonthlyOrder.invalidate()

    }

    private fun setDataForMonthlyIcome(vMonthlyIncomeList: ArrayList<MontholyIncomeModel>) {


          val labels = arrayListOf<String>()

        val valuesForCurrentYear: ArrayList<BarEntry> = ArrayList()

        for ((index, item) in vMonthlyIncomeList.withIndex()) {
            valuesForCurrentYear.add(BarEntry(index.toFloat(),  item.vTotalIncome.toFloat()))
            labels.add( DateTimeUtils.convertDateFormat(
                item.monthsOfIncome,
                "yyyy-MM-dd HH:mm:ss","MMM,yyyy"
            ))
        }


        simpleChartForMonthlyIncome.setBackgroundColor(Color.WHITE)
        simpleChartForMonthlyIncome.description.isEnabled = false
        simpleChartForMonthlyIncome.setTouchEnabled(false)
        simpleChartForMonthlyIncome.setDrawGridBackground(false)
        simpleChartForMonthlyIncome.isDragEnabled = false
        simpleChartForMonthlyIncome.setScaleEnabled(false)
        simpleChartForMonthlyIncome.setPinchZoom(false)
        simpleChartForMonthlyIncome.setOnChartValueSelectedListener(this)
        simpleChartForMonthlyIncome.pivotX = 0f
        simpleChartForMonthlyIncome.pivotY = 0f
        simpleChartForMonthlyIncome.setNoDataText("")
        simpleChartForMonthlyIncome.setNoDataTextColor(Color.WHITE)
        simpleChartForMonthlyIncome.legend.horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
        simpleChartForMonthlyIncome.setFitBars(true)
        simpleChartForMonthlyIncome.setTouchEnabled(true)
        simpleChartForMonthlyIncome.setPinchZoom(false)
        simpleChartForMonthlyIncome.isDoubleTapToZoomEnabled = false
        val custom: ValueFormatter =
            MyValueFormatter("")

        val xAxis: XAxis = simpleChartForMonthlyIncome.xAxis
        xAxis.disableGridDashedLine()
        xAxis.disableAxisLineDashedLine()
        xAxis.setDrawAxisLine(true)
        xAxis.setDrawGridLinesBehindData(false)
        xAxis.setDrawGridLines(false)
        xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        xAxis.labelCount = labels.size
        xAxis.setAvoidFirstLastClipping(false)
        xAxis.position = XAxis.XAxisPosition.BOTTOM
        xAxis.axisMinimum = -0.5f
        xAxis.setCenterAxisLabels(false);

        val yAxis: YAxis = simpleChartForMonthlyIncome.axisLeft
        simpleChartForMonthlyIncome.axisRight.isEnabled = false
        yAxis.disableGridDashedLine()
        yAxis.disableAxisLineDashedLine()
        yAxis.setDrawAxisLine(true)
        yAxis.valueFormatter = custom
        yAxis.mAxisMaximum = 0f
        yAxis.granularity = 1f
        yAxis.setDrawZeroLine(true)

        val mv = XYMarkerViewMonthlyIncome(context)
        mv.chartView = simpleChartForMonthlyIncome // For bounds control
        simpleChartForMonthlyIncome.marker = mv // Set the marker to the chart


        simpleChartForMonthlyIncome.clear()
        simpleChartForMonthlyIncome.notifyDataSetChanged()






        val earningSet = BarDataSet(valuesForCurrentYear, "")
        earningSet.color = ContextCompat.getColor(context!!, R.color.go_image_tint)
        earningSet.setDrawValues(false)
        val dataSets: ArrayList<IBarDataSet> = ArrayList()
        dataSets.add(earningSet)

        val data = BarData(dataSets)
        //    data.setValueTextSize(10f)
        data.barWidth = 0.5f



        simpleChartForMonthlyIncome.data = data
        simpleChartForMonthlyIncome.invalidate()

    }



    inner class XYMarkerViewMonthlyOrder(context: Context?) :
        MarkerView(context, R.layout.custom_marker_view) {
        private val tvContent: TextView = findViewById(R.id.textVelueOfGraf)



        // runs every time the MarkerView is redrawn, can be used to update the
        // content (user-interface)
        override fun refreshContent(e: Entry, highlight: Highlight?) {


            val x:Float =e.x
            val y:Float =e.y
            simpleChartForMonthlyOrder.highlightValue(highlight)
            tvContent.text = y.toString()




            super.refreshContent(e, highlight)
        }

        override fun getOffset(): MPPointF {
            return MPPointF((-(width / 2)).toFloat(), (-height).toFloat())
        }

    }

    inner class XYMarkerViewMonthlyIncome(context: Context?) :
        MarkerView(context, R.layout.custom_marker_view) {
        private val tvContent: TextView = findViewById(R.id.textVelueOfGraf)



        // runs every time the MarkerView is redrawn, can be used to update the
        // content (user-interface)
        override fun refreshContent(e: Entry, highlight: Highlight?) {


            val x:Float =e.x
            val y:Float =e.y
            simpleChartForMonthlyIncome.highlightValue(highlight)
            tvContent.text = y.toString()




            super.refreshContent(e, highlight)
        }

        override fun getOffset(): MPPointF {
            return MPPointF((-(width / 2)).toFloat(), (-height).toFloat())
        }

    }

    override fun onValueSelected(e: Entry?, h: Highlight?) {


    }

    override fun onNothingSelected() {

    }

}