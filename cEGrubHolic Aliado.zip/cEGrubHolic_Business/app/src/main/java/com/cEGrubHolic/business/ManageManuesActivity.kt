package com.egodelivery.business

import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.cEGrubHolic.business.ManageItemOfManuActivity
import com.cEGrubHolic.business.fragment.AddAndEditManusFragment
import com.cEGrubHolic.business.fragment.AddAndEditModifierFragment
import com.cEGrubHolic.business.fragment.AddAndEditPromocodeFragment
import com.egodelivery.business.fragment.*
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.GET_TITLE_OF_FRAGMENT
import com.cEGrubHolic.business.utils.FragmentUtils
import kotlinx.android.synthetic.main.app_main_toolbar.*

class ManageManuesActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manage_manues)
       setLightStatusBar()

        btnLeft.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.ic_back))
        btnLeft.setOnClickListener {
            finish()
        }
        val getFragment = intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,0)

        when(getFragment){
            0->{
                val vAddAndEditManusFragment = AddAndEditManusFragment()
                val bundle = Bundle()
                bundle.putInt(Constants.OPEN_ADD_FRAGMENT,intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,0))
               vAddAndEditManusFragment.arguments = bundle
                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditManusFragment,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.add_category)
            }
            1->{
                val vAddAndEditManusFragment = AddAndEditManusFragment()
                val bundle = Bundle()
                bundle.putInt(Constants.OPEN_ADD_FRAGMENT,intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,1))
                bundle.putSerializable(
                    Constants.SEND_CATEGORY_DATA,intent.getSerializableExtra(
                        Constants.SEND_CATEGORY_DATA))
                vAddAndEditManusFragment.arguments = bundle
                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditManusFragment,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.details)
            }
            2->{
                val vManegItemOfManuesFragment = ManegItemOfManuesFragment()
                val bundale = Bundle()
                bundale.putString(Constants.SEND_ID_OF_CATEGORY,intent.getStringExtra(Constants.SEND_ID_OF_CATEGORY))
                vManegItemOfManuesFragment.arguments = bundale
                val getTitel = intent.getStringExtra(GET_TITLE_OF_FRAGMENT)
                tvTitle.text =getTitel
                FragmentUtils.replaceFragment(
                    this,
                        vManegItemOfManuesFragment,
                    R.id.manegeManusContenar,
                    true
                )
                btnRight.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.ic_plus))
                btnRight.setOnClickListener {
                    startActivityForResult(
                            Intent(this, ManageItemOfManuActivity::class.java)
                                    .putExtra(
                                        Constants.SEND_ID_OF_CATEGORY,intent.getStringExtra(
                                            Constants.SEND_ID_OF_CATEGORY))
                                    .putExtra(Constants.CUSTMISED_FOOD_CART,0), Constants.RC_ADD_FOODITEM
                    )
                }

            }
            3->{
                val vAddAndEditManusFragment = AddAndEditModifierFragment()
                val bundle = Bundle()
                bundle.putInt(Constants.OPEN_ADD_FRAGMENT,intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,3))
                vAddAndEditManusFragment.arguments = bundle
                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditManusFragment,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.add_modifier)
            }
            4->{
                val vAddAndEditManusFragment = AddAndEditModifierFragment()
                val bundle = Bundle()
                bundle.putInt(Constants.OPEN_ADD_FRAGMENT,intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,4))
                bundle.putSerializable(
                    Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL,intent.getSerializableExtra(
                        Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL))
                bundle.putString(Constants.GET_ITEM_ID,intent.getStringExtra(Constants.GET_ITEM_ID))
                vAddAndEditManusFragment.arguments = bundle
                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditManusFragment,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.edit_modifier)
            }
            5->{
                val vAddAndEditManusFragment = ModifierItemListFragment()
                val bundle = Bundle()
                bundle.putString(
                    Constants.GET_MODIFIER_CETEGORYWISE_LIST,intent.getStringExtra(
                        Constants.GET_MODIFIER_CETEGORYWISE_LIST))
                bundle.putInt(Constants.OPEN_ADD_FRAGMENT,intent.getIntExtra(Constants.OPEN_ADD_FRAGMENT,5))
                vAddAndEditManusFragment.arguments = bundle
                FragmentUtils.replaceFragment(
                    this,
                    vAddAndEditManusFragment,
                    R.id.manegeManusContenar,
                    true
                )
                val getProtinName = intent.getStringExtra(Constants.ACTION_RESTART_SERVICE)
                tvTitle.text = getProtinName
                btnRight.setImageDrawable(ContextCompat.getDrawable(this,R.drawable.ic_plus))
                btnRight.setOnClickListener {
                    startActivityForResult(
                        Intent(this, ManageItemOfManuActivity::class.java)
                            .putExtra(Constants.CUSTMISED_FOOD_CART,intent.getIntExtra(Constants.KEY_BOOKING_ID,2))
                            .putExtra(
                                Constants.GET_MODIFIER_CETEGORYWISE_LIST,intent.getStringExtra(
                                    Constants.GET_MODIFIER_CETEGORYWISE_LIST)),
                        Constants.RC_PROTIN_ITEM_ADD
                    )
                }
            }
            6->{
                var bundalPromocode = Bundle()
                bundalPromocode.putInt(Constants.FOR_API_CALLING_PROMOCODE,intent.getIntExtra(Constants.FOR_API_CALLING_PROMOCODE,1))
                var addPromocodeFrg =  AddAndEditPromocodeFragment()
                addPromocodeFrg.arguments = bundalPromocode
                FragmentUtils.replaceFragment(
                    this,
                    addPromocodeFrg ,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.add_promocode)
            }
            7 ->{
                var bundalPromocode = Bundle()
                bundalPromocode.putInt(Constants.FOR_API_CALLING_PROMOCODE,intent.getIntExtra(Constants.FOR_API_CALLING_PROMOCODE,2))
                bundalPromocode.putSerializable(Constants.GET_PROMOCODE_DATA,intent.getSerializableExtra(Constants.GET_PROMOCODE_DATA))
                var editPromocodeFrg =  AddAndEditPromocodeFragment()
                editPromocodeFrg.arguments = bundalPromocode
                FragmentUtils.replaceFragment(
                    this,
                    editPromocodeFrg,
                    R.id.manegeManusContenar,
                    true
                )
                tvTitle.text = getString(R.string.edit_promocode)
            }
        }
    }

    override fun onBackPressed() {
        finish()
        super.onBackPressed()
    }
}


