package com.cEGrubHolic.business.fragment

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.egodelivery.business.R
import com.egodelivery.business.BaseActivity
import com.cEGrubHolic.business.BaseFragment

import com.cEGrubHolic.business.SelectAddressHandlerActivity
import com.egodelivery.business.utils.Constants.KEY_BUSINESS_ADDRESS
import com.egodelivery.business.utils.Constants.RC_ADDRESS
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.models.AppLanguageModel
import com.cEGrubHolic.business.models.UserSessionModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.example.godeliverybusinessapp.utils.*
import com.egodelivery.business.utils.Constants.AppLanguages_ENGLISH
import com.egodelivery.business.utils.Constants.AppLanguages_SPANISH
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.LocaleManager
import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import com.github.dhaval2404.imagepicker.ImagePicker

import kotlinx.android.synthetic.main.fragment_menu_profile.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File


class ManuProfileFragment : BaseFragment() {

    var vSymbol = ""
    val dConversionRate = "1"

    private val userVM by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    private var latitude = 0.00
    private var longitude = 0.00
    private var address = ""
    private var selectedProfileFile: File? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        vSymbol = Constants.vCurrentCurrencySymbol

        if (!userVM.updateProfileApiResponseObserver.hasActiveObservers())
            userVM.updateProfileApiResponseObserver.observe(activity!!, Observer { it->
                it.getContentIfNotHandled()?.let { it ->

                    when (it?.status) {
                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                relProfileDone,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                            MyAppPreferenceUtils.saveUserSession(
                                context!!, Gson().fromJson(
                                    it.data,
                                    object : TypeToken<UserSessionModel>() {}.type
                                )
                            )
                            updateUI(
                                MyAppPreferenceUtils.getUserSession(context!!)
                            )

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                relProfileDone,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                relProfileDone,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        }
                    }
                }
            })


        if (!userVM.getProfileApiResponseObserver.hasActiveObservers())
            userVM.getProfileApiResponseObserver.observe(activity!!, Observer { it->
                it.getContentIfNotHandled()?.let { it ->

                    when (it?.status) {
                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()

                            MyAppPreferenceUtils.saveUserSession(
                                context!!, Gson().fromJson(
                                    it.data,
                                    object : TypeToken<UserSessionModel>() {}.type
                                )
                            )
                            updateUI(
                                MyAppPreferenceUtils.getUserSession(context!!)
                            )

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                relProfileDone,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
//                        updateUI(MyAppPreferenceUtils.getUserSession(context!!))
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                relProfileDone,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )
//                        updateUI(MyAppPreferenceUtils.getUserSession(context!!))
                        }
                    }
                }
            })

        userVM.getProfile()












        relProfileDone.setOnClickListener {
            if (isValidForm()) {

                val multipartArray = arrayListOf<MultipartBody.Part>()
                if (selectedProfileFile != null)
                    multipartArray.add(
                        MultipartBody.Part.createFormData(
                            "vImagePath", selectedProfileFile!!.name,
                            RequestBody.create(MediaType.parse("image/*"), selectedProfileFile!!)
                        )
                    )

                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "vName",
                        eddRestorantTitle.text.toString().trim()
                    )
                )
                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "vAddress",
                        address.trim()
                    )
                )
                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "dLat",
                        latitude.toString()
                    )
                )
                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "dLng",
                        longitude.toString()
                    )
                )
                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "vLanguage",
                        Constants.AppLanguages[appLangugeDropDown.selectedItemPosition].languageCode
                    )
                )

                userVM.updateProfile(multipartArray)
            }

        }
        imageRestorntImage.setOnClickListener {
            (activity as BaseActivity).checkAndAskStoragePermission { isStoragePermissionGranted ->
                if (isStoragePermissionGranted) {
                    (activity as BaseActivity).checkAndAskCameraPermission { isCameraPermissionGranted ->
                        if (isCameraPermissionGranted) {
                            ImagePicker.with(this)
                                .crop()
                                .setImageProviderInterceptor { imageProvider -> // Intercept ImageProvider
                                    Log.d("ImagePicker", "Selected ImageProvider: " + imageProvider.name)
                                }
                                .setDismissListener {
                                    Log.d("ImagePicker", "Dialog Dismiss")
                                }
                                // Image resolution will be less than 512 x 512
                                //.maxResultSize(200, 200)
                                .start(Constants.PROFILE_IMAGE_REQ_CODE)
                        }
                    }
                }
            }
        }



        edtResstoranAddress.setOnClickListener {
            startActivityForResult(
                Intent(activity, SelectAddressHandlerActivity::class.java)
                    .putExtra(Constants.KEY_CAPTAIN,0)
                    .putExtra("latitude", latitude)
                    .putExtra("longitude", longitude)
                    .putExtra("address", address), RC_ADDRESS
            )

        }


    }

    fun updateUI(businessProfileModle: UserSessionModel){

        Glide.with(context!!).load(businessProfileModle.vImagePath).into(imageRestorntImage)

        eddRestorantTitle.setText(businessProfileModle.vName)

        tvWalletBlance.text =   FormValidationUtils.getValueWithCurrencyCode(
            businessProfileModle.dWallet.toDouble(),
            vSymbol,
            dConversionRate
        )

        edtResstoranAddress.text = businessProfileModle.vAddress

        address = businessProfileModle.vAddress
        latitude = businessProfileModle.dLat.toDouble()
        longitude = businessProfileModle.dLng.toDouble()

        if(btnSubmitMyProfile.text.toString().length>6) {
            appLangugeDropDown.adapter = object : ArrayAdapter<AppLanguageModel>(
                context!!,
                android.R.layout.simple_spinner_dropdown_item,
                AppLanguages_SPANISH
            ) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent)
                    (v as TextView).textSize = 0f
                    v.setTextColor(Color.TRANSPARENT)
                    return v
                }
            }
        }else {
            appLangugeDropDown.adapter = object : ArrayAdapter<AppLanguageModel>(
                context!!,
                android.R.layout.simple_spinner_dropdown_item,
                AppLanguages_ENGLISH
            ) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val v = super.getView(position, convertView, parent)
                    (v as TextView).textSize = 0f
                    v.setTextColor(Color.TRANSPARENT)
                    return v
                }
            }
        }
        // languge change
        appLangugeDropDown.onItemSelectedListener =
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(
                    parent: AdapterView<*>,
                    view: View?,
                    position: Int,
                    id: Long
                ) {
                    if(btnSubmitMyProfile.text.toString().length>6) {
                        tvMyApplanguge.text = AppLanguages_SPANISH[position].language
                    }
                    else{
                        tvMyApplanguge.text = AppLanguages_ENGLISH[position].language
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>) {

                }
            }
        for ((index, cuntry) in Constants.AppLanguages.withIndex()) {
            if (cuntry.languageCode == businessProfileModle.vAppLanguage) {
                appLangugeDropDown.setSelection(index)

                break
            }
        }

        if (MyAppPreferenceUtils.getAppLanguage(context!!) == businessProfileModle.vAppLanguage) {
            return
        }

        LocaleManager.setNewLocale(context!!, businessProfileModle.vAppLanguage)

      /*  val intentforresult = Intent()
        intentforresult.putExtra(Constants.APK_LANGUAGE_CODE, true)
        activity!!.setResult(Activity.RESULT_OK, intentforresult)*/
        LocaleManager.setNewLocale(context!!, businessProfileModle.vAppLanguage)
        WebServiceRetrofitUtil.destroyInstance()
        WebServiceRetrofitUtil.init(context!!)
        (activity!!.recreate())



    }
    fun setLocalImage(uri: Uri) {
        selectedProfileFile = File(uri.path!!)

        Glide.with(this).load(uri.path.toString()).into(imageRestorntImage)


    }




    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {

                Constants.PROFILE_IMAGE_REQ_CODE ->{
                    val uri: Uri = data?.data!!
                    setLocalImage(uri)
                }

            /*    CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE -> {
                    val cropResult = CropImage.getActivityResult(data)
                    if (resultCode == Activity.RESULT_OK) {


                        selectedProfileFile = File(cropResult.uri.path)
                        Glide.with(this).load(cropResult.uri).into(imageRestorntImage)


                    } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                        val error = cropResult.error

                        try {
                            showSnackbar(
                                eddRestorantTitle,
                                error.message!!,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                        } catch (e: Exception) {
                            Log.e("ProfileFragment", "onActivityResult : ${e.message} ")
                        }
                    }
                }*/
                RC_ADDRESS -> {

                    if (data != null) {

                        val addressData = data.extras!!.get(KEY_BUSINESS_ADDRESS) as Intent

                        latitude = addressData.getDoubleExtra("latitude", 0.00)
                        longitude = addressData.getDoubleExtra("longitude", 0.00)
                        address = addressData.getStringExtra("address")!!
                        edtResstoranAddress.text = address
                    }

                }


            }
        }
    }

    private fun isValidForm(): Boolean {


        if (!FormValidationUtils.isValidText(eddRestorantTitle.text.toString().trim())) {
            eddRestorantTitle.requestFocus()
            showSnackbar(
                eddRestorantTitle,
                getString(R.string.enter_title),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }  else  if (!FormValidationUtils.isValidText(edtResstoranAddress.text.toString().trim())) {
            edtResstoranAddress.requestFocus()
            showSnackbar(
                edtResstoranAddress,
                getString(R.string.restorant_address),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }else{
            return true
        }
    }


}