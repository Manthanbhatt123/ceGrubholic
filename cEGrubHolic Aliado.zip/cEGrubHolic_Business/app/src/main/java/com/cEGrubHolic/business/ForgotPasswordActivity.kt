package com.cEGrubHolic.business

import android.os.Bundle
import android.os.Handler
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.egodelivery.business.BaseActivity
import com.egodelivery.business.R

import com.example.godeliverybusinessapp.viewmodelprovider.UserAuthVM
import kotlinx.android.synthetic.main.activity_forgot_password.*

class ForgotPasswordActivity : BaseActivity() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(UserAuthVM::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        setLightStatusBarWhite()


        relForgotPassword.setOnClickListener {
            if (!FormValidationUtils.isValidEmail(tvForgotPasswordEmail.text.toString().trim())) {
                tvForgotPasswordEmail.requestFocus()
                showSnackbar(relForgotPassword, getString(R.string.enter_velid_email), SnackbarUtils.SnackbarType.WARNING)
                return@setOnClickListener
            }else {
                userViewModel.forgotPassword(tvForgotPasswordEmail.text.toString().trim())
            }
        }
     //   imgBack.setOnClickListener { finish() }

        if (!userViewModel.forgotPasswordApiResponseObservable.hasActiveObservers()) {
            userViewModel.forgotPasswordApiResponseObservable.observe(this, Observer {it->
                it.getContentIfNotHandled()?.let { it ->

                    when (it.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {

                            hideProgress()
                            showSnackbar(
                                tvForgotPasswordEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                            Handler().postDelayed({
                                finish()
                            }, 1500)

                        }
                        ApiResponseStatus.ERROR -> {

                            hideProgress()
                            showSnackbar(
                                tvForgotPasswordEmail,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )


                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {

                            hideProgress()
                            destroyLoginSession(true)
                        }
                        ApiResponseStatus.NO_INTERNET -> {



                        }
                        else -> {
                            hideProgress()
                        }
                    }
                }

            })
        }



    }
}
