package com.pickapp.foods.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import okhttp3.MultipartBody
import java.util.ArrayList

class CouponDitailsVM:ViewModel() {

    val addDiscountCouponApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addDiscountCoupon(fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.addDiscountCoupon(fields)

        addDiscountCouponApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addDiscountCouponApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addDiscountCouponApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addDiscountCouponApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addDiscountCouponApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val updateDiscountCouponApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun updateDiscountCoupon(fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.updateDiscountCoupon(fields)

        updateDiscountCouponApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateDiscountCouponApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateDiscountCouponApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    updateDiscountCouponApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    updateDiscountCouponApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val getCouponDetailsApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getCouponDetails(nCouponId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getCouponDetails(nCouponId)

        getCouponDetailsApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getCouponDetailsApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getCouponDetailsApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getCouponDetailsApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getCouponDetailsApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val getCouponListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getCouponList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getDiscoutCouponList()

        getCouponListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getCouponListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getCouponListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getCouponListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getCouponListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val removeCouponApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeCouponList(nCouponId:String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.removeCoupon(nCouponId)

        removeCouponApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeCouponApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeCouponApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeCouponApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeCouponApi.postValue(ApiResponse().noInternet())
                }
            })
    }

}