package com.cEGrubHolic.business.utils


import android.text.InputFilter
import android.text.Spanned
import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*
import java.util.regex.Pattern


/**
 * Created by codexalters on 6/2/18.
 */
object FormValidationUtils {

    fun isValidEmail(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches()
    }

    fun isValidText(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && target.length >= 1
    }

    fun isValidPhone(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && Patterns.PHONE.matcher(target).matches() && target.length > 7
    }

    fun isValidPassword(password: String?): Boolean {

        /*  Pattern pattern;
        Matcher matcher;
//        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();*/


        var flag = false
        if (password != null && !password.equals("", false)
            && !password.equals(" ", false)
            && password.trim().length >= 8
            && password.trim().length <= 16
        ) {
            flag = true
        }
        return flag
    }
    fun isValidMaxNumber(target: CharSequence): Boolean {
        return !TextUtils.isEmpty(target) && Patterns.PHONE.matcher(target).matches() && target.length > 0
    }

    fun isValidPassword(password: String, length: Int): Boolean {

        /*  Pattern pattern;
        Matcher matcher;
//        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,15}$";

        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();*/


        var flag = false
        if (password != null && !password.equals("", false)
            && !password.equals(" ", false)
            && password.trim().length >= length
        ) {
            flag = true
        }
        return flag
    }

    fun isStringValid(value: String?): Boolean {
        var flag = false
        if (value != null && !value.equals("", false)
            && value.trim().isNotEmpty()
        ) {
            flag = true
        }
        return flag
    }
    fun getValueWithCurrencySymbolCode(
        amount: Any,
        currencySymbol: String,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            currencySymbol + convertToDecimal(amount.toString())
        } else {
            currencySymbol + convertToDecimal((amount.toString().toDouble() * conversionRate.toDouble()).toString())

        }
    }

    fun isValidRePassword(pass1: String, pass2: String): Boolean {
        return pass1 == pass2
    }

    fun upperCaseFirstLetter(string: String): String {
        if (TextUtils.isEmpty(string)) {
            return string
        } else {
            val sb = StringBuilder(string)
            sb.setCharAt(0, Character.toUpperCase(sb.get(0)))
            return sb.toString()
        }
    }

    fun getValueWithCurrencyCode(
        amount: Double,
        currencySymbol: String,
        conversionRate: String
    ): String {
        return if (amount.toString().isEmpty() || amount.toString().isBlank()) {
            currencySymbol + convertToDecimal(amount.toString())
        } else {
            currencySymbol + convertToDecimal(
                (amount.toString().toDouble() * conversionRate.toDouble()).toString()
            )

        }
    }


    fun convertToDecimal(str: String): String {
        return try {
            val symbols = DecimalFormatSymbols(Locale.ENGLISH)
         "" +  DecimalFormat("0.00",symbols).format(str.toDouble())
        } catch (e: Exception) {
            Log.e("FormValidationUtils", "convertToDecimal : ${e.printStackTrace()} ")
            str
        }
    }


    fun getLocationDecimalFormat(): DecimalFormat {

        val decimalFormat = DecimalFormat("#.##", DecimalFormatSymbols(Locale.ENGLISH))

       // decimalFormat.roundingMode = RoundingMode.HALF_UP

        return decimalFormat
    }

    class DecimalDigitsInputFilter(digitsBeforeZero: Int, digitsAfterZero: Int) : InputFilter {

      private  var mPattern: Pattern =
            Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?")

        override fun filter(
            source: CharSequence,
            start: Int,
            end: Int,
            dest: Spanned,
            dstart: Int,
            dend: Int
        ): CharSequence? {

            val matcher = mPattern.matcher(dest)
            return if (!matcher.matches()) "" else null
        }

    }

    class AlphaNumericInputFilter : InputFilter {
        override fun filter(
            source: CharSequence, start: Int, end: Int,
            dest: Spanned, dstart: Int, dend: Int
        ): CharSequence? {

            // Only keep characters that are alphanumeric
            val builder = StringBuilder()
            for (i in start until end) {
                val c = source[i]
                if (Character.isLetterOrDigit(c)) {
                    builder.append(c)
                }
            }

            // If all characters are valid, return null, otherwise only return the filtered characters
            val allCharactersValid = builder.length == end - start
            return if (allCharactersValid) null else builder.toString().toUpperCase()
        }
    }
}