package com.egodelivery.business.fragment

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.ModifierGroupModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FormValidationUtils
import com.cEGrubHolic.business.utils.KeyboardUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.egodelivery.business.viewmodelprovider.ModifierGroupListVM
import kotlinx.android.synthetic.main.fragment_add_and_edit_modifier_item.*
import okhttp3.MultipartBody


class AddAndEditModifierItemFragment : BaseFragment() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(ModifierGroupListVM::class.java)
    }
    var vSymbol = ""
    var dConversionRate= "1"
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_and_edit_modifier_item, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (!userViewModel.addModifierItemListApi.hasActiveObservers()) {
            userViewModel.addModifierItemListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                Activity.RESULT_OK
                                activity!!.finish()
                            },1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {
                            hideProgress()
                        }

                    }

                })
        }
        if (!userViewModel.updateModifierItemListApi.hasActiveObservers()) {
            userViewModel.updateModifierItemListApi.observe(
                activity!!,
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )
                            Handler().postDelayed({
                                Activity.RESULT_OK
                                activity!!.finish()
                            },1500)

                        }
                        ApiResponseStatus.ERROR -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnAddAndUpdateProtin,
                                getString(R.string.no_internet),
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }
                        else -> {
                            hideProgress()
                        }

                    }

                })
        }
        val getDataForCall = arguments!!.getInt(Constants.KEY_BOOKING_ID)

        when(getDataForCall){
            3->{
                val getDataModelCall = arguments!!.getSerializable(Constants.GET__MODIFIER_CETEGORYWISE_LIST_FULL) as ModifierGroupModel
                upDateUI(getDataModelCall)
            }
        }

        costSembols.setText("Cost"+"("+Constants.vCurrentCurrencySymbol+")")


        btnAddAndUpdateProtin.setOnClickListener {


            when(getDataForCall){
                3->{
                    KeyboardUtils.hideKeyboard(activity!!, btnAddAndUpdateProtin)
                    if (isValidForm()){
                        val multipartArray = arrayListOf<MultipartBody.Part>()
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nModifierItemId",
                                arguments!!.getString(Constants.GET_ITEM_ID)!!
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nModifierGroupId",
                                arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!
                            )
                        )

                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vName",
                                edtProtinItemNAmes.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dCost",
                                edtProtineCostBss.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtProtineSequences.text.toString().trim()
                            )
                        )
                        if (swichProtineItemActive.isChecked){
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        }else{
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }


                        userViewModel.upadteModifierItemList(multipartArray)



                    }

                }
                2->{
                    KeyboardUtils.hideKeyboard(activity!!, btnAddAndUpdateProtin)
                    if (isValidForm()){
                        val multipartArray = arrayListOf<MultipartBody.Part>()

                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nModifierGroupId",
                                arguments!!.getString(Constants.GET_MODIFIER_CETEGORYWISE_LIST)!!
                            )
                        )

                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "vName",
                                edtProtinItemNAmes.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "dCost",
                                edtProtineCostBss.text.toString().trim()
                            )
                        )
                        multipartArray.add(
                            MultipartBody.Part.createFormData(
                                "nSequenceNo",
                                edtProtineSequences.text.toString().trim()
                            )
                        )
                        if (swichProtineItemActive.isChecked){
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "1"
                                )
                            )
                        }else{
                            multipartArray.add(
                                MultipartBody.Part.createFormData(
                                    "isActive",
                                    "0"
                                )
                            )
                        }




                        userViewModel.addModifierItemList(multipartArray)

                    }

                }
            }



        }

    }

    private fun upDateUI(modifierItemModel: ModifierGroupModel){
        edtProtinItemNAmes.setText(modifierItemModel.vName)
        edtProtineCostBss.setText(
            FormValidationUtils.getValueWithCurrencyCode(
                modifierItemModel.dCost.toDouble(),
                "" ,
                dConversionRate
            )
        )
        edtProtineSequences.setText(modifierItemModel.nSequenceNo)
        if (modifierItemModel.isActive=="1"){
            swichProtineItemActive.isChecked = true
        }else if (modifierItemModel.isActive=="0"){
            swichProtineItemActive.isChecked = false
        }

        Log.e("===","=== symbol ==="+modifierItemModel.vSymbol)

       /* costSembols.text = String.format(
            getString(R.string.cost_bs),
            modifierItemModel.vSymbol

        )*/

    }




    private fun isValidForm(): Boolean {

        if (!FormValidationUtils.isValidText(edtProtinItemNAmes.text.toString().trim())) {
            edtProtinItemNAmes.requestFocus()
            showSnackbar(
                edtProtinItemNAmes,
                getString(R.string.plase_add_item_title),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        }  else if (!FormValidationUtils.isValidText(edtProtineCostBss.text.toString().trim())) {
            edtProtineCostBss.requestFocus()
            showSnackbar(
                edtProtineCostBss,
                getString(R.string.please_add_item_cost),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else if (!FormValidationUtils.isValidText(edtProtineSequences.text.toString().trim())) {
            edtProtineSequences.requestFocus()
            showSnackbar(
                edtProtineSequences,
                getString(R.string.please_add_suquence_number),
                SnackbarUtils.SnackbarType.WARNING
            )
            return false
        } else

        {
            return true
        }
    }

    
}