package com.cEGrubHolic.business.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.BusinessHourModel
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.cEGrubHolic.business.utils.DateTimeUtils.convertDateFormatWithoutUTC
import com.cEGrubHolic.business.utils.LayoutUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import kotlinx.android.synthetic.main.fragment_business_hours.*
import kotlinx.android.synthetic.main.raw_item_business_hour.view.*
import okhttp3.MultipartBody
import java.text.SimpleDateFormat
import java.util.*


class ManuBusinessHoursFragment : BaseFragment() {

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }
    var vBusinessHourModel = arrayListOf<BusinessHourModel>()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_business_hours, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        userViewModel.getBusinessHours()

        if (!userViewModel.updateBusinessHourssApi.hasActiveObservers()) {
            userViewModel.updateBusinessHourssApi.observe(
                requireActivity(),
                androidx.lifecycle.Observer {

                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            showProgress(getString(R.string.loding), false)
                        }

                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            getBusinessHoursList(
                                Gson().fromJson(
                                    it.data,
                                    object : TypeToken<List<BusinessHourModel>>() {}.type
                                )
                            )




                            showSnackbar(
                                btnSubmit,
                                it.message,
                                SnackbarUtils.SnackbarType.SUCCESS
                            )

                        }

                        ApiResponseStatus.ERROR -> {
                            hideProgress()

                            //  showDetailView(false, it.message)
                            showSnackbar(
                                btnSubmit,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )

                        }

                        ApiResponseStatus.SESSION_EXPIRED -> {
                            hideProgress()
                            destroyLoginSession()
                        }

                        ApiResponseStatus.NO_INTERNET -> {
                            hideProgress()
                            showSnackbar(
                                btnSubmit,
                                it.message,
                                SnackbarUtils.SnackbarType.ERROR
                            )
                            //    showDetailView(false,  getString(R.string.noInternetConnection))

                        }
                    }
                })
        }

        if (!userViewModel.getBusinessHoursApi.hasActiveObservers()) {
            userViewModel.getBusinessHoursApi.observe(
                viewLifecycleOwner,
                androidx.lifecycle.Observer {


                    when (it?.status) {

                        ApiResponseStatus.LOADING -> {
                            businessHoursUpdate.isRefreshing = true

                        }
                        ApiResponseStatus.SUCCESS -> {
                            hideProgress()
                            businessHoursUpdate.isRefreshing = false


                            getBusinessHoursList(
                                Gson().fromJson(
                                    it.data,
                                    object : TypeToken<List<BusinessHourModel>>() {}.type
                                )
                            )


                            //      getBusinessHoursList(businsessDayList[0])


                        }
                        ApiResponseStatus.ERROR -> {
                            businessHoursUpdate.isRefreshing = false
                            hideProgress()
                        }
                        ApiResponseStatus.SESSION_EXPIRED -> {
                            businessHoursUpdate.isRefreshing = false

                            destroyLoginSession()
                        }
                        ApiResponseStatus.NO_INTERNET -> {
                            businessHoursUpdate.isRefreshing = false
                            hideProgress()


                        }
                        else -> {
                            hideProgress()
                            businessHoursUpdate.isRefreshing = false
                        }

                    }

                })
        }


        businessHoursUpdate.setOnRefreshListener {

            userViewModel.getBusinessHours()
        }


    }



    fun getBusinessHoursList(vBusinessHourModelList: ArrayList<BusinessHourModel>) {


        daysContainer.removeAllViews()

        for ((index, vBusinessHourModel) in vBusinessHourModelList.withIndex()) {


            // switch  for index > 0...6 > 0 Sunday,1M, 2T .


                var day = when (index) {
                    0 -> {
                        getString(R.string.sunday)
                    }
                    1 -> {
                        getString(R.string.monday)
                    }
                    2 -> {
                        getString(R.string.tuesday)
                    }
                    3 -> {
                        getString(R.string.wednesday)
                    }
                    4 -> {
                        getString(R.string.thursday)
                    }
                    5 -> {
                        getString(R.string.friday)
                    }
                    6 -> {
                        getString(R.string.saturday)
                    }

                    else -> {
                        "-"
                    }


                }

                val dayView =
                    LayoutInflater.from(requireContext()).inflate(R.layout.raw_item_business_hour, null)

                dayView.txtDays.text = day
                if (vBusinessHourModel.isOpen == "1") {
                    dayView.checkboxBusinessHour.isChecked = true
                } else if (vBusinessHourModel.isOpen == "0") {
                    dayView.checkboxBusinessHour.isChecked = false
                }


                //       dayView.checkboxBusinessHour.isChecked = vBusinessHourModel.isOpen == "0"
                if (vBusinessHourModel.isOpen == "1") {
                    dayView.tvMondayMorningStartTime.text = vBusinessHourModel.nMorningStartHours
                    dayView.tvMondayMorningEndTime.text = vBusinessHourModel.nMorningCloseHours
                    dayView.tvMondayEvningStartTime.text = vBusinessHourModel.nEveningStartHours
                    dayView.tvMondayEveningEndTime.text = vBusinessHourModel.nEveningCloseHours
                } else {
                    /* dayModel.nMorningStartHours = "12:00 am"
                     dayModel.nMorningCloseHours = "12:00 am"
                     dayModel.nEveningStartHours = "12:00 am"
                     dayModel.nEveningCloseHours = "12:00 am"*/

                    dayView.tvMondayMorningStartTime.text = vBusinessHourModel.nMorningStartHours
                    dayView.tvMondayMorningEndTime.text = vBusinessHourModel.nMorningCloseHours
                    dayView.tvMondayEvningStartTime.text = vBusinessHourModel.nEveningStartHours
                    dayView.tvMondayEveningEndTime.text = vBusinessHourModel.nEveningCloseHours

                }


                dayView.checkboxBusinessHour.setOnCheckedChangeListener { buttonView, isChecked ->
                    vBusinessHourModel.isOpen = if (isChecked) {
                        "1"
                    } else {
                        "0"
                    }

                    if (!isChecked) {
                        dayView.tvMondayMorningStartTime.isSelected = false
                        dayView.tvMondayMorningEndTime.isSelected = false
                        dayView.tvMondayEvningStartTime.isSelected = false
                        dayView.tvMondayEveningEndTime.isSelected = false

                        /* dayModel.nMorningStartHours = "12:00 am"
                         dayModel.nMorningCloseHours = "12:00 am"
                         dayModel.nEveningStartHours = "12:00 am"
                         dayModel.nEveningCloseHours = "12:00 am"

                         dayView.tvMondayMorningStartTime.text = dayModel.nMorningStartHours
                         dayView.tvMondayMorningEndTime.text = dayModel.nMorningCloseHours
                         dayView.tvMondayEvningStartTime.text = dayModel.nEveningStartHours
                         dayView.tvMondayEveningEndTime.text = dayModel.nEveningCloseHours*/

                    } else {
                        dayView.tvMondayMorningStartTime.text = vBusinessHourModel.nMorningStartHours
                        dayView.tvMondayMorningEndTime.text = vBusinessHourModel.nMorningCloseHours
                        dayView.tvMondayEvningStartTime.text = vBusinessHourModel.nEveningStartHours
                        dayView.tvMondayEveningEndTime.text = vBusinessHourModel.nEveningCloseHours
                    }
                }


                dayView.tvMondayMorningStartTime.setOnClickListener {



                    dayView.tvMondayMorningStartTime.isSelected = true

                    LayoutUtils.unselectViewGroup(daysContainer)

                    val mCurrentTime = Calendar.getInstance()
                    val hour = mCurrentTime.get(Calendar.HOUR_OF_DAY)
                    val minuts = mCurrentTime.get(Calendar.MINUTE)
                    val dialog =
                        com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->


                            if (vBusinessHourModel.nMorningCloseHours.equals("12:00 am", true)) {
                                dayView.tvMondayMorningStartTime.text =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                vBusinessHourModel.nMorningStartHours =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )
                            } else {


                                val closeTimeInModelClass = vBusinessHourModel.nMorningCloseHours
                                val hourFromPicker = hourOfDay
                                val minFromPicker = minute
                                val openTimeFromPicker = "$hourFromPicker:$minFromPicker"

                                val closeTime =
                                    SimpleDateFormat(
                                        "hh:mm a",
                                        Locale.ENGLISH
                                    ).parse(closeTimeInModelClass)!!

                                val openTime =
                                    SimpleDateFormat(
                                        "HH:mm",
                                        Locale.ENGLISH
                                    ).parse(openTimeFromPicker)!!

                                dayView.tvMondayMorningStartTime.text =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                vBusinessHourModel.nMorningStartHours =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                /*   if (openTime.after(closeTime)) {
                                       showSnackbar(
                                           btnSubmit,
                                           getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                           SnackbarUtils.SnackbarType.ERROR
                                       )
                                   } else {
                                       dayView.tvMondayMorningStartTime.text =
                                           convertDateFormatWithoutUTC(
                                               "$hourOfDay:$minute",
                                               "HH:mm",
                                               "hh:mm a"
                                           ).toLowerCase(
                                               Locale.ROOT
                                           )

                                       vBusinessHourModel.nMorningStartHours =
                                           convertDateFormatWithoutUTC(
                                               "$hourOfDay:$minute",
                                               "HH:mm",
                                               "hh:mm a"
                                           ).toLowerCase(
                                               Locale.ROOT
                                           )
                                   }*/
                            }


                        }, hour, minuts, false)
                    /*dialog.accentColor = ContextCompat.getColor(context!!, R.color.black)
                    dialog.setOkColor(ContextCompat.getColor(context!!, R.color.background))
                    dialog.setCancelColor(ContextCompat.getColor(context!!, R.color.background))
                    dialog.isThemeDark = false*/
                    //  dialog.enableMinutes(false)
                    dialog.show(childFragmentManager, "")


                }



                dayView.tvMondayMorningEndTime.setOnClickListener {

                    if (dayView.tvMondayMorningStartTime.text.toString().trim().isEmpty()) {
                        showSnackbar(
                            btnSubmit,
                            getString(R.string.selectOpenTime),
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    } else {




                        dayView.tvMondayMorningEndTime.isSelected = true
                        LayoutUtils.unselectViewGroup(daysContainer)

                        val mCurrentTime = Calendar.getInstance()
                        val hour = mCurrentTime.get(Calendar.HOUR_OF_DAY)
                        val minuts = mCurrentTime.get(Calendar.MINUTE)
                        val dialog =
                            com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->
                                val timeInModelClass = vBusinessHourModel.nMorningStartHours
                                val hourFromPicker = hourOfDay
                                val minFromPicker = minute

                                val timeFromPicker = "$hourFromPicker:$minFromPicker"

                                val dayModel_nMorningStartHours_DateObject =
                                    SimpleDateFormat(
                                        "hh:mm a",
                                        Locale.ENGLISH
                                    ).parse(timeInModelClass)!!

                                val timeFromPickerDateObject =
                                    SimpleDateFormat(
                                        "HH:mm",
                                        Locale.ENGLISH
                                    ).parse(timeFromPicker)!!

                                if (dayModel_nMorningStartHours_DateObject.after(
                                        timeFromPickerDateObject
                                    )
                                ) {
                                    showSnackbar(
                                        btnSubmit,
                                        getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                        SnackbarUtils.SnackbarType.ERROR
                                    )
                                }else if (dayModel_nMorningStartHours_DateObject  == timeFromPickerDateObject){
                                    showSnackbar(
                                        btnSubmit,
                                        getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                        SnackbarUtils.SnackbarType.ERROR
                                    )
                                } else {
                                    dayView.tvMondayMorningEndTime.text =
                                        convertDateFormatWithoutUTC(
                                            "$hourOfDay:$minute",
                                            "HH:mm",
                                            "hh:mm a"
                                        ).toLowerCase(Locale.ROOT)



                                    vBusinessHourModel.nMorningCloseHours =
                                        convertDateFormatWithoutUTC(
                                            "$hourOfDay:$minute",
                                            "HH:mm",
                                            "hh:mm a"
                                        ).toLowerCase(
                                            Locale.ROOT
                                        )
                                }
                            }, hour, minuts, false)
                        /*dialog.accentColor = ContextCompat.getColor(context!!, R.color.black)
                        dialog.setOkColor(ContextCompat.getColor(context!!, R.color.background))
                        dialog.setCancelColor(ContextCompat.getColor(context!!, R.color.background))*/

                        //  dialog.enableMinutes(false)

                        dialog.show(childFragmentManager, "")
                        // dialog.isThemeDark = false
                    }
                }
                dayView.tvMondayEvningStartTime.setOnClickListener {

                    dayView.tvMondayEvningStartTime.isSelected = true

                    LayoutUtils.unselectViewGroup(daysContainer)

                    val mCurrentTime = Calendar.getInstance()
                    val hour = mCurrentTime.get(Calendar.HOUR_OF_DAY)
                    val minuts = mCurrentTime.get(Calendar.MINUTE)
                    val dialog =
                        com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->

                            if (vBusinessHourModel.nEveningCloseHours.equals("12:00 am", true)) {
                                dayView.tvMondayEvningStartTime.text =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm", "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                vBusinessHourModel.nEveningStartHours =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )
                            } else {


                                val closeTimeInModelClass = vBusinessHourModel.nEveningCloseHours
                                val hourFromPicker = hourOfDay
                                val minFromPicker = minute
                                val openTimeFromPicker = "$hourFromPicker:$minFromPicker"

                                val closeTime =
                                    SimpleDateFormat(
                                        "hh:mm a",
                                        Locale.ENGLISH
                                    ).parse(closeTimeInModelClass)!!

                                val openTime =
                                    SimpleDateFormat(
                                        "HH:mm",
                                        Locale.ENGLISH
                                    ).parse(openTimeFromPicker)!!


                                dayView.tvMondayEvningStartTime.text =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm", "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                vBusinessHourModel.nEveningStartHours =
                                    convertDateFormatWithoutUTC(
                                        "$hourOfDay:$minute",
                                        "HH:mm",
                                        "hh:mm a"
                                    ).toLowerCase(
                                        Locale.ROOT
                                    )

                                /* if (openTime.after(closeTime)) {
                                     showSnackbar(
                                         btnSubmit,
                                         getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                         SnackbarUtils.SnackbarType.ERROR
                                     )
                                 } else {
                                     dayView.tvMondayEvningStartTime.text =
                                         convertDateFormatWithoutUTC(
                                             "$hourOfDay:$minute",
                                             "HH:mm", "hh:mm a"
                                         ).toLowerCase(
                                             Locale.ROOT
                                         )

                                     vBusinessHourModel.nEveningStartHours =
                                         convertDateFormatWithoutUTC(
                                             "$hourOfDay:$minute",
                                             "HH:mm",
                                             "hh:mm a"
                                         ).toLowerCase(
                                             Locale.ROOT
                                         )

                                 }*/
                            }

                        }, hour, minuts, false)
                    /*dialog.accentColor = ContextCompat.getColor(context!!, R.color.black)
                    dialog.setOkColor(ContextCompat.getColor(context!!, R.color.background))
                    dialog.setCancelColor(ContextCompat.getColor(context!!, R.color.background))
                    dialog.isThemeDark = false*/
                    //      dialog.enableMinutes(false)
                    dialog.show(childFragmentManager, "")


                }
                dayView.tvMondayEveningEndTime.setOnClickListener {

                    if (dayView.tvMondayEvningStartTime.text.toString().trim().isEmpty()) {
                        showSnackbar(
                            btnSubmit,
                            getString(R.string.selectOpenTime),
                            SnackbarUtils.SnackbarType.ERROR
                        )
                    }  else {



                        dayView.tvMondayEveningEndTime.isSelected = true

                        LayoutUtils.unselectViewGroup(daysContainer)

                        val mCurrentTime = Calendar.getInstance()
                        val hour = mCurrentTime.get(Calendar.HOUR_OF_DAY)
                        val minuts = mCurrentTime.get(Calendar.MINUTE)
                        val dialog =
                            com.wdullaer.materialdatetimepicker.time.TimePickerDialog.newInstance({ view, hourOfDay, minute, second ->

                                val timeInModelClass = vBusinessHourModel.nEveningStartHours
                                val hourFromPicker = hourOfDay
                                val minFromPicker = minute
                                val timeFromPicker = "$hourFromPicker:$minFromPicker"

                                val dayModel_nMorningStartHours_DateObject =
                                    SimpleDateFormat(
                                        "hh:mm a",
                                        Locale.ENGLISH
                                    ).parse(timeInModelClass)!!
                                val timeFromPickerDateObject =
                                    SimpleDateFormat(
                                        "HH:mm",
                                        Locale.ENGLISH
                                    ).parse(timeFromPicker)!!

                                if (dayModel_nMorningStartHours_DateObject.after(
                                        timeFromPickerDateObject
                                    )
                                ) {
                                    showSnackbar(
                                        btnSubmit,
                                        getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                        SnackbarUtils.SnackbarType.ERROR
                                    )

                                } else if (dayModel_nMorningStartHours_DateObject ==timeFromPickerDateObject ){
                                    showSnackbar(
                                        btnSubmit,
                                        getString(R.string.closeTimeShouldGreaterThanOpenTime),
                                        SnackbarUtils.SnackbarType.ERROR
                                    )
                                } else {

                                    dayView.tvMondayEveningEndTime.text =
                                        convertDateFormatWithoutUTC(
                                            "$hourOfDay:$minute",
                                            "HH:mm",
                                            "hh:mm a"
                                        ).toLowerCase(
                                            Locale.ROOT
                                        )

                                    vBusinessHourModel.nEveningCloseHours =
                                        convertDateFormatWithoutUTC(
                                            "$hourOfDay:$minute",
                                            "HH:mm",
                                            "hh:mm a"
                                        ).toLowerCase(
                                            Locale.ROOT
                                        )

                                }
                            }, hour, minuts, false)
                        /*dialog.accentColor = ContextCompat.getColor(context!!, R.color.black)
                        dialog.setOkColor(ContextCompat.getColor(context!!, R.color.background))
                        dialog.setCancelColor(ContextCompat.getColor(context!!, R.color.background))*/

                        //     dialog.enableMinutes(false)

                        dialog.show(childFragmentManager, "")
                        // dialog.isThemeDark = false
                    }
                }

                daysContainer.addView(dayView)

        }



        btnSubmit.setOnClickListener {


            val multipartArray = arrayListOf<MultipartBody.Part>()

            for ((index, day) in vBusinessHourModelList.withIndex()) {

                multipartArray.add(
                    MultipartBody.Part.createFormData(
                        "vBusinessHours[$index]",
                        "${day.dayNumber}," +
                                "${day.nMorningStartHours}," +
                                "${day.nMorningCloseHours}," +
                                "${day.nEveningStartHours}," +
                                "${day.nEveningCloseHours}," +
                                day.isOpen
                    )
                )

                userViewModel.updateBusinessHours(multipartArray)


            }
        }

    }
}
