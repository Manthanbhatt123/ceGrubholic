package com.cEGrubHolic.business

import android.content.Intent
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils
import com.cEGrubHolic.business.utils.ProgressDialogWithCustomLoader
import com.cEGrubHolic.business.utils.SnackbarUtils
import com.egodelivery.business.LogInActivity

open class BaseFragment : Fragment() {

    fun showShortToast(msg: String) {
        Toast.makeText(context!!, msg, Toast.LENGTH_SHORT).show()
    }

    fun showLongToast(msg: String) {
        Toast.makeText(context!!, msg, Toast.LENGTH_LONG).show()
    }

    fun destroyLoginSession(isMessageRequired: Boolean = true) {
        hideProgress()

        if (isMessageRequired)
            MyAppPreferenceUtils.clearLoginSession(activity!!)
        activity!!.finish()
        val intent = Intent(activity, LogInActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)

    }

    fun showSnackbar(view: View, msg: String, type: SnackbarUtils.SnackbarType) {
        when (type) {

            SnackbarUtils.SnackbarType.SUCCESS -> {
                SnackbarUtils.success(activity!! as AppCompatActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.WARNING -> {
                SnackbarUtils.warning(activity!! as AppCompatActivity, view, msg)
            }
            SnackbarUtils.SnackbarType.ERROR -> {
                SnackbarUtils.error(activity!! as AppCompatActivity, view, msg)
            }
        }
    }

    fun showProgress(msg: String, cancelable: Boolean) {
        ProgressDialogWithCustomLoader.showProgressDialog(context!!, "", msg, cancelable)
    }

    fun hideProgress() {
        ProgressDialogWithCustomLoader.dismissProgressDialog()
    }


}
