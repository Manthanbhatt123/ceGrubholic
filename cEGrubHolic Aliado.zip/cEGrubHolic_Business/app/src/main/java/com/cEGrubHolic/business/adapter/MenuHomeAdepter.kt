package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R

import com.cEGrubHolic.business.models.SideNavModelClass
import kotlinx.android.synthetic.main.raw_side_menu_item.view.*


class MenuHomeAdepter(val dataList: ArrayList<SideNavModelClass>,
                      val itemClickListener: ItemClickListener
)  : RecyclerView.Adapter<MenuHomeAdepter.MyViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_side_menu_item,
                null
            )
        )
    }

    override fun getItemCount(): Int {
        return   dataList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        holder.itemView.tvMenuTitle.text = holder.itemView.context.getString(dataList[position].vMenuTitle)
    }


    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener{
                itemClickListener.onItemClicked(dataList[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: SideNavModelClass
        )
    }
}