package com.egodelivery.business.utils

import android.content.Context
import android.net.*
import android.util.Log

object ConnectionUtil {
    fun isDataConnectionAvailable(context: Context): Boolean {
        try {
            val conMgr =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            return conMgr.activeNetworkInfo != null && conMgr.activeNetworkInfo!!.isAvailable && conMgr.activeNetworkInfo!!.isConnected
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    /*fun isGooglePlayServicesAvailable(activity: Activity): Boolean {
        val googleApiAvailability = GoogleApiAvailability.getInstance()
        val status = googleApiAvailability.isGooglePlayServicesAvailable(activity)
        if (status != ConnectionResult.SUCCESS) {
            if (googleApiAvailability.isUserResolvableError(status)) {
                googleApiAvailability.getErrorDialog(activity, status, 2404).show()
            }
            return false
        }
        return true
    }*/

    var connectivityManager: ConnectivityManager? = null
    var mMyListener: MyListener? = null

    private val networkCallback: ConnectivityManager.NetworkCallback =
        object : ConnectivityManager.NetworkCallback() {

            override fun onAvailable(network: Network) {
                super.onAvailable(network!!)

                Log.d("NetworkSchedulerService", "onAvailable: ${network.toString()}")

                val activeNetwork = connectivityManager?.activeNetworkInfo
                if (activeNetwork == null) {
                    Log.i("NetworkSchedulerService", "No active network.")
                } else {

                    Log.i("NetworkSchedulerService", activeNetwork.detailedState.toString())
                    mMyListener?.onConnected(activeNetwork.subtypeName)
                }
            }

            override fun onLost(network: Network) {
                super.onLost(network!!)
                mMyListener?.onDisconnected()
                Log.e("NetworkSchedulerService", "onLost:${network.toString()} ")
            }

            override fun onLosing(network: Network, maxMsToLive: Int) {
                super.onLosing(network!!, maxMsToLive)
                Log.e("NetworkSchedulerService", "onLosing: ${network.toString()}")
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                super.onCapabilitiesChanged(network!!, networkCapabilities!!)
                Log.i(
                    "NetworkSchedulerService", "onCapabilitiesChanged: " +
                            "${network.toString()}  ${networkCapabilities}"
                )

            }

            override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                super.onLinkPropertiesChanged(network!!, linkProperties!!)
                Log.i(
                    "NetworkSchedulerService", "onLinkPropertiesChanged: ${network.toString()}" +
                            "${linkProperties?.interfaceName}"
                )
            }


        }


    fun stopNetworkConnectionChecking() {
        mMyListener = null
        connectivityManager?.unregisterNetworkCallback(networkCallback)
    }

    fun startNetworkConnectionChecking(context: Context, mMyListener: MyListener) {
        ConnectionUtil.mMyListener = null
        ConnectionUtil.mMyListener = mMyListener
        connectivityManager?.unregisterNetworkCallback(networkCallback)
        connectivityManager =
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        connectivityManager?.registerNetworkCallback(
            NetworkRequest.Builder().build(),
            networkCallback
        )

    }


    interface MyListener {
        fun onConnected(subtypeName: String)
        fun onDisconnected()
    }
}