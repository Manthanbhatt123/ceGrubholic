package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.CategoryListModel

import kotlinx.android.synthetic.main.raw_manage_manus.view.*


import java.util.ArrayList

class ManageManusListAdepter(val couponCategoriesModel: ArrayList<CategoryListModel>, val itemClickListener: ItemClickListener): RecyclerView.Adapter<ManageManusListAdepter.MyViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.raw_manage_manus,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return couponCategoriesModel.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.tvCategoryNames.text = couponCategoriesModel[position].vName

    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(couponCategoriesModel[layoutPosition])
            }
            itemView.imageEditMenu.setOnClickListener {
                itemClickListener.onEditCategory(couponCategoriesModel[layoutPosition])
            }
            itemView.ImageDeleteMenu.setOnClickListener {
                itemClickListener.onDeletCategory(couponCategoriesModel[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: CategoryListModel

        )
        fun onEditCategory(
            menuPos: CategoryListModel
        )
        fun onDeletCategory(
            menuPos: CategoryListModel
        )
    }
}