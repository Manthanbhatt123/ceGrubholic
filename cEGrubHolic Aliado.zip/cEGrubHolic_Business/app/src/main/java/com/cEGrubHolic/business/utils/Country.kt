package com.example.godeliverybusinessapp.utils

data class  Country(val s: String,val s1: String,val dialCode: String,val flagSl: Int ) {
    override fun toString(): String {
        return dialCode
    }
}
