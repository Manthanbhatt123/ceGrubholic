package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class CategoryListModel(
        @SerializedName("id")
        val id: String = "",
        @SerializedName("vName")
        val vName: String = "",
        @SerializedName("nSequenceNo")
        val nSequenceNo: String = "",
        @SerializedName("isActive")
        val isActive: String = ""
): Serializable