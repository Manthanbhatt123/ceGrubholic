package com.egodelivery.business.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import okhttp3.MultipartBody
import java.util.ArrayList

class PromocodeVM:ViewModel() {
    val getPromocodeListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getPromocodeList() {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.getPromocodeList()

        getPromocodeListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getPromocodeListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getPromocodeListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getPromocodeListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getPromocodeListApi.postValue(ApiResponse().noInternet())
                }
            })
    }


    val addPromocodeListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addPromocodeList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.addPromocode(fields)
        addPromocodeListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addPromocodeListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addPromocodeListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addPromocodeListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addPromocodeListApi.postValue(ApiResponse().noInternet())
                }
            })
    }


    val upDatePromocodeListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun upDatePromocodeList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.editPromocode(fields)
        upDatePromocodeListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    upDatePromocodeListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    upDatePromocodeListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    upDatePromocodeListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    upDatePromocodeListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val removePromocodeListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removePromocodeList (vPromocodeId: String) {

        val apiCall =
            WebServiceRetrofitUtil.webService!!.deletePromocode(vPromocodeId)
        removePromocodeListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removePromocodeListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removePromocodeListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removePromocodeListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removePromocodeListApi.postValue(ApiResponse().noInternet())
                }
            })
    }


}