package com.egodelivery.business.viewmodelprovider

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.ApiResponse
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import com.cEGrubHolic.business.network.WebServiceRetrofitUtil
import okhttp3.MultipartBody
import java.util.ArrayList

class ModifierGroupListVM: ViewModel()  {

    val getModifierGroupListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getModifierGroupList() {

        val apiCall = WebServiceRetrofitUtil.webService!!.getModiFierGroupList()

        getModifierGroupListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getModifierGroupListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getModifierGroupListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getModifierGroupListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getModifierGroupListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val addModifierGroupListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addModifierGroupList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.addModifierGroup(fields)
        addModifierGroupListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addModifierGroupListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addModifierGroupListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addModifierGroupListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addModifierGroupListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val upDateModifierGroupListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun upDateModifierGroupList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.upDateModifierGroup(fields)
        upDateModifierGroupListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    upDateModifierGroupListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    upDateModifierGroupListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    upDateModifierGroupListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    upDateModifierGroupListApi.postValue(ApiResponse().noInternet())
                }
            })
    }
    val removeModifierGroupListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeModifierGroupList (nModifierGroupId: String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.removeModifierGroup(nModifierGroupId)
        removeModifierGroupListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeModifierGroupListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeModifierGroupListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeModifierGroupListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeModifierGroupListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val getModifierItemListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun getModifierItemList (nModifierGroupId: String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.getModifierItemList(nModifierGroupId)
        getModifierItemListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    getModifierItemListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    getModifierItemListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    getModifierItemListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    getModifierItemListApi.postValue(ApiResponse().noInternet())
                }
            })
    }


    val addModifierItemListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun addModifierItemList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.addModifierItem(fields)
        addModifierItemListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    addModifierItemListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    addModifierItemListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    addModifierItemListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    addModifierItemListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val updateModifierItemListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun upadteModifierItemList (fields: ArrayList<MultipartBody.Part>) {

        val apiCall = WebServiceRetrofitUtil.webService!!.updateModifierItem(fields)
        updateModifierItemListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    updateModifierItemListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    updateModifierItemListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    updateModifierItemListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    updateModifierItemListApi.postValue(ApiResponse().noInternet())
                }
            })
    }

    val removeModifierItemListApi: MutableLiveData<ApiResponse> = MutableLiveData()

    fun removeModifierItemList (nModifierItemId: String) {

        val apiCall = WebServiceRetrofitUtil.webService!!.removeModifierItem(nModifierItemId)
        removeModifierItemListApi.postValue(ApiResponse().loading())

        WebServiceResponseHandler.handleApiResponse(
            apiCall,
            object : WebServiceResponseHandler.DataHandler {
                override fun sessionExpired() {
                    removeModifierItemListApi.postValue(ApiResponse().sessionExpired())
                }

                override fun onSuccess(data: JsonElement, message: String) {
                    removeModifierItemListApi.postValue(ApiResponse().success(data, message))
                }

                override fun onFailure(message: String) {
                    removeModifierItemListApi.postValue(ApiResponse().error(message))
                }

                override fun noInternetConnection() {
                    removeModifierItemListApi.postValue(ApiResponse().noInternet())
                }
            })
    }


}