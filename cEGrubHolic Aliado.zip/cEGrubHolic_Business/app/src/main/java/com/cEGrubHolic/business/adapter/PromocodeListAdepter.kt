package com.cEGrubHolic.business.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.egodelivery.business.R
import com.cEGrubHolic.business.models.PromocodeModel
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.DateTimeUtils
import com.cEGrubHolic.business.utils.FormValidationUtils

import kotlinx.android.synthetic.main.row_promocode_list.view.*
import java.util.ArrayList

class PromocodeListAdepter(val couponCategoriesModel: ArrayList<PromocodeModel>,
                           val itemClickListener: ItemClickListener
): RecyclerView.Adapter<PromocodeListAdepter.MyViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        return MyViewHolder(
            LayoutInflater.from(parent.context).inflate(
                R.layout.row_promocode_list,
                null
            )
        )

    }

    override fun getItemCount(): Int {
        return couponCategoriesModel.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.itemView.txtPromocodeName.text = couponCategoriesModel[position].vPromoCode
        holder.itemView.txtPromocodeStartDate.text =  DateTimeUtils.convertDateFormat(
            couponCategoriesModel[position].dStartDate     ,
            "yyyy-MM-dd HH:mm:ss","dd MMM,yyyy hh:mm a"
        )
        holder.itemView.txtPromocodeEndDate.text =  DateTimeUtils.convertDateFormat(
            couponCategoriesModel[position].dEndDate    ,
            "yyyy-MM-dd HH:mm:ss","dd MMM,yyyy hh:mm a"
        )

        if ( couponCategoriesModel[position].nType == "1"){
            holder.itemView.tvOffPrcanteg.text = couponCategoriesModel[position].dValue+"% Off"
               /* FormValidationUtils.getValueWithCurrencyCode(
                    couponCategoriesModel[position].dValue.toDouble(),
                    ""  ,
                    couponCategoriesModel[position].dConversionRate
                )*/
        }else if (couponCategoriesModel[position].nType == "2"){
            holder.itemView.tvOffPrcanteg.text =  FormValidationUtils.getValueWithCurrencyCode(
                couponCategoriesModel[position].dValue.toDouble(),
                Constants.vCurrentCurrencySymbol,
              "1"
            )+"\nOff"
        }


    //    holder.itemView.txtIsExpierd.text = couponCategoriesModel[position].mExpier

      /*  if (couponCategoriesModel[position].mExpier =="1"){
            holder.itemView.txtIsExpierd.visibility = View.VISIBLE
            holder.itemView.txtIsExpierd.setText(R.string.expired)
        }
*/

    }

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        init {
            itemView.setOnClickListener {
                itemClickListener.onItemClicked(couponCategoriesModel[layoutPosition])
            }
            itemView.imageEditPromocode.setOnClickListener {
                itemClickListener.editPromocode(couponCategoriesModel[layoutPosition])
            }
            itemView.imageDeletePromocode.setOnClickListener {
                itemClickListener.deletePromocode(couponCategoriesModel[layoutPosition])
            }
        }
    }

    interface ItemClickListener {
        fun onItemClicked(
            menuPos: PromocodeModel
        )
        fun editPromocode(
            vEditPromocode: PromocodeModel
        )
    fun deletePromocode(
        vDeletePromocode: PromocodeModel
    )
    }
}