package com.cEGrubHolic.business.network

import android.content.Context
import com.egodelivery.business.R
import com.egodelivery.business.network.WebServices
import com.egodelivery.business.utils.ConnectionUtil


import com.google.gson.GsonBuilder

import com.egodelivery.business.utils.Constants.NO_INTERNET
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils.getAppLanguage
import com.example.godeliverybusinessapp.utils.MyAppPreferenceUtils.getToken

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.IOException
import java.util.concurrent.TimeUnit


object WebServiceRetrofitUtil {

    var webService: WebServices? = null

    const val HEADER_vAuthToken = "vAuthToken"
    const val HEADER_languageCode = "Ln"

    fun init(context: Context) {
        val gson = GsonBuilder()
            .setLenient()
            .disableHtmlEscaping()
            .create()

        val vAuthToken = getToken(context)
        val languageCode = getAppLanguage(context)
        val httpLoggingInterceptor = HttpLoggingInterceptor()
        httpLoggingInterceptor.level = HttpLoggingInterceptor.Level.BODY

        val internetAccessInterceptor = Interceptor { chain ->
            //this will check internet connection availability every time request made by user
            if (ConnectionUtil.isDataConnectionAvailable(context)) {
                return@Interceptor chain.proceed(chain.request())
            } else {
                throw IOException(NO_INTERNET)
            }
        }

        val headerInterceptor = Interceptor { chain ->
            //this will add required headers to APIs
            return@Interceptor chain.proceed(
                chain.request().newBuilder()
                    .addHeader(HEADER_vAuthToken, vAuthToken)
                    .addHeader(HEADER_languageCode, languageCode)
                    .build()
            )
        }
        val okHttpClient =
            OkHttpClient.Builder()
                .addInterceptor(headerInterceptor)
                .addInterceptor(internetAccessInterceptor)
                .addInterceptor(httpLoggingInterceptor)
                .connectTimeout(5, TimeUnit.MINUTES)
                .readTimeout(5, TimeUnit.MINUTES)
                .build()


        val retrofit = Retrofit.Builder()
            .baseUrl(context.getString(R.string.BaseURL))
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        webService = retrofit.create(WebServices::class.java)


    }

    fun destroyInstance() {
        if (webService != null)
            webService = null
    }
}




