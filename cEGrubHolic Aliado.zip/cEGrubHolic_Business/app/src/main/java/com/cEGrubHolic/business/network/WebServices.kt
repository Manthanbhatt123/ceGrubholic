package com.egodelivery.business.network

import com.google.gson.JsonElement
import com.cEGrubHolic.business.network.WebServiceResponseHandler
import okhttp3.MultipartBody
import retrofit2.Call
import retrofit2.http.*

/**
 * Created by Ashish on 7/3/19.
 */
interface WebServices {

    companion object {

        const val Driver = "Business/"

        const val AUTH_SIGN_UP = Driver + "signup"
        const val AUTH_SOCIAL_LOGIN = Driver + "sociallogin"
        const val GENERAL_ABOUT_US = Driver + "getAboutUs"

        const val GENERAL_GET_NOTIFICATIONS = Driver + "getNotificationList"
        const val GET_UPDATE_Driver_DATA = Driver + "updateDriverData"
        const val GET_FAV_BRAND_LIST = Driver + "getBrandList"


        const val CONTACT_US = Driver + "addContactus"
        const val GET_ORDER_REQUEST_DETILES_LIST = Driver + "getOrderRequestlist"
        const val CHANGE_ORDER_REQUEST_STATUS = Driver + "changeOrderRequestStatus"
        const val DRIVER_UPDATE_LAT_LNG =  Driver + "updateLatLng"
        const val CHANGE_ORDER_STATUS = Driver + "changeOrderStatus"
        const val GET_ORDER_HESTORY_DETILES_LIST = Driver + "getOrderHistorylist"



        //PickApp Restaurant











        const val MANEGE_BUSINESS_PROFILE = Driver + "updateBusinessProfile"
        const val GET_BUSINESS_PROFILE = Driver + "getBusinessProfile"
        const val ADD_UDER_ROAL = Driver + "addUser"
        const val UPDATE_USER_ROAL = Driver + "updateUser"
        const val GET_USER_ROAL_LIST = Driver + "getUserlist"
        const val REMOVE_USER = Driver + "removeUser"
        const val ADD_DISCOUN_COUPON = Driver + "addCoupon"
        const val UPDATE_DISCOUNT_COUPON = Driver + "updateCoupon"
        const val GET_DISCOUNT_COUPON_LIST = Driver + "getCouponList"
        const val GET_DISCOUNT_COUPON_DETAILS = Driver + "getCouponDetails"
        const val REMOVE_COUPON = Driver + "removeCoupon"
        const val GENERAL_GET_TERMS = Driver + "getTerms"
        const val GENERAL_GET_PRIVACY_POLICY = Driver + "getPrivacypolicy"
        const val GET_REVIEW_LIST = Driver + "getReviewlist"
        const val GET_EARNING_DATA = Driver + "getEarningsDetails"
        const val GET_APP_LOANGUGE= Driver + "changeAppLanguage"
        const val GENERAL_GET_RESTAURANT_DETAIL = Driver + "getRestaurantDetails"
        const val GENERAL_GET_FOOD_DETAILS = Driver + "getFoodDetails"



        // Go Delivery

        const val AUTH_LOGIN = Driver + "login"
        const val AUTH_FORGOT_PASSWORD = Driver + "forgotPassword"
        const val AUTH_LOG_OUT = Driver + "logout"
        const val AUTH_CHANGE_PASSWORD = Driver + "changePassword"
        const val GET_INTIAL_DATA = Driver + "getInitialData"
        const val GET_HISTORY_LIST = Driver + "getOrderHistorylist"
        const val AUTH_EDIT_PROFILE = Driver + "updateProfile"
        const val AUTH_GET_USER_PROFILE = Driver + "getProfileDetails"
        const val GET_ORDER_DETAILS = Driver + "getOrderDetails"
        const val GET_ORDER_STATUS = Driver + "changeOrderStatus"
        const val UPDATE_CATEGOORY_OF_FOOD = Driver + "updateCategory"
        const val ADD_CATEGORY = Driver + "addCategory"
        const val REMOVE_CATEGORY_ITEM = Driver + "removeCategory"
        const val GET_FAV_CATEGORY_LIST = Driver + "getCategorylist"
        const val FOOD_ITEM_CATEGORYWISE = Driver + "getProductlist"
        const val REMOVE_FOOD_ITEM = Driver + "removeFood"
        const val ADD_FOOD_ITEM = Driver +"addFood"
        const val UPDATE_FOOD_ITEM = Driver + "updateFood"
        const val GET_ONGOING_ORDER_LIST = Driver +"getOngoingOrderlist"
        const val UPDATE_BUSINESS_HOURS_LIST = Driver + "updateBusinessHours"
        const val GET_BUSINESS_HOURS_LIST = Driver + "getBusinessHours"
        const val ASSIGN_ORDER_TO_DRIVER = Driver + "assignDeliveryboy"
        const val GENERAL_GET_APP_VERSION = Driver + "checkAppVersion"


        const val GET_MODIFIER_GROUP_LIST = Driver + "getModifierGroupList"
        const val ADD_MODIFIER_GROUP = Driver +"addModifierGroup"
        const val  UPDATE_MODIFIER_GROUP_LIST = Driver +"updateModifierGroup"
        const val DELETE_MODIFIER_GROUP_LIST = Driver + "removeModifierGroup"


        const val GET_MODIFIER_ITEMLIST =  Driver + "getModifierItemlist"
        const val ADD_MODIFIER_ITEM = Driver + "addModifierItem"
        const val UPADTE_MODIFIER_ITEM = Driver + "updateModifierItem"
        const val REMOVE_MODIFIER_ITEM = Driver + "removeModifierItem"


        const val GET_PROMOCODE_LIST = Driver + "getPromocodeList"
        const val ADD_PROMOCODE = Driver + "addPromocode"
        const val EDIT_PROMOCODE = Driver + "updatePromocode"
        const val DELETE_PROMOCODE = Driver + "deletePromocode"

        const val GET_REPORT = Driver + "report"

    }

    @FormUrlEncoded
    @POST(AUTH_LOGIN)
    fun login(
        @Field("vEmail") vEmail: String,
        @Field("vPassword") vPassword: String,
        @Field("nLoginDeviceType") nLoginDeviceType: String,
        @Field("vPushToken") vPushToken: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(CONTACT_US)
    fun mContactUs(
        @Field("vName") vName: String,
        @Field("vEmail") vEmail: String,
        @Field("vMessage") vMessage: String
        ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_EARNING_DATA)
    fun getEarningData(
        @Field("dFromDate") dFromDate: String,
        @Field("dToDate") dToDate  : String
        ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_APP_LOANGUGE)
    fun getAppLanguage(
        @Field("vAppLanguage") vAppLanguage: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(ASSIGN_ORDER_TO_DRIVER)
    fun assigbDeliveryBoy(
        @Field("nOrderId") nOrderId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(AUTH_SIGN_UP)
    fun signUp(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPDATE_CATEGOORY_OF_FOOD)
    fun upDateFoodCategory(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>


    @GET(GENERAL_GET_RESTAURANT_DETAIL)
    fun getRestaurantDetails(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GENERAL_GET_FOOD_DETAILS)
    fun getFoodDetails(
        @Field("nFoodId") nFoodId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPDATE_FOOD_ITEM)
    fun upDateFoodItem(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(REMOVE_FOOD_ITEM)
    fun removeFoodItem(
        @Field("nProductId") nProductId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(ADD_UDER_ROAL)
    fun addUserRoal(
        @Field("vFirstName") vFirstName: String,
        @Field("vLastName") vLastName: String,
        @Field("vEmail") vEmail: String,
        @Field("vModules") vModules: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(ADD_DISCOUN_COUPON)
    fun addDiscountCoupon(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPDATE_DISCOUNT_COUPON)
    fun updateDiscountCoupon(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_DISCOUNT_COUPON_DETAILS)
    fun getCouponDetails(
        @Field("nCouponId") nCouponId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_ORDER_STATUS)
    fun orderStatusChange(
        @Field("nOrderId") nOrderId: String,
        @Field("nStatus") nStatus: String,
        @Field("nPreparationTime") nPreparationTime: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_DISCOUNT_COUPON_LIST)
    fun getDiscoutCouponList(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_REVIEW_LIST)
    fun getReviewsList(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_BUSINESS_HOURS_LIST)
    fun getBusinessHoiur(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(REMOVE_COUPON)
    fun removeCoupon(
        @Field("nCouponId") nCouponId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_ONGOING_ORDER_LIST)
    fun getOngoingOrderList(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_USER_ROAL_LIST)
    fun getUserRoalList(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(REMOVE_USER)
    fun removeUser(
        @Field("nUserId") nUserId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(MANEGE_BUSINESS_PROFILE)
    fun manegeBusinessProfile(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_BUSINESS_PROFILE)
    fun getBusinessProfile(): Call<WebServiceResponseHandler.ResponseBody>


    @FormUrlEncoded
    @POST(UPDATE_USER_ROAL)
    fun updateUserRoal(
        @Field("nUserId") nUserId: String,
        @Field("vFirstName") vFirstName: String,
        @Field("vLastName") vLastName: String,
        @Field("vEmail") vEmail: String,
        @Field("vModules") vModules: String
    ): Call<WebServiceResponseHandler.ResponseBody>




    @Multipart
    @POST(ADD_FOOD_ITEM)
    fun addFoodItem(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(ADD_MODIFIER_GROUP)
    fun addModifierGroup(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_MODIFIER_GROUP_LIST)
    fun getModiFierGroupList(): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPDATE_MODIFIER_GROUP_LIST)
    fun upDateModifierGroup(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(DELETE_MODIFIER_GROUP_LIST)
    fun removeModifierGroup(
        @Field("nModifierGroupId") nModifierGroupId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_MODIFIER_ITEMLIST)
    fun getModifierItemList(
        @Field("nModifierGroupId") nModifierGroupId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(ADD_MODIFIER_ITEM)
    fun addModifierItem(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPADTE_MODIFIER_ITEM)
    fun updateModifierItem(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(REMOVE_MODIFIER_ITEM)
    fun removeModifierItem(
        @Field("nModifierItemId") nModifierItemId: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @Multipart
    @POST(ADD_CATEGORY)
    fun addCategory(
        @Part fields: ArrayList<MultipartBody.Part>
        ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(UPDATE_BUSINESS_HOURS_LIST)
    fun updateBusinessHoursList(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(REMOVE_CATEGORY_ITEM)
    fun removeCategory(
        @Field("nCategoryId") nCategoryId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(FOOD_ITEM_CATEGORYWISE)
    fun getFoodItemCategoryWise(
        @Field("nCategoryId") nCategoryId: String
    ): Call<WebServiceResponseHandler.ResponseBody>



    @FormUrlEncoded
    @POST(GET_ORDER_DETAILS)
    fun getOrderDetails(
        @Field("nOrderId") nOrderId: String
    ): Call<WebServiceResponseHandler.ResponseBody>


    @GET(GET_ORDER_REQUEST_DETILES_LIST)
    fun getOrderRequestlist(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_ORDER_HESTORY_DETILES_LIST)
    fun getOrderhistorylist(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(CHANGE_ORDER_REQUEST_STATUS)
    fun mChangeOrderRequestStatus(
        @Field("nOrderId") nOrderId: String,
        @Field("nRequestStatus") nRequestStatus: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(CHANGE_ORDER_STATUS)
    fun mChangeOrderStatus(
        @Field("nOrderId") nOrderId: String,
        @Field("nOrderStatus") nOrderStatus: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_INTIAL_DATA)
    fun getIntialData(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_HISTORY_LIST)
    fun getHistoryList(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(AUTH_SOCIAL_LOGIN)
    fun socialLogin(
        @Field("vFirstName") vFirstName: String,
        @Field("vLastName") vLastName: String,
        @Field("vEmail") vEmail: String,
        @Field("nSignUpType") nSignUpType: String,
        @Field("vProviderKey") vProviderKey: String,
        @Field("nLoginDeviceType") nLoginDeviceType: String,
        @Field("vPushToken") vPushToken: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GET_UPDATE_Driver_DATA)
    fun getUpdateDriverData(
        @Field("vCategoryId") vCategoryId: String,
        @Field("vBrandId") vBrandId: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(AUTH_LOG_OUT)
    fun logout(): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(AUTH_EDIT_PROFILE)
    fun editProfile(@Part fields: ArrayList<MultipartBody.Part>): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(AUTH_CHANGE_PASSWORD)
    fun changePassword(
        @Field("vOldPassword") vOldPassword: String,
        @Field("vNewPassword") vNewPassword: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(AUTH_FORGOT_PASSWORD)
    fun forgotPassword(
        @Field("vEmail") vEmail: String
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(GENERAL_GET_APP_VERSION)
    fun getLatestApkVersion(
        @Field("nAppType") nAppType: String = "1",          //nAppType   (1=Android,2=ios)
        @Field("nRecordFor") nRecordFor: String = "3"       //nRecordFor (1=customer ,2=Driver, 3=Business )
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_ABOUT_US)
    fun getAboutUs(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_GET_TERMS)
    fun getTerms(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GENERAL_GET_PRIVACY_POLICY)
    fun getPrivacyPolicy(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_FAV_CATEGORY_LIST)
    fun getFavCategoryList(): Call<WebServiceResponseHandler.ResponseBody>


    @FormUrlEncoded
    @POST(GET_FAV_BRAND_LIST)
    fun getFavBrantList(
        @Field("vCategoryId") vCategoryId: String = "1"
    ): Call<WebServiceResponseHandler.ResponseBody>

    @GET
    fun getAddressFromLatLng(@Url addressLookUpUrl: String): Call<JsonElement>

    @GET(GENERAL_GET_NOTIFICATIONS)
    fun getNotifications(): Call<WebServiceResponseHandler.ResponseBody>

    @GET(AUTH_GET_USER_PROFILE)
    fun getProfile(): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(DRIVER_UPDATE_LAT_LNG)
    fun updateLocation(
        @Field("dLat") latitude: Double,
        @Field("dLng") longitude: Double
    ): Call<WebServiceResponseHandler.ResponseBody>


    @GET(GET_PROMOCODE_LIST)
    fun getPromocodeList(): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(ADD_PROMOCODE)
    fun addPromocode(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @Multipart
    @POST(EDIT_PROMOCODE)
    fun editPromocode(
        @Part fields: ArrayList<MultipartBody.Part>
    ): Call<WebServiceResponseHandler.ResponseBody>

    @FormUrlEncoded
    @POST(DELETE_PROMOCODE)
    fun deletePromocode(
        @Field("nPromocodeId") vPromocodeId: String,
        ): Call<WebServiceResponseHandler.ResponseBody>

    @GET(GET_REPORT)
    fun getReports(): Call<WebServiceResponseHandler.ResponseBody>

}