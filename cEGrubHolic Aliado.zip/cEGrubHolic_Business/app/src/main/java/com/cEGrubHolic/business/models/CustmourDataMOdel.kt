package com.cEGrubHolic.business.models

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class CustmourDataMOdel (
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("vMobileNo")
    val vMobileNo: String = "",
    @SerializedName("id")
    val id: String = ""
):Serializable