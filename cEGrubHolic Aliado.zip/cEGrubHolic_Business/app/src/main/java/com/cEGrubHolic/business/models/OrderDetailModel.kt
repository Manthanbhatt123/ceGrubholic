package com.egodelivery.business.models


import com.cEGrubHolic.business.models.CustmourDataMOdel
import com.cEGrubHolic.business.models.DeliveryBoyDataModel
import com.cEGrubHolic.business.models.FoodTitleModel
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OrderDetailsmodel(
    @SerializedName("dGrandTotal")
    val dGrandTotal: String = "",
    @SerializedName("vOrderId")
    val vOrderId: String = "",
    @SerializedName("id")
    val id: String = "",
    @SerializedName("vLastName")
    val vLastName: String = "",
    @SerializedName("vFirstName")
    val vFirstName: String = "",
    @SerializedName("dCreatedDate")
    val dCreatedDate: String = "",
    @SerializedName("Food")
    val Food: ArrayList<FoodTitleModel>?,
    @SerializedName("nQty")
    val nQty: String = "",
    @SerializedName("nFoodId")
    val nFoodId: String = "",
    @SerializedName("vTitle")
    val vTitle: String = "",
    @SerializedName("nStatus")
    val nStatus: String = "",
    @SerializedName("dTax")
    val dTax: String = "",
    @SerializedName("dSubTotal")
    val dSubTotal: String = "",
    @SerializedName("vNotes")
    val vNotes: String = "",
    @SerializedName("dDeliveryCharge")
    val dDeliveryCharge: String = "",
    @SerializedName("vReceiptName")
    val vReceiptName: String = "",
    @SerializedName("vPromoCode")
    val vPromoCode: String = "",
    @SerializedName("vNIT")
    val vNIT: String = "",
    @SerializedName("FoodData")
    val foodData: List<FoodTitleModel>?,
    @SerializedName("dDiscount")
    val dDiscount: String = "",
    @SerializedName("nPaymentType")
    val nPaymentType: String = "",
    @SerializedName("nSpeedRate")
    val nSpeedRate: String = "",
    @SerializedName("nAvgRate")
    val nAvgRate: Double = 0.0,
    @SerializedName("nServiceRate")
    val nServiceRate: String = "",
    @SerializedName("vNote")
    val vNote: String = "",
    @SerializedName("nQualityRate")
    val nQualityRate: String = "",
    @SerializedName("vImagePath")
    val vImagePath: String = "",
    @SerializedName("nMobileNo")
    val nMobileNo: String = "",
    @SerializedName("vSymbol")
    val vSymbol: String = "",
    @SerializedName("dConversionRate")
    val dConversionRate: String = "",
    @SerializedName("TotalItem")
    val TotalItem: String = "",
    @SerializedName("nOrderType")
    val nOrderType: String = "",
    @SerializedName("dAmountToBeCollect")
    val dAmountToBeCollect: String = "",
    @SerializedName("isAutoCancelled")
    val isAutoCancelled: String = "",
    @SerializedName("vRejectReason")
    val vRejectReason: String = "",
    @SerializedName("CustomerData")
    val vCustomerData: List<CustmourDataMOdel> = arrayListOf(),
    @SerializedName("vAddress")
    val vAddress: String = "",
    @SerializedName("dPackagingCharge")
    val dPackagingCharge: String = "",
    @SerializedName("DeliveryBoyData")
    val vDriverData: ArrayList<DeliveryBoyDataModel> = arrayListOf(),
    @SerializedName("vNickName")
    val vNickName : String = "",
    @SerializedName("vName")
    val vName: String = "",
    @SerializedName("vMobileNo")
    val vMobileNo: String = "",
    @SerializedName("dTaxAmount")
    val dTaxAmount: String = "",
    @SerializedName("vReciptName")
    val vReciptName: String = "",
    @SerializedName("vNITno")
    val vNITno: String = "",
    @SerializedName("vRecommendationNote")
    val vRecommendationNote: String = "",
    @SerializedName("isFreeDeliveryCharge")
    val isFreeDeliveryCharge: String = "",
    @SerializedName("isDiscountFrom")
    val isDiscountFrom: String = "",
    @SerializedName("nPreparationTime")
    val nPreparationTime: String = "",
    @SerializedName("dOnlinePaymentChargeAmount")
    val dOnlinePaymentChargeAmount: String = "",
    @SerializedName("vPickupVerificationCode")
    val vPickupVerificationCode: String = ""

) : Serializable




