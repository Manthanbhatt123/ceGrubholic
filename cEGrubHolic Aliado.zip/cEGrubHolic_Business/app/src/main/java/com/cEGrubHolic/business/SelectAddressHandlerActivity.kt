package com.cEGrubHolic.business

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.core.content.ContextCompat
import com.egodelivery.business.BaseActivity
import com.egodelivery.business.R
import com.cEGrubHolic.business.fragment.SelectAddressFragment
import com.egodelivery.business.utils.Constants
import com.cEGrubHolic.business.utils.FragmentUtils
import com.cEGrubHolic.business.utils.SnackbarUtils
import kotlinx.android.synthetic.main.app_main_toolbar.*
import kotlinx.android.synthetic.main.fragment_select_address.*
import kotlinx.android.synthetic.main.fragment_select_address.view.*


class SelectAddressHandlerActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_address_handler)
        btnLeft.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_back))
        btnLeft.setOnClickListener {
            finish()
        }
        val fragment = intent.getIntExtra(Constants.KEY_CAPTAIN,0)

        when(fragment){
            0->{
                val bundle = Bundle()
                bundle.putDouble("latitude", intent.getDoubleExtra("latitude", 0.00))
                bundle.putDouble("longitude", intent.getDoubleExtra("longitude", 0.00))
                bundle.putDouble("address", intent.getDoubleExtra("address", 0.00))

                val fragment = SelectAddressFragment()
                fragment.arguments = bundle

                FragmentUtils.replaceFragment(
                        this,
                        fragment, R.id.canterForAddress, false
                )

                tvTitle.text = getString(R.string.select_address)

                btnRight.setImageDrawable(ContextCompat.getDrawable(this,
                    R.drawable.ic_orderplaced_yellow_withbg
                ))

                btnRight.setOnClickListener {

                    val frag =
                            (supportFragmentManager.findFragmentById(R.id.canterForAddress) as SelectAddressFragment)

                    if (frag.currentLocation == null
                            || edtTxtLocation.text.toString().trim().isEmpty()
                    ) {
                        showSnackbar(
                                btnLeft,
                                getString(R.string.selectLocation),
                                SnackbarUtils.SnackbarType.ERROR
                        )
                        return@setOnClickListener
                    } else {
                        val resultIntent = Intent()
                        resultIntent.putExtra("latitude", frag.currentLocation!!.latitude)
                        resultIntent.putExtra("longitude", frag.currentLocation!!.longitude)
                        resultIntent.putExtra(
                                "address",
                                frag.view!!.edtTxtLocation.text.toString().trim()
                        )
                        setBusinessAddress(resultIntent)
                    }
                }
            }
        }

    }
    fun setBusinessAddress(resultIntent: Intent) {
        setResult(
                Activity.RESULT_OK,
                Intent().putExtra(Constants.KEY_BUSINESS_ADDRESS, resultIntent)
        )
        finish()
    }

    override fun onBackPressed() {
        finish()
        super.onBackPressed()
    }
}