package com.cEGrubHolic.business.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProvider
import com.egodelivery.business.R
import com.cEGrubHolic.business.BaseFragment
import com.egodelivery.business.OrderDetailsActivity

import com.egodelivery.business.adapter.OrderListAdepter
import com.egodelivery.business.models.OngoingOrderModel
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.utils.Constants.googleApiKey
import com.egodelivery.business.utils.Constants.vCurrentCurrencySymbol
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.example.godeliverybusinessapp.viewmodelprovider.GeneralVM
import kotlinx.android.synthetic.main.fragment_menu_home.*
import kotlinx.android.synthetic.main.view_no_data.*


class ManuHomeFragment : BaseFragment(), OrderListAdepter.ItemClickListener {
   val vOrderListModel = arrayListOf<OngoingOrderModel>()

    val mOrderListAdepter: OrderListAdepter = OrderListAdepter(vOrderListModel,this)

    private val userViewModel by lazy {
        ViewModelProvider(this).get(GeneralVM::class.java)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        if (!userViewModel.getIntialData.hasActiveObservers()) {
            userViewModel.getIntialData.observe(
                requireActivity(),
                androidx.lifecycle.Observer { it->
                    it.getContentIfNotHandled()?.let { it ->

                        when (it.status) {
                            ApiResponseStatus.LOADING -> {
                                swipeRefreshHomeMain.isRefreshing = true
                            }
                            ApiResponseStatus.SUCCESS -> {
                                swipeRefreshHomeMain.isRefreshing = false

                                vOrderListModel.clear()
                                vOrderListModel.addAll(
                                    Gson().fromJson(
                                        it.data!!.asJsonObject["Orderlist"],
                                        object : TypeToken<List<OngoingOrderModel>>() {}.type
                                    )
                                )
                                vCurrentCurrencySymbol =  it.data!!.asJsonObject["vSymbol"].asString

                                googleApiKey = it.data!!.asJsonObject["GooglePlaceApiKey"].asString


                                recyclerOngoingOrder.adapter = mOrderListAdepter
                                mOrderListAdepter.notifyDataSetChanged()
                                if (vOrderListModel.isEmpty()){
                                    showDetailView(false,  it.message)
                                }else{
                                    showDetailView(true, "")
                                }


                            }
                            ApiResponseStatus.ERROR -> {

                                swipeRefreshHomeMain.isRefreshing = false
                                  showDetailView(false, it.message)

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                destroyLoginSession()
                            }
                            ApiResponseStatus.NO_INTERNET -> {
                                swipeRefreshHomeMain.isRefreshing = false
                                  showDetailView(false, getString(R.string.no_internet))

                            }
                            else -> {
                                swipeRefreshHomeMain.isRefreshing = false
                            }

                        }
                    }
                })
        }


        swipeRefreshHomeMain.setOnRefreshListener {
            userViewModel.getIntialDatas()
        }
        userViewModel.getIntialDatas()
    }

    override fun onResume() {
        userViewModel.getIntialDatas()
        super.onResume()
    }

    override fun onItemClicked(menuPos: OngoingOrderModel) {

        startActivityForResult(
            Intent(requireContext(), OrderDetailsActivity::class.java)
                .putExtra(Constants.KEY_FOR_ORDER_DETIASL,menuPos.id)
            , Constants.RC_ORDER_DITAISLS
        )
    }
    private fun showDetailView(isDataAvailable: Boolean, errorMsg: String) {

        txtError.text = errorMsg
        if (isDataAvailable) {
            imgNoDataFound.visibility = View.GONE
            recyclerOngoingOrder.visibility = View.VISIBLE
        } else {
            imgNoDataFound.visibility = View.VISIBLE
            recyclerOngoingOrder.visibility = View.GONE
        }
    }
    fun refreshPage() {
        userViewModel.getIntialDatas()
    }

}