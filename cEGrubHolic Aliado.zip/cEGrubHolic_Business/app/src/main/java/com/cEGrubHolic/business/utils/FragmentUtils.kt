package com.cEGrubHolic.business.utils

import android.util.Log
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity


/**
 * Created by codexalters on 4/12/17.
 */
object FragmentUtils {


// if animation required 

/* transaction.setCustomAnimations(R.animator.fragment_slide_left_enter,
                    R.animator.fragment_slide_left_exit,
                    R.animator.fragment_slide_right_enter,
                    R.animator.fragment_slide_right_exit)
 */

    fun addFragment(
        activity: FragmentActivity,
        fragment: Fragment,
        container: Int,
        addToBackStack: Boolean
    ) {

        try {


            if (activity.supportFragmentManager.findFragmentById(container) != null &&
                activity.supportFragmentManager.findFragmentById(container)!!.javaClass == fragment.javaClass
            ) {
                return
            }

            val fragmentPopped = activity.supportFragmentManager.popBackStackImmediate(
                fragment.javaClass.simpleName,
                0
            )

            if (!fragmentPopped) {
                val transaction = activity.supportFragmentManager.beginTransaction()
               /* transaction.setCustomAnimations(
                    R.animator.fragment_slide_left_enter,
                    R.animator.fragment_slide_left_exit,
                    R.animator.fragment_slide_right_enter,
                    R.animator.fragment_slide_right_exit
                )*/

                if (activity.supportFragmentManager.findFragmentById(container) != null)
                    transaction.hide(activity.supportFragmentManager.findFragmentById(container)!!)

                transaction.add(container, fragment, fragment.javaClass.simpleName)

                if (addToBackStack) {
                    transaction.addToBackStack(fragment::class.java.simpleName)
                }

                transaction.commitAllowingStateLoss()

            }
        } catch (e: Exception) {
            Log.e("FragmentUtils", "replaceFragment : ${e.printStackTrace()} ")
        }
    }

    fun replaceFragment(
        activity: FragmentActivity,
        fragment: Fragment,
        container: Int,
        addToBackStack: Boolean
    ) {

        try {


            if (activity.supportFragmentManager.findFragmentById(container) != null &&
                activity.supportFragmentManager.findFragmentById(container)!!.javaClass == fragment.javaClass
            ) {
                return
            }

            val fragmentPopped = activity.supportFragmentManager.popBackStackImmediate(
                fragment.javaClass.simpleName,
                0
            )

            if (!fragmentPopped) {
                val transaction = activity.supportFragmentManager.beginTransaction()

                /*  transaction.setCustomAnimations(
                      R.animator.fragment_slide_left_enter,
                      R.animator.fragment_slide_left_exit,
                      R.animator.fragment_slide_right_enter,
                      R.animator.fragment_slide_right_exit
                  )*/

                if (activity.supportFragmentManager.findFragmentById(container) != null)
                    transaction.hide(activity.supportFragmentManager.findFragmentById(container)!!)

                transaction.add(container, fragment, fragment.javaClass.simpleName)

                if (addToBackStack) {
                    transaction.addToBackStack(fragment::class.java.simpleName)
                }

                transaction.commitAllowingStateLoss()


            }
        } catch (e: Exception) {
            Log.e("FragmentUtils", "replaceFragment : ${e.printStackTrace()} ")
        }
    }

    fun replaceMenuFragment(
        activity: FragmentActivity, fragment: Fragment, container: Int
    ) {

        val transaction = activity.supportFragmentManager.beginTransaction()
        transaction.add(container, fragment, fragment.javaClass.simpleName)
        transaction.commitAllowingStateLoss()
    }



}