package com.egodelivery.business

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.cEGrubHolic.business.adapter.FoodListForOrderDetailsAdepter
import com.cEGrubHolic.business.models.FoodTitleModel
import com.cEGrubHolic.business.network.ApiResponseStatus
import com.cEGrubHolic.business.utils.*
import com.egodelivery.business.models.OrderDetailsmodel
import com.egodelivery.business.utils.Constants
import com.egodelivery.business.viewmodelprovider.GanrealOrderListVM
import com.example.godeliverybusinessapp.viewmodelprovider.GeneralVM
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.synthetic.main.activity_order_details.*
import kotlinx.android.synthetic.main.app_main_toolbar.*
import kotlinx.android.synthetic.main.dilog_for_delevry_coanformetion.view.*
import kotlinx.android.synthetic.main.dilog_for_pripretiontime.view.*

class OrderDetailsActivity : BaseActivity() {
    private val userViewModel by lazy {
        ViewModelProvider(this).get(GanrealOrderListVM::class.java)
    }
    private val usersViewModel by lazy {
        ViewModelProvider(this).get(GeneralVM::class.java)
    }
    var mDefultCount = 0
    var currency = ""
    val conversionRate = "1"
    var getGrandTotal :Double = 0.0

    val vFoodlistModel = arrayListOf<FoodTitleModel>()
    val foodListAdepter: FoodListForOrderDetailsAdepter =
        FoodListForOrderDetailsAdepter(vFoodlistModel)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_details)
        currency = Constants.vCurrentCurrencySymbol

        setLightStatusBar()
        btnLeft.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_back))
        btnLeft.setOnClickListener {
            finish()
        }
        tvTitle.text = getString(R.string.order_details)


        if (!usersViewModel.chengeOrderStatusApi.hasActiveObservers())
            usersViewModel.chengeOrderStatusApi.observe(
                this,
                Observer { apiResponse ->
                    apiResponse.getContentIfNotHandled()?.let { apiResponse ->
                        when (apiResponse?.status) {

                            ApiResponseStatus.LOADING -> {
                                showProgress(getString(R.string.loding), false)
                            }
                            ApiResponseStatus.SUCCESS -> {
                                hideProgress()
                                showSnackbar(
                                    tvOrderBillNo,
                                    apiResponse.message,
                                    SnackbarUtils.SnackbarType.SUCCESS
                                )
                                userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)
                                linearAcceptReject.visibility = View.GONE
                                btnHandoverToDriver.visibility = View.VISIBLE
                            }

                            ApiResponseStatus.ERROR -> {

                                hideProgress()
                                showSnackbar(
                                    tvOrderBillNo,
                                    apiResponse.message,
                                    SnackbarUtils.SnackbarType.ERROR
                                )

                            }

                            ApiResponseStatus.NO_INTERNET -> {

                                hideProgress()
                                showSnackbar(
                                    tvOrderBillNo,
                                    getString(R.string.no_internet),
                                    SnackbarUtils.SnackbarType.ERROR
                                )

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                hideProgress()
                                destroyLoginSession(true)
                            }
                        }
                    }
                })
        /*    if (!userViewModel.assignDeliveryBoyApi.hasActiveObservers())
                userViewModel.assignDeliveryBoyApi.observe(
                    this,
                    Observer { apiResponse ->
                        apiResponse.getContentIfNotHandled()?.let { apiResponse ->
                            when (apiResponse?.status) {

                                ApiResponseStatus.LOADING -> {
                                    showProgress(getString(R.string.loding), false)
                                }
                                ApiResponseStatus.SUCCESS -> {
                                    hideProgress()
                                    showSnackbar(
                                        tvOrderBillNo,
                                        apiResponse.message,
                                        SnackbarUtils.SnackbarType.SUCCESS
                                    )
                                //   userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)

                                }

                                ApiResponseStatus.ERROR -> {

                                    hideProgress()
                                    showSnackbar(
                                        tvOrderBillNo,
                                        apiResponse.message,
                                        SnackbarUtils.SnackbarType.ERROR
                                    )

                                }

                                ApiResponseStatus.NO_INTERNET -> {

                                    hideProgress()
                                    showSnackbar(
                                        tvOrderBillNo,
                                        getString(R.string.no_internet),
                                        SnackbarUtils.SnackbarType.ERROR
                                    )

                                }
                                ApiResponseStatus.SESSION_EXPIRED -> {
                                    hideProgress()
                                    destroyLoginSession(true)
                                }
                            }
                        }
                    })*/




        if (!userViewModel.getOrderDetaislApi.hasActiveObservers())
            userViewModel.getOrderDetaislApi.observe(
                this,
                Observer { it ->

                    it.getContentIfNotHandled()?.let { apiResponse ->
                        when (apiResponse.status) {

                            ApiResponseStatus.LOADING -> {
                                orderDetailsRifreshh.isRefreshing = true

                            }
                            ApiResponseStatus.SUCCESS -> {
                                orderDetailsRifreshh.isRefreshing = false

                                upDateUiOrderDetails(
                                    Gson().fromJson(
                                        apiResponse.data,
                                        object : TypeToken<OrderDetailsmodel>() {}.type
                                    )
                                )


                                vFoodlistModel.clear()
                                vFoodlistModel.addAll(
                                    Gson().fromJson(
                                        apiResponse.data!!.asJsonObject["FoodData"],
                                        object : TypeToken<List<FoodTitleModel>>() {}.type
                                    )
                                )
                                recycerlOrderItem.adapter = foodListAdepter



                                mDefultCount = vFoodlistModel.count()
                                tvOrderItemCount.text =
                                    mDefultCount.toString() + " " + getString(R.string.items)

                                foodListAdepter.notifyDataSetChanged()
                                //      showDetailView(apiResponse.message, true)
                            }

                            ApiResponseStatus.ERROR -> {
                                orderDetailsRifreshh.isRefreshing = false
                                //     hideProgress()
                                //     showDetailView(apiResponse.message, false)

                            }

                            ApiResponseStatus.NO_INTERNET -> {
                                orderDetailsRifreshh.isRefreshing = false
                                showSnackbar(
                                    tvOrderBillNo,
                                    getString(R.string.no_internet),
                                    SnackbarUtils.SnackbarType.ERROR
                                )
                                //    showDetailView(apiResponse.message, false)

                            }
                            ApiResponseStatus.SESSION_EXPIRED -> {
                                orderDetailsRifreshh.isRefreshing = false

                                destroyLoginSession(true)
                            }
                        }
                    }
                })

        orderDetailsRifreshh.setOnRefreshListener {
            userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)
        }
        userViewModel.getOrderdetails(intent.getStringExtra(Constants.KEY_FOR_ORDER_DETIASL)!!)

    }

    private fun upDateUiOrderDetails(mOrderDetailsmodel: OrderDetailsmodel) {

        tvItemDetailsNoteOrder.text = mOrderDetailsmodel.vRecommendationNote
        tvOrderDitailsReceiptName.text = mOrderDetailsmodel.vReciptName
        tvOrderDetailsNit.text = mOrderDetailsmodel.vNITno
        tvOrderBillNo.text = "#" + mOrderDetailsmodel.vOrderId
        tvOnline_Service_Charge.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dOnlinePaymentChargeAmount, currency, conversionRate
        )

        if (mOrderDetailsmodel.isFreeDeliveryCharge == "0") {
            tvDeliveryCharges.text = getString(R.string.paid_by_customer)
        } else {
            if (mOrderDetailsmodel.isDiscountFrom == "1") {
                tvDeliveryCharges.text = "paid by ${getString(R.string.app_name)}"
            } else {
                tvDeliveryCharges.text = getString(R.string.paid_by_you)
            }
        }
        getGrandTotal = mOrderDetailsmodel.dOnlinePaymentChargeAmount.toDouble() + mOrderDetailsmodel.dGrandTotal.toDouble()


        tvOrderDateTime.text = DateTimeUtils.convertDateFormat(
            mOrderDetailsmodel.dCreatedDate,
            "yyyy-MM-dd HH:mm:ss", "dd MMM,yyyy  HH:mm"
        )

        tvOrdeAddrssLocation.text = mOrderDetailsmodel.vAddress

        tvSubTotals.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dSubTotal, currency, conversionRate
        )

        tvDeliveryCharges.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dDeliveryCharge, currency, conversionRate
        )

        tvDiscounts.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dDiscount, currency, conversionRate
        )


        tvPackagingCharge.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dPackagingCharge, currency, conversionRate
        )

        txtPripretionTimeDet.text = mOrderDetailsmodel.nPreparationTime + getString(R.string.min)

        if (mOrderDetailsmodel.vNickName.isEmpty()) {
            tvOrdeHomeloc.visibility = View.GONE
        } else {
            tvOrdeHomeloc.text = mOrderDetailsmodel.vNickName
        }

        if (mOrderDetailsmodel.nPaymentType == "1") {
            txtPyamentType.text = getString(R.string.cod)
        } else if (mOrderDetailsmodel.nPaymentType == "2") {
            txtPyamentType.text = getString(R.string.online)
        }

        if (mOrderDetailsmodel.nOrderType== "1") {
            txtOrderType.text = getString(R.string.takeaway)

        } else {
            txtOrderType.text = getString(R.string.deliver)
        }

        txtTakeAwayCode.text = mOrderDetailsmodel.vPickupVerificationCode
        //   val vTaxCalculation =(mOrderDetailsmodel.dSubTotal.toDouble() - mOrderDetailsmodel.dDiscount.toDouble())
        // val taxamountis = (vTaxCalculation * mOrderDetailsmodel.dTax.toDouble()) /100.00
        //  val totalAmount =taxamountis + mOrderDetailsmodel.dGrandTotal.toDouble()

        tvTaxAmounts.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            mOrderDetailsmodel.dTaxAmount, currency, conversionRate
        )




        tvTotalOrderAmounts.text = FormValidationUtils.getValueWithCurrencySymbolCode(
            getGrandTotal  , currency, conversionRate
        )


        val mCustomerData = mOrderDetailsmodel.vCustomerData

        tvOrderDitelasUserName.text = mCustomerData[0].vName
        tvOrderDetailsUserContect.text = mCustomerData[0].vMobileNo
        tvOrderDetailsUserContect.setOnClickListener {
            checkAndAskCallPermission {
                if (it) {
                    IntentUtils.callIntent(
                        this,
                        mCustomerData[0].vMobileNo
                    )
                }
            }

        }

        relAccpetOrder.setOnClickListener {
            val deleteAdView = LayoutInflater.from(this)
                .inflate(R.layout.dilog_for_pripretiontime, null)

            val deleteAlert =
                AlertDialogUtil.createCustomAlertDialog(
                    this,
                    deleteAdView
                )
            deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            deleteAlert.setCancelable(true)
            deleteAlert.show()
            deleteAdView.btnSubmitTime.setOnClickListener {
                if (deleteAdView.edtExtendedTime.text.toString().trim().isEmpty()) {
                    deleteAdView.edtExtendedTime.requestFocus()
                    showSnackbar(
                        tvOrderBillNo,
                        getString(R.string.enter_prep_time),
                        SnackbarUtils.SnackbarType.WARNING
                    )
                } else {
                    usersViewModel.changeOrderStatus(
                        mOrderDetailsmodel.id,
                        "1",
                        deleteAdView.edtExtendedTime.text.toString().trim()
                    )
                    linearAcceptReject.visibility = View.GONE
                    deleteAlert.dismiss()
                }

            }


        }

        relRejectOrder.setOnClickListener {
            val deleteAdView = LayoutInflater.from(this)
                .inflate(R.layout.dilog_for_delevry_coanformetion, null)

            val deleteAlert =
                AlertDialogUtil.createCustomAlertDialog(
                    this,
                    deleteAdView
                )
            deleteAlert.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            deleteAlert.setCancelable(false)
            deleteAlert.show()
            deleteAdView.btndelevryYes.setOnClickListener {
                usersViewModel.changeOrderStatus(mOrderDetailsmodel.id, "4", "")
                deleteAlert.dismiss()
            }
            deleteAdView.btndelevryNo.setOnClickListener {
                deleteAlert.dismiss()
            }

        }
        val vDraiverDetisl = mOrderDetailsmodel.vDriverData

        if (mOrderDetailsmodel.nStatus == "0") {
            linearAcceptReject.visibility = View.VISIBLE
            btnHandoverToDriver.visibility = View.GONE
            btnDriverDetails.visibility = View.GONE
            tvOrderDetailStatusLabel.text =
                getString(R.string.order_received) + " " + getString(R.string.on)
        } else if (mOrderDetailsmodel.nStatus == "1") {
            tvOrderDetailStatusLabel.text =
                getString(R.string.orderaccepted) + " " + getString(R.string.on)

            // this code for Verification code
            /*    if (mOrderDetailsmodel.nOrderType== "1"){
                    relativeForVerificationCode.visibility = View.VISIBLE
                    btnHandoverToDriver.visibility = View.VISIBLE
                }else{
                    relativeForVerificationCode.visibility = View.GONE
                    if (vDraiverDetisl[0].vName.isBlank()) {
                        btnHandoverToDriver.visibility = View.GONE
                    } else {
                        btnHandoverToDriver.visibility = View.VISIBLE
                    }
                }*/
            if (vDraiverDetisl[0].vName.isBlank()) {
                btnHandoverToDriver.visibility = View.GONE
            } else {
                btnHandoverToDriver.visibility = View.VISIBLE
            }
            linearAcceptReject.visibility = View.GONE
            btnDriverDetails.visibility = View.GONE
        } else if (mOrderDetailsmodel.nStatus == "2") {
            tvOrderDetailStatusLabel.text =
                getString(R.string.orderdispatched) + " " + getString(R.string.on)
            btnHandoverToDriver.visibility = View.GONE
            linearAcceptReject.visibility = View.GONE
        } else if (mOrderDetailsmodel.nStatus == "3") {
            relativeForVerificationCode.visibility = View.GONE
            btnHandoverToDriver.visibility = View.GONE
            tvOrderDetailStatusLabel.text =
                getString(R.string.order_delivered) + " " + getString(R.string.on)
        } else if (mOrderDetailsmodel.nStatus == "4") {
            tvOrderDetailStatusLabel.text =
                getString(R.string.order_cencel) + " " + getString(R.string.on)
        } else {
            btnHandoverToDriver.visibility = View.GONE
        }

        btnHandoverToDriver.setOnClickListener {
            if (mOrderDetailsmodel.nOrderType == "1") {

                usersViewModel.changeOrderStatus(mOrderDetailsmodel.id, "3", "")

                // this code for Verification code
                /*   if (edtVerificationCode.text.toString().trim().isEmpty()){
                       showSnackbar(
                           tvOrderBillNo,
                           getString(R.string.enter_pickup_verification_code),
                           SnackbarUtils.SnackbarType.WARNING
                       )
                   }else{
                       if (edtVerificationCode.text.toString().trim() == mOrderDetailsmodel.vPickupVerificationCode) {
                           usersViewModel.changeOrderStatus(mOrderDetailsmodel.id, "3", "")
                       }else{
                           showSnackbar(
                               tvOrderBillNo,
                               getString(R.string.enter_currect_pickup),
                               SnackbarUtils.SnackbarType.WARNING
                           )
                       }
                   }*/

            } else {
                usersViewModel.changeOrderStatus(mOrderDetailsmodel.id, "2", "")
            }

        }


        tvOrderDriverContect.setOnClickListener {
            checkAndAskCallPermission {
                if (it) {
                    IntentUtils.callIntent(
                        this,
                        vDraiverDetisl[0].vContect
                    )
                }
            }
        }




        if (vDraiverDetisl[0].vName.isBlank()) {
            btnDriverDetails.visibility = View.GONE
        } else {
            btnDriverDetails.visibility = View.VISIBLE
            tvOrderDriverNAme.text = vDraiverDetisl[0].vName
            tvOrderDriverContect.text = vDraiverDetisl[0].vContect
        }


    }


}