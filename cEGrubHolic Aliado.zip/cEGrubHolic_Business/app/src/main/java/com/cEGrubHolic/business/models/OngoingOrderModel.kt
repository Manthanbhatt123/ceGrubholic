package com.egodelivery.business.models

import com.cEGrubHolic.business.models.FoodTitleModel
import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class OngoingOrderModel(
    @SerializedName("vOrderId")
    val vOrderID: String,
    @SerializedName("vCustomerName")
    val vOrderUsen: String,
    @SerializedName("dCreatedDate")
    val vOrderDate: String,
    @SerializedName("dGrandTotal")
    val vOrderAmount: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("nPreparationTime")
    val nPreparationTime: String = "",
    @SerializedName("Food")
    val foodItemModel: ArrayList<FoodTitleModel>?

): Serializable