package com.cEGrubHolic.business.models


import com.google.gson.annotations.SerializedName
import java.io.Serializable

data class AddressLookUpResponseModel(
    @SerializedName("results")
    val results: List<ResultsItem> = arrayListOf(),
    @SerializedName("status")
    val status: String = ""
) : Serializable {
    data class Geometry(
        @SerializedName("location")
        val location: Location,
        @SerializedName("location_type")
        val locationType: String = ""
    ) : Serializable


    data class ResultsItem(
        @SerializedName("formatted_address")
        val formattedAddress: String = "",
        @SerializedName("geometry")
        val geometry: Geometry,
        @SerializedName("place_id")
        val placeId: String = "",
        @SerializedName("address_components")
        val address_components: ArrayList<AddresscComponents>
    ) : Serializable

    data class Location(
        @SerializedName("lng")
        val lng: Double = 0.0,
        @SerializedName("lat")
        val lat: Double = 0.0
    ) : Serializable


    data class AddresscComponents(
        @SerializedName("long_name")
        val long_name: String = "",
        @SerializedName("short_name")
        val short_name: String = "",
        @SerializedName("types")
        val types: ArrayList<String> = arrayListOf()
    ) : Serializable

}
